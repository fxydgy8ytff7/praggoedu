# 🏫 Advanced School Management System (SMS) v2.0

A comprehensive, modern School Management System with **Smart Database Architecture** and **Advanced Head Teacher SMS Panel**. Built specifically for Bangladesh education system with local SMS providers, Bengali language support, and advanced messaging capabilities.

## 🚀 **New Features in v2.0**

### 🧠 **Smart Database Structure**
- **Normalized Database**: Proper relationships between all entities
- **Role-based Architecture**: Unified user management with granular permissions
- **Audit Logging**: Complete activity tracking for compliance
- **Scalable Design**: Optimized for multi-school deployment

### 👑 **Head Teacher Special Powers**
- **Advanced SMS Panel**: Send targeted messages to any group
- **Smart Recipient Targeting**: Filter by class, gender, attendance, performance
- **Message Scheduling**: Schedule messages for future delivery
- **Bulk Operations**: Send to thousands of recipients efficiently
- **Message Templates**: Pre-built templates for common scenarios
- **Delivery Tracking**: Real-time delivery status and analytics

### 📲 **Advanced SMS System**
- **Multiple Providers**: Muthofun, BulkSMSBD, Twilio support
- **Smart Routing**: Automatic failover between providers
- **Cost Optimization**: Track SMS costs and optimize delivery
- **Bengali Support**: Full Unicode support for Bengali messages
- **Emergency Alerts**: High-priority message delivery

## 🎯 **Core Features**

### **Multi-Role System**
- **Super Admin**: System-wide management across all schools
- **School Admin**: Complete school operations management
- **Head Teacher**: Advanced privileges with SMS powers
- **Teachers**: Classroom and student management
- **Students**: Academic records and assignments
- **Parents**: Child monitoring and communication

### **Smart Messaging System**
- **Targeted Messaging**: Send to specific groups or individuals
- **Template System**: Pre-built message templates
- **Scheduled Messages**: Send messages at optimal times
- **Delivery Analytics**: Track message performance
- **Cost Management**: Monitor SMS expenses
- **Emergency Broadcasts**: Instant alerts to all stakeholders

### **Academic Management**
- **Attendance Tracking**: Multiple methods (Manual, QR, NFC, Fingerprint)
- **Grade Management**: Comprehensive result tracking
- **Assignment System**: Digital assignment submission
- **Exam Management**: Complete examination workflow
- **Report Generation**: Automated report cards and analytics

### **Financial Management**
- **Fee Structure**: Flexible fee management
- **Online Payments**: SSLCommerz and bKash integration
- **Payment Tracking**: Real-time payment status
- **Financial Reports**: Comprehensive financial analytics

## 🛠 **Technology Stack**

### **Frontend**
- **Next.js 14** - React framework with App Router
- **TypeScript** - Type-safe development
- **Tailwind CSS** - Modern styling
- **shadcn/ui** - Beautiful UI components
- **Recharts** - Data visualization

### **Backend**
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **PostgreSQL** - Primary database with advanced relationships
- **JWT** - Secure authentication
- **Socket.io** - Real-time communication

### **SMS Integration**
- **Muthofun** - Primary SMS provider for Bangladesh
- **BulkSMSBD** - Secondary SMS provider
- **Twilio** - International SMS support
- **Node-cron** - Scheduled message processing

### **Additional Services**
- **Firebase** - Push notifications
- **Nodemailer** - Email notifications
- **Multer** - File upload handling
- **PDF Generation** - Report generation

## 📊 **Database Schema Highlights**

### **Smart Relationships**
\`\`\`sql
-- Unified user management
users → roles (Many-to-One)
users → schools (Many-to-One)

-- Academic structure
students → classes → sections (Many-to-One)
teachers ↔ subjects ↔ classes (Many-to-Many)

-- Family relationships
students ↔ guardians (Many-to-Many)

-- Communication tracking
message_logs → users (audit trail)
scheduled_messages → message_logs (scheduling)
\`\`\`

### **Key Tables**
- **24 Normalized Tables** with proper relationships
- **Audit Logging** for all critical operations
- **Message Tracking** with delivery status
- **Financial Records** with transaction history
- **Academic Records** with complete grade tracking

## 🚀 **Quick Start**

### **Prerequisites**
- Node.js 18+
- PostgreSQL 14+
- SMS Provider Account (Muthofun/BulkSMSBD)

### **Installation**

1. **Clone and Install**
\`\`\`bash
git clone https://github.com/your-repo/school-management-system.git
cd school-management-system
npm install
\`\`\`

2. **Environment Setup**
\`\`\`bash
cp .env.example .env.local
\`\`\`

Configure your `.env.local`:
\`\`\`env
# Database
DATABASE_URL=postgresql://username:password@localhost:5432/sms_db

# JWT
JWT_SECRET=your-super-secret-jwt-key

# SMS Providers
MUTHOFUN_API_KEY=your-muthofun-api-key
MUTHOFUN_API_SECRET=your-muthofun-secret
MUTHOFUN_SENDER_ID=SCHOOL

BULKSMSBD_API_KEY=your-bulksmsbd-key
BULKSMSBD_SENDER_ID=SCHOOL

TWILIO_ACCOUNT_SID=your-twilio-sid
TWILIO_AUTH_TOKEN=your-twilio-token
TWILIO_PHONE_NUMBER=your-twilio-number

# Payment Gateway
SSLCOMMERZ_STORE_ID=your-store-id
SSLCOMMERZ_STORE_PASSWORD=your-store-password
\`\`\`

3. **Database Setup**
\`\`\`bash
# Create database
createdb sms_db

# Run migrations
npm run db:migrate

# Seed demo data
npm run db:seed
\`\`\`

4. **Start Development**
\`\`\`bash
# Frontend
npm run dev

# Backend
npm run server:dev
\`\`\`

### **Default Login Credentials**
- **Super Admin**: admin@sms.com / admin123
- **Head Teacher**: head@dhakamodel.edu.bd / head123
- **School Admin**: admin@dhakamodel.edu.bd / admin123
- **Teacher**: teacher001 / teacher123
- **Student**: 2024001 / student123
- **Parent**: guardian001@email.com / guardian123

## 📱 **Head Teacher SMS Panel**

### **Advanced Targeting**
\`\`\`javascript
// Example: Send to absent students' parents
{
  "recipients": {
    "type": "guardians",
    "filters": {
      "attendanceStatus": "absent",
      "date": "today"
    }
  },
  "message": "Your child was absent today. Please contact school.",
  "messageType": "attendance_alert"
}
\`\`\`

### **Message Templates**
- **Attendance Alert**: Automated absence notifications
- **Fee Due Alert**: Payment reminders with amounts
- **Result Published**: Exam result notifications
- **Emergency Notice**: Urgent school-wide alerts
- **Event Reminder**: Upcoming event notifications

### **Scheduling Options**
- **Immediate**: Send right away
- **Scheduled**: Send at specific date/time
- **Recurring**: Daily/Weekly/Monthly repeats
- **Optimal Timing**: Send during parent-friendly hours

## 🔧 **API Documentation**

### **SMS Endpoints**
\`\`\`bash
POST /api/sms/send              # Send SMS
GET  /api/sms/templates         # Get message templates
GET  /api/sms/statistics        # SMS analytics
GET  /api/sms/logs             # Message history
POST /api/sms/recipients        # Get recipient list
POST /api/sms/retry/:id         # Retry failed message
\`\`\`

### **Head Teacher Endpoints**
\`\`\`bash
GET  /api/head-teacher/dashboard    # Advanced dashboard
GET  /api/head-teacher/analytics    # School analytics
POST /api/head-teacher/broadcast    # Emergency broadcast
GET  /api/head-teacher/reports      # Generate reports
\`\`\`

## 📊 **Advanced Analytics**

### **SMS Analytics**
- **Delivery Rates**: Track message success rates
- **Cost Analysis**: Monitor SMS expenses
- **Response Tracking**: Measure parent engagement
- **Provider Performance**: Compare SMS provider efficiency

### **Academic Analytics**
- **Attendance Trends**: Class-wise attendance patterns
- **Performance Metrics**: Subject-wise academic performance
- **Financial Analytics**: Fee collection and revenue tracking
- **Communication Analytics**: Message effectiveness metrics

## 🔒 **Security Features**

### **Advanced Authentication**
- **JWT-based**: Secure token authentication
- **Role-based Access**: Granular permission system
- **Session Management**: Secure session handling
- **Audit Logging**: Complete activity tracking

### **Data Protection**
- **Input Validation**: Comprehensive data validation
- **SQL Injection Protection**: Parameterized queries
- **Rate Limiting**: API abuse prevention
- **Data Encryption**: Sensitive data protection

## 🌐 **Deployment**

### **Production Setup**
\`\`\`bash
# Build application
npm run build

# Start production server
npm start

# Run database migrations
npm run db:migrate

# Start SMS scheduler
node server/cron/sms-scheduler.js
\`\`\`

### **Environment Variables**
Ensure all production environment variables are configured:
- Database connections
- SMS provider credentials
- Payment gateway settings
- Security keys

## 📈 **Performance Optimization**

### **Database Optimization**
- **Indexed Queries**: Optimized database indexes
- **Connection Pooling**: Efficient database connections
- **Query Optimization**: Optimized SQL queries
- **Caching Strategy**: Redis caching for frequent queries

### **SMS Optimization**
- **Batch Processing**: Send messages in batches
- **Provider Failover**: Automatic provider switching
- **Cost Optimization**: Choose cheapest provider
- **Rate Limiting**: Respect provider limits

## 🧪 **Testing**

### **Demo Data**
The system includes comprehensive demo data:
- **5 Classes** with 2 sections each
- **10 Teachers** across different subjects
- **50 Students** distributed across classes
- **20 Guardians** linked to students
- **Sample Messages** and delivery logs

### **Test Scenarios**
\`\`\`bash
# Run tests
npm test

# Test SMS functionality
npm run test:sms

# Test database operations
npm run test:db
\`\`\`

## 🤝 **Contributing**

1. Fork the repository
2. Create feature branch (`git checkout -b feature/amazing-feature`)
3. Commit changes (`git commit -m 'Add amazing feature'`)
4. Push to branch (`git push origin feature/amazing-feature`)
5. Open Pull Request

## 📝 **License**

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 **Support**

For support and questions:
- **Email**: support@schoolmanagementsystem.com
- **Documentation**: [docs.schoolmanagementsystem.com](https://docs.schoolmanagementsystem.com)
- **Issues**: [GitHub Issues](https://github.com/your-repo/school-management-system/issues)

## 🎉 **Acknowledgments**

- Built specifically for Bangladesh education system
- Supports Bengali language and local payment methods
- Optimized for local SMS providers
- Mobile-first responsive design
- Scalable architecture for multiple schools

---

**🚀 Built with ❤️ for modern education management in Bangladesh**

### **Key Improvements in v2.0**
✅ **Smart normalized database** with proper relationships  
✅ **Head Teacher SMS panel** with advanced targeting  
✅ **Multiple SMS providers** with failover support  
✅ **Message scheduling** and template system  
✅ **Advanced analytics** and reporting  
✅ **Audit logging** for compliance  
✅ **Bengali language** support  
✅ **Cost optimization** for SMS delivery  
✅ **Emergency broadcast** system  
✅ **Comprehensive demo data** for testing
