# School Management System (SMS)

A comprehensive, modern School Management System built with Next.js, Node.js, and PostgreSQL. This system supports multiple user roles including Super Admin, School Admin, Teachers, Students, and Parents with features like attendance tracking, fee management, academic records, and real-time notifications.

## 🚀 Features

### Multi-Role Authentication
- **Super Admin**: Manage multiple schools, system-wide settings, and analytics
- **School Admin**: Manage school operations, students, teachers, and classes
- **Teachers**: Take attendance, manage assignments, grade students, and communicate with parents
- **Students**: View academic records, assignments, attendance, and fee status
- **Parents**: Monitor children's progress, receive notifications, and communicate with teachers

### Core Functionality
- **Attendance System**: Manual, QR code, NFC, and fingerprint-based attendance
- **Fee Management**: Online payments, fee tracking, and automated notifications
- **Academic Management**: Results, assignments, class schedules, and report cards
- **Communication**: Real-time messaging between teachers, parents, and students
- **Mobile App Support**: React Native app with push notifications
- **Multi-language Support**: English and Bengali (Bangla) support
- **Reporting**: Comprehensive reports for attendance, fees, and academic performance

## 🛠 Technology Stack

### Frontend
- **Next.js 14** - React framework with App Router
- **React 18** - UI library
- **Tailwind CSS** - Utility-first CSS framework
- **shadcn/ui** - Modern UI components
- **TypeScript** - Type-safe JavaScript

### Backend
- **Node.js** - Runtime environment
- **Express.js** - Web framework
- **PostgreSQL** - Primary database
- **JWT** - Authentication
- **Socket.io** - Real-time communication
- **Multer** - File upload handling

### Mobile
- **React Native** - Cross-platform mobile development
- **Firebase** - Push notifications and real-time sync

### Additional Services
- **SMS Integration** - For attendance and fee notifications
- **Payment Gateway** - SSLCommerz/bKash integration for Bangladesh
- **Email Service** - Automated email notifications

## 📁 Project Structure

\`\`\`
school-management-system/
├── app/                          # Next.js App Router pages
│   ├── page.tsx                 # Login page
│   ├── super-admin/             # Super admin dashboard
│   ├── admin/                   # School admin dashboard
│   ├── teacher/                 # Teacher dashboard
│   ├── student/                 # Student dashboard
│   └── parent/                  # Parent dashboard
├── components/                   # Reusable React components
│   ├── ui/                      # shadcn/ui components
│   └── layouts/                 # Layout components
├── server/                      # Backend API
│   ├── routes/                  # API routes
│   ├── middleware/              # Express middleware
│   ├── models/                  # Database models
│   └── utils/                   # Utility functions
├── scripts/                     # Database scripts
│   ├── database-schema.sql      # PostgreSQL schema
│   └── seed-data.sql           # Sample data
├── mobile/                      # React Native app
│   ├── src/                     # Mobile app source
│   └── android/                 # Android-specific files
└── docs/                        # Documentation
\`\`\`

## 🚀 Quick Start

### Prerequisites
- Node.js 18+ 
- PostgreSQL 14+
- npm or yarn

### Installation

1. **Clone the repository**
\`\`\`bash
git clone https://github.com/your-repo/school-management-system.git
cd school-management-system
\`\`\`

2. **Install dependencies**
\`\`\`bash
npm install
\`\`\`

3. **Set up environment variables**
\`\`\`bash
cp .env.example .env.local
\`\`\`

Edit `.env.local` with your configuration:
\`\`\`env
# Database
DATABASE_URL=postgresql://username:password@localhost:5432/school_management_system

# JWT
JWT_SECRET=your-super-secret-jwt-key

# SMS Service (for Bangladesh)
SMS_API_KEY=your-sms-api-key
SMS_API_SECRET=your-sms-secret

# Payment Gateway
SSLCOMMERZ_STORE_ID=your-store-id
SSLCOMMERZ_STORE_PASSWORD=your-store-password

# Firebase (for push notifications)
FIREBASE_PROJECT_ID=your-firebase-project-id
FIREBASE_PRIVATE_KEY=your-firebase-private-key
FIREBASE_CLIENT_EMAIL=your-firebase-client-email
\`\`\`

4. **Set up the database**
\`\`\`bash
# Create database and run migrations
psql -U postgres -c "CREATE DATABASE school_management_system;"
psql -U postgres -d school_management_system -f scripts/database-schema.sql
\`\`\`

5. **Start the development servers**

Frontend (Next.js):
\`\`\`bash
npm run dev
\`\`\`

Backend (Express.js):
\`\`\`bash
npm run server:dev
\`\`\`

6. **Access the application**
- Frontend: http://localhost:3000
- Backend API: http://localhost:5000

### Default Login Credentials
- **Super Admin**: admin@sms.com / admin123
- **School Admin**: admin@school.edu / admin123
- **Teacher**: teacher@school.edu / teacher123
- **Student**: 2024001 / student123
- **Parent**: parent@email.com / parent123

## 📱 Mobile App Setup

### React Native Development

1. **Navigate to mobile directory**
\`\`\`bash
cd mobile
\`\`\`

2. **Install dependencies**
\`\`\`bash
npm install
\`\`\`

3. **For Android development**
\`\`\`bash
npx react-native run-android
\`\`\`

4. **For iOS development**
\`\`\`bash
npx react-native run-ios
\`\`\`

## 🔧 API Documentation

### Authentication Endpoints
\`\`\`
POST /api/auth/login          # User login
POST /api/auth/logout         # User logout
POST /api/auth/refresh        # Refresh token
\`\`\`

### Super Admin Endpoints
\`\`\`
GET  /api/super-admin/schools     # Get all schools
POST /api/super-admin/schools     # Create new school
PUT  /api/super-admin/schools/:id # Update school
DELETE /api/super-admin/schools/:id # Delete school
\`\`\`

### School Admin Endpoints
\`\`\`
GET  /api/admin/dashboard         # Dashboard statistics
GET  /api/admin/students          # Get students
POST /api/admin/students          # Add student
PUT  /api/admin/students/:id      # Update student
DELETE /api/admin/students/:id    # Delete student
\`\`\`

### Teacher Endpoints
\`\`\`
GET  /api/teacher/classes         # Get assigned classes
POST /api/teacher/attendance      # Submit attendance
GET  /api/teacher/assignments     # Get assignments
POST /api/teacher/assignments     # Create assignment
\`\`\`

### Student Endpoints
\`\`\`
GET  /api/student/profile         # Get student profile
GET  /api/student/attendance      # Get attendance record
GET  /api/student/results         # Get exam results
GET  /api/student/assignments     # Get assignments
\`\`\`

### Parent Endpoints
\`\`\`
GET  /api/parent/children         # Get children list
GET  /api/parent/notifications    # Get notifications
POST /api/parent/messages         # Send message to teacher
\`\`\`

## 🎯 Key Features Implementation

### 1. Attendance System
- **Manual Attendance**: Teachers can mark attendance through web interface
- **QR Code**: Students scan QR codes for quick attendance
- **NFC Tags**: Students tap NFC cards/tags for attendance
- **Fingerprint**: Integration with biometric devices (optional)
- **Auto SMS**: Parents receive SMS notifications for absences

### 2. Fee Management
- **Online Payments**: Integration with SSLCommerz and bKash
- **Payment Tracking**: Real-time fee status updates
- **Automated Reminders**: SMS and email reminders for due payments
- **Receipt Generation**: Digital receipts and payment history

### 3. Academic Management
- **Grade Book**: Teachers can input and manage grades
- **Report Cards**: Automated report card generation
- **Assignment Management**: Upload, submit, and grade assignments
- **Class Scheduling**: Dynamic class routine management

### 4. Communication System
- **Real-time Messaging**: Teachers, parents, and students can communicate
- **Announcements**: School-wide and class-specific announcements
- **Push Notifications**: Mobile app notifications for important updates
- **SMS Integration**: Automated SMS for critical updates

## 🔒 Security Features

- **JWT Authentication**: Secure token-based authentication
- **Role-based Access Control**: Different permissions for each user type
- **Data Encryption**: Sensitive data encryption at rest and in transit
- **Rate Limiting**: API rate limiting to prevent abuse
- **Input Validation**: Comprehensive input validation and sanitization
- **SQL Injection Protection**: Parameterized queries and ORM usage

## 📊 Reporting & Analytics

### Super Admin Reports
- System-wide school performance
- Revenue analytics across all schools
- User engagement metrics
- Growth trends and forecasting

### School Admin Reports
- Student enrollment trends
- Fee collection reports
- Teacher performance metrics
- Attendance analytics

### Teacher Reports
- Class-wise attendance reports
- Student performance analytics
- Assignment submission tracking
- Parent communication logs

### Parent Reports
- Child's academic progress
- Attendance summary
- Fee payment history
- Communication history with teachers

## 🌐 Deployment

### Production Deployment

1. **Build the application**
\`\`\`bash
npm run build
\`\`\`

2. **Set up production database**
\`\`\`bash
# Run migrations on production database
psql -h your-db-host -U your-db-user -d your-db-name -f scripts/database-schema.sql
\`\`\`

3. **Deploy to Vercel (Frontend)**
\`\`\`bash
vercel --prod
\`\`\`

4. **Deploy Backend (Railway/Heroku)**
\`\`\`bash
# Configure your deployment platform
# Set environment variables
# Deploy the server directory
\`\`\`

### Environment Configuration
Ensure all environment variables are properly set in production:
- Database connection strings
- JWT secrets
- SMS API credentials
- Payment gateway credentials
- Firebase configuration

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📝 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🆘 Support

For support and questions:
- Email: support@schoolmanagementsystem.com
- Documentation: [docs.schoolmanagementsystem.com](https://docs.schoolmanagementsystem.com)
- Issues: [GitHub Issues](https://github.com/your-repo/school-management-system/issues)

## 🎉 Acknowledgments

- Built with modern web technologies
- Designed for Bangladesh education system
- Supports Bengali language and local payment methods
- Mobile-first responsive design
- Scalable architecture for multiple schools

---

**Built with ❤️ for modern education management**
