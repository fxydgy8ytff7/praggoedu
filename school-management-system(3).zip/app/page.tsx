"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { BookOpen, Users, GraduationCap, UserCheck, Shield, Crown } from "lucide-react"

export default function LoginPage() {
  const [selectedRole, setSelectedRole] = useState<string>("")
  const [credentials, setCredentials] = useState({ username: "", password: "" })

  const roles = [
    {
      id: "student",
      name: "Student / ছাত্র-ছাত্রী",
      icon: BookOpen,
      path: "/student/dashboard",
      demo: { username: "student123", password: "demo123" },
    },
    {
      id: "teacher",
      name: "Teacher / শিক্ষক",
      icon: GraduationCap,
      path: "/teacher/dashboard",
      demo: { username: "teacher123", password: "demo123" },
    },
    {
      id: "parent",
      name: "Parent / অভিভাবক",
      icon: Users,
      path: "/parent/dashboard",
      demo: { username: "parent123", password: "demo123" },
    },
    {
      id: "admin",
      name: "Admin / প্রশাসক",
      icon: UserCheck,
      path: "/admin/dashboard",
      demo: { username: "admin123", password: "demo123" },
    },
    {
      id: "head-teacher",
      name: "Head Teacher / প্রধান শিক্ষক",
      icon: Crown,
      path: "/head-teacher/dashboard",
      demo: { username: "headteacher123", password: "demo123" },
    },
    {
      id: "super-admin",
      name: "Super Admin / সুপার প্রশাসক",
      icon: Shield,
      path: "/super-admin/dashboard",
      demo: { username: "superadmin123", password: "demo123" },
    },
  ]

  const handleLogin = () => {
    const role = roles.find((r) => r.id === selectedRole)
    if (role) {
      window.location.href = role.path
    }
  }

  const fillDemoCredentials = (role: any) => {
    setCredentials(role.demo)
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 via-blue-50 to-purple-50 flex items-center justify-center p-4">
      <div className="w-full max-w-6xl">
        {/* Header */}
        <div className="text-center mb-8">
          <div className="bd-gradient rounded-full w-20 h-20 mx-auto mb-4 flex items-center justify-center">
            <BookOpen className="w-10 h-10 text-white" />
          </div>
          <h1 className="text-4xl font-bold text-gray-800 mb-2 bd-text-shadow">School Management System</h1>
          <h2 className="text-2xl font-semibold text-gray-600 mb-4">স্কুল ব্যবস্থাপনা সিস্টেম</h2>
          <p className="text-gray-600 max-w-2xl mx-auto">
            Complete digital solution for Bangladesh educational institutions with bilingual support
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8">
          {/* Role Selection */}
          <Card className="bd-card-hover">
            <CardHeader>
              <CardTitle className="text-2xl text-center">Select Your Role / ভূমিকা নির্বাচন করুন</CardTitle>
              <CardDescription className="text-center">
                Choose your role to access the appropriate dashboard
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-3">
                {roles.map((role) => {
                  const Icon = role.icon
                  return (
                    <Button
                      key={role.id}
                      variant={selectedRole === role.id ? "default" : "outline"}
                      className="w-full h-16 text-left justify-start text-lg font-medium"
                      onClick={() => setSelectedRole(role.id)}
                    >
                      <Icon className="w-6 h-6 mr-3" />
                      {role.name}
                    </Button>
                  )
                })}
              </div>
            </CardContent>
          </Card>

          {/* Login Form */}
          <Card className="bd-card-hover">
            <CardHeader>
              <CardTitle className="text-2xl text-center">Login / লগইন</CardTitle>
              <CardDescription className="text-center">Enter your credentials to access the system</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="username" className="text-lg font-medium">
                  Username / ব্যবহারকারীর নাম
                </Label>
                <Input
                  id="username"
                  type="text"
                  placeholder="Enter your username"
                  value={credentials.username}
                  onChange={(e) => setCredentials({ ...credentials, username: e.target.value })}
                  className="h-12 text-lg"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-lg font-medium">
                  Password / পাসওয়ার্ড
                </Label>
                <Input
                  id="password"
                  type="password"
                  placeholder="Enter your password"
                  value={credentials.password}
                  onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
                  className="h-12 text-lg"
                />
              </div>

              {/* Demo Credentials */}
              {selectedRole && (
                <div className="bg-blue-50 p-4 rounded-lg border-2 border-blue-200">
                  <h4 className="font-semibold text-blue-800 mb-2">Demo Credentials:</h4>
                  <div className="text-sm text-blue-700 space-y-1">
                    <p>
                      <strong>Username:</strong> {roles.find((r) => r.id === selectedRole)?.demo.username}
                    </p>
                    <p>
                      <strong>Password:</strong> {roles.find((r) => r.id === selectedRole)?.demo.password}
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="mt-2 bg-transparent"
                    onClick={() => fillDemoCredentials(roles.find((r) => r.id === selectedRole))}
                  >
                    Fill Demo Credentials
                  </Button>
                </div>
              )}

              <Button
                onClick={handleLogin}
                disabled={!selectedRole || !credentials.username || !credentials.password}
                className="w-full h-12 text-lg font-semibold bd-gradient"
              >
                Login / লগইন করুন
              </Button>

              <div className="text-center text-sm text-gray-500">
                <p>Demo system - All credentials are for testing purposes</p>
                <p>ডেমো সিস্টেম - সকল তথ্য পরীক্ষার জন্য</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Features */}
        <div className="mt-12 grid md:grid-cols-3 gap-6">
          <Card className="text-center bd-card-hover">
            <CardContent className="pt-6">
              <Users className="w-12 h-12 mx-auto mb-4 text-blue-600" />
              <h3 className="font-semibold text-lg mb-2">Multi-Role Support</h3>
              <p className="text-gray-600">Students, Teachers, Parents, Admins</p>
            </CardContent>
          </Card>
          <Card className="text-center bd-card-hover">
            <CardContent className="pt-6">
              <BookOpen className="w-12 h-12 mx-auto mb-4 text-green-600" />
              <h3 className="font-semibold text-lg mb-2">Complete Management</h3>
              <p className="text-gray-600">Attendance, Grades, Homework, SMS</p>
            </CardContent>
          </Card>
          <Card className="text-center bd-card-hover">
            <CardContent className="pt-6">
              <GraduationCap className="w-12 h-12 mx-auto mb-4 text-purple-600" />
              <h3 className="font-semibold text-lg mb-2">Bangladesh Ready</h3>
              <p className="text-gray-600">Bilingual Support, Local Features</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
