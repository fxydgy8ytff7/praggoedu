"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { User, Calendar, FileText, Home, Bell, Users, DollarSign } from "lucide-react"

export default function ParentDashboard() {
  const [children] = useState([
    {
      id: 1,
      name: "Fatima Rahman",
      class: "Class 10-A",
      rollNumber: "15",
      attendance: 96,
      grade: "A-",
      percentage: 87.5,
    },
    {
      id: 2,
      name: "Ahmed Rahman",
      class: "Class 8-B",
      rollNumber: "22",
      attendance: 94,
      grade: "B+",
      percentage: 85.2,
    },
  ])

  const [recentActivities] = useState([
    { id: 1, child: "Fatima Rahman", activity: "Submitted Math assignment", time: "2 hours ago" },
    { id: 2, child: "Ahmed Rahman", activity: "Attended Science class", time: "4 hours ago" },
    { id: 3, child: "Fatima Rahman", activity: "Received grade for English essay", time: "1 day ago" },
    { id: 4, child: "Ahmed Rahman", activity: "Parent-teacher meeting scheduled", time: "2 days ago" },
  ])

  const [fees] = useState([
    { month: "January 2024", amount: 5000, status: "paid", dueDate: "2024-01-05" },
    { month: "February 2024", amount: 5000, status: "pending", dueDate: "2024-02-05" },
    { month: "March 2024", amount: 5000, status: "upcoming", dueDate: "2024-03-05" },
  ])

  const handleLogout = () => {
    localStorage.removeItem("userRole")
    localStorage.removeItem("isAuthenticated")
    window.location.href = "/edumanagement/"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 to-rose-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <Users className="h-8 w-8 text-pink-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Parent Dashboard</h1>
                <p className="text-sm text-gray-600">Welcome back, Mr. Rahman</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm">
                <Bell className="h-4 w-4 mr-2" />
                Notifications
              </Button>
              <Button variant="outline" onClick={handleLogout}>
                <Home className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Children Overview */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          {children.map((child) => (
            <Card key={child.id} className="bg-gradient-to-r from-pink-500 to-rose-500 text-white">
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>{child.name}</span>
                  <User className="h-5 w-5" />
                </CardTitle>
                <CardDescription className="text-pink-100">
                  {child.class} • Roll: {child.rollNumber}
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-3 gap-4 text-center">
                  <div>
                    <div className="text-2xl font-bold">{child.attendance}%</div>
                    <div className="text-xs text-pink-100">Attendance</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold">{child.grade}</div>
                    <div className="text-xs text-pink-100">Grade</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold">{child.percentage}%</div>
                    <div className="text-xs text-pink-100">Average</div>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="attendance">Attendance</TabsTrigger>
            <TabsTrigger value="grades">Grades</TabsTrigger>
            <TabsTrigger value="fees">Fees</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Recent Activities */}
              <Card>
                <CardHeader>
                  <CardTitle>Recent Activities</CardTitle>
                  <CardDescription>Latest updates about your children</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentActivities.map((activity) => (
                      <div key={activity.id} className="flex items-start space-x-3">
                        <div className="flex-shrink-0">
                          <User className="h-5 w-5 text-pink-500" />
                        </div>
                        <div className="flex-1 min-w-0">
                          <p className="text-sm font-medium text-gray-900">{activity.child}</p>
                          <p className="text-sm text-gray-600">{activity.activity}</p>
                          <p className="text-xs text-gray-500">{activity.time}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                  <CardDescription>Common parent tasks</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <Button className="h-20 flex flex-col items-center justify-center space-y-2">
                      <Calendar className="h-6 w-6" />
                      <span className="text-sm">Schedule Meeting</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col items-center justify-center space-y-2 bg-transparent"
                    >
                      <DollarSign className="h-6 w-6" />
                      <span className="text-sm">Pay Fees</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col items-center justify-center space-y-2 bg-transparent"
                    >
                      <FileText className="h-6 w-6" />
                      <span className="text-sm">View Reports</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col items-center justify-center space-y-2 bg-transparent"
                    >
                      <Bell className="h-6 w-6" />
                      <span className="text-sm">Notifications</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="attendance" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {children.map((child) => (
                <Card key={child.id}>
                  <CardHeader>
                    <CardTitle>{child.name} - Attendance</CardTitle>
                    <CardDescription>{child.class}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span>This Month</span>
                        <span className="font-semibold">{child.attendance}%</span>
                      </div>
                      <Progress value={child.attendance} />
                      <div className="text-sm text-gray-600">
                        <p>Present: 24 days</p>
                        <p>Absent: 1 day</p>
                        <p>Late: 0 days</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="grades" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {children.map((child) => (
                <Card key={child.id}>
                  <CardHeader>
                    <CardTitle>{child.name} - Academic Performance</CardTitle>
                    <CardDescription>{child.class}</CardDescription>
                  </CardHeader>
                  <CardContent>
                    <div className="space-y-4">
                      <div className="flex justify-between items-center">
                        <span>Overall Grade</span>
                        <Badge variant="default">{child.grade}</Badge>
                      </div>
                      <div className="flex justify-between items-center">
                        <span>Percentage</span>
                        <span className="font-semibold">{child.percentage}%</span>
                      </div>
                      <Progress value={child.percentage} />
                      <div className="grid grid-cols-2 gap-4 text-sm">
                        <div>
                          <p className="font-medium">Mathematics: A</p>
                          <p className="font-medium">Physics: B+</p>
                        </div>
                        <div>
                          <p className="font-medium">English: A-</p>
                          <p className="font-medium">Chemistry: B</p>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </TabsContent>

          <TabsContent value="fees" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Fee Management</CardTitle>
                <CardDescription>Track and manage school fees</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {fees.map((fee, index) => (
                    <div key={index} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <h3 className="font-semibold text-gray-900">{fee.month}</h3>
                        <p className="text-sm text-gray-600">Due: {fee.dueDate}</p>
                        <p className="text-sm font-medium">৳{fee.amount}</p>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Badge
                          variant={
                            fee.status === "paid" ? "default" : fee.status === "pending" ? "destructive" : "secondary"
                          }
                        >
                          {fee.status.charAt(0).toUpperCase() + fee.status.slice(1)}
                        </Badge>
                        {fee.status === "pending" && <Button size="sm">Pay Now</Button>}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
