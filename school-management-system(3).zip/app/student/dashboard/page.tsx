"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookOpen, Calendar, CheckCircle, Clock, FileText, Home, User, Bell, Award } from "lucide-react"

export default function StudentDashboard() {
  const [todaySchedule] = useState([
    { id: 1, subject: "Mathematics", teacher: "Mr. Rahman", time: "9:00 AM", room: "Room 101", status: "completed" },
    { id: 2, subject: "Physics", teacher: "Ms. Khan", time: "10:30 AM", room: "Lab 1", status: "ongoing" },
    { id: 3, subject: "English", teacher: "Mrs. Ahmed", time: "2:00 PM", room: "Room 205", status: "upcoming" },
    { id: 4, subject: "Chemistry", teacher: "Dr. Hassan", time: "3:30 PM", room: "Lab 2", status: "upcoming" },
  ])

  const [assignments] = useState([
    { id: 1, subject: "Mathematics", title: "Algebra Problems", dueDate: "2024-01-15", status: "pending" },
    { id: 2, subject: "Physics", title: "Lab Report", dueDate: "2024-01-18", status: "submitted" },
    { id: 3, subject: "English", title: "Essay Writing", dueDate: "2024-01-20", status: "pending" },
  ])

  const [grades] = useState([
    { subject: "Mathematics", grade: "A", percentage: 92 },
    { subject: "Physics", grade: "B+", percentage: 87 },
    { subject: "English", grade: "A-", percentage: 89 },
    { subject: "Chemistry", grade: "B", percentage: 82 },
  ])

  const handleLogout = () => {
    localStorage.removeItem("userRole")
    localStorage.removeItem("isAuthenticated")
    window.location.href = "/edumanagement/"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-pink-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <User className="h-8 w-8 text-purple-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Student Dashboard</h1>
                <p className="text-sm text-gray-600">Welcome back, Fatima Rahman</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm">
                <Bell className="h-4 w-4 mr-2" />
                Notifications
              </Button>
              <Button variant="outline" onClick={handleLogout}>
                <Home className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Quick Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Classes</CardTitle>
              <Calendar className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">4</div>
              <p className="text-xs text-purple-100">2 completed, 2 upcoming</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Assignments</CardTitle>
              <FileText className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3</div>
              <p className="text-xs text-blue-100">2 pending, 1 submitted</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Attendance</CardTitle>
              <CheckCircle className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">96%</div>
              <p className="text-xs text-green-100">This month</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Overall Grade</CardTitle>
              <Award className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">A-</div>
              <p className="text-xs text-orange-100">87.5% average</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="schedule" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="schedule">Today's Schedule</TabsTrigger>
            <TabsTrigger value="assignments">Assignments</TabsTrigger>
            <TabsTrigger value="grades">Grades</TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="schedule" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Today's Classes</CardTitle>
                <CardDescription>Your schedule for today</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {todaySchedule.map((classItem) => (
                    <div key={classItem.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="flex-shrink-0">
                          <BookOpen className="h-8 w-8 text-purple-500" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{classItem.subject}</h3>
                          <p className="text-sm text-gray-600">{classItem.teacher}</p>
                          <p className="text-sm text-gray-500">
                            {classItem.time} • {classItem.room}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Badge
                          variant={
                            classItem.status === "completed"
                              ? "default"
                              : classItem.status === "ongoing"
                                ? "destructive"
                                : "secondary"
                          }
                        >
                          {classItem.status === "completed" && <CheckCircle className="h-3 w-3 mr-1" />}
                          {classItem.status === "ongoing" && <Clock className="h-3 w-3 mr-1" />}
                          {classItem.status.charAt(0).toUpperCase() + classItem.status.slice(1)}
                        </Badge>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="assignments" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>My Assignments</CardTitle>
                <CardDescription>Track your homework and submissions</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {assignments.map((assignment) => (
                    <div key={assignment.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div className="flex items-center space-x-4">
                        <div className="flex-shrink-0">
                          <FileText className="h-8 w-8 text-blue-500" />
                        </div>
                        <div>
                          <h3 className="font-semibold text-gray-900">{assignment.title}</h3>
                          <p className="text-sm text-gray-600">{assignment.subject}</p>
                          <p className="text-sm text-gray-500">Due: {assignment.dueDate}</p>
                        </div>
                      </div>
                      <div className="flex items-center space-x-3">
                        <Badge variant={assignment.status === "submitted" ? "default" : "destructive"}>
                          {assignment.status === "submitted" ? "Submitted" : "Pending"}
                        </Badge>
                        {assignment.status === "pending" && <Button size="sm">Submit</Button>}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="grades" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Academic Performance</CardTitle>
                <CardDescription>Your grades and progress</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  {grades.map((grade, index) => (
                    <div key={index} className="border rounded-lg p-4">
                      <div className="flex justify-between items-center mb-3">
                        <div>
                          <h3 className="font-semibold text-gray-900">{grade.subject}</h3>
                          <p className="text-sm text-gray-600">Current Grade: {grade.grade}</p>
                        </div>
                        <div className="text-right">
                          <div className="text-2xl font-bold text-gray-900">{grade.percentage}%</div>
                        </div>
                      </div>
                      <Progress value={grade.percentage} className="h-2" />
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="profile" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Student Profile</CardTitle>
                <CardDescription>Your personal information</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6">
                  <div className="flex items-center space-x-4">
                    <div className="w-20 h-20 bg-purple-100 rounded-full flex items-center justify-center">
                      <User className="h-10 w-10 text-purple-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-semibold">Fatima Rahman</h3>
                      <p className="text-gray-600">Student ID: 2024001</p>
                      <p className="text-gray-600">Class: 10-A</p>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div>
                      <h4 className="font-semibold mb-2">Contact Information</h4>
                      <p className="text-sm text-gray-600">Email: fatima.rahman@school.edu</p>
                      <p className="text-sm text-gray-600">Phone: +880 1234-567890</p>
                    </div>
                    <div>
                      <h4 className="font-semibold mb-2">Academic Info</h4>
                      <p className="text-sm text-gray-600">Roll Number: 15</p>
                      <p className="text-sm text-gray-600">Section: A</p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
