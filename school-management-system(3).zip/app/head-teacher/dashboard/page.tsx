"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Crown,
  Users,
  GraduationCap,
  TrendingUp,
  Calendar,
  MessageSquare,
  Home,
  Bell,
  FileText,
  Award,
} from "lucide-react"

export default function HeadTeacherDashboard() {
  const [schoolStats] = useState({
    totalStudents: 1250,
    totalTeachers: 85,
    attendanceRate: 94.5,
    examResults: 87.2,
    pendingApprovals: 12,
    activeEvents: 5,
  })

  const [pendingApprovals] = useState([
    { id: 1, type: "leave", teacher: "Ms. Fatima Khan", reason: "Medical leave", date: "2024-01-15" },
    { id: 2, type: "event", title: "Science Fair", requestedBy: "Mr. Ahmed", date: "2024-01-20" },
    { id: 3, type: "budget", title: "Lab Equipment", amount: "৳50,000", department: "Science" },
  ])

  const handleLogout = () => {
    localStorage.removeItem("userRole")
    localStorage.removeItem("isAuthenticated")
    window.location.href = "/edumanagement/"
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-yellow-50 to-orange-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center py-4">
            <div className="flex items-center space-x-3">
              <Crown className="h-8 w-8 text-yellow-600" />
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Head Teacher Dashboard</h1>
                <p className="text-sm text-gray-600">Welcome back, Dr. Rashida Begum</p>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button variant="outline" size="sm">
                <Bell className="h-4 w-4 mr-2" />
                Notifications
                {schoolStats.pendingApprovals > 0 && (
                  <Badge className="ml-2 bg-red-500">{schoolStats.pendingApprovals}</Badge>
                )}
              </Button>
              <Button variant="outline" onClick={handleLogout}>
                <Home className="h-4 w-4 mr-2" />
                Logout
              </Button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* School Stats */}
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-6 gap-6 mb-8">
          <Card className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Students</CardTitle>
              <Users className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{schoolStats.totalStudents}</div>
              <p className="text-xs text-yellow-100">Total enrolled</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Teachers</CardTitle>
              <GraduationCap className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{schoolStats.totalTeachers}</div>
              <p className="text-xs text-blue-100">Faculty members</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Attendance</CardTitle>
              <TrendingUp className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{schoolStats.attendanceRate}%</div>
              <p className="text-xs text-green-100">This month</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Results</CardTitle>
              <Award className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{schoolStats.examResults}%</div>
              <p className="text-xs text-purple-100">Pass rate</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Approvals</CardTitle>
              <FileText className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{schoolStats.pendingApprovals}</div>
              <p className="text-xs text-red-100">Pending</p>
            </CardContent>
          </Card>

          <Card className="bg-gradient-to-r from-teal-500 to-teal-600 text-white">
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Events</CardTitle>
              <Calendar className="h-4 w-4" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{schoolStats.activeEvents}</div>
              <p className="text-xs text-teal-100">This month</p>
            </CardContent>
          </Card>
        </div>

        {/* Main Content */}
        <Tabs defaultValue="overview" className="space-y-6">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="approvals">Approvals</TabsTrigger>
            <TabsTrigger value="teachers">Teachers</TabsTrigger>
            <TabsTrigger value="communication">Communication</TabsTrigger>
          </TabsList>

          <TabsContent value="overview" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* School Performance */}
              <Card>
                <CardHeader>
                  <CardTitle>School Performance</CardTitle>
                  <CardDescription>Key metrics and trends</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Student Attendance</span>
                        <span>{schoolStats.attendanceRate}%</span>
                      </div>
                      <Progress value={schoolStats.attendanceRate} />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Teacher Attendance</span>
                        <span>96.8%</span>
                      </div>
                      <Progress value={96.8} />
                    </div>
                    <div>
                      <div className="flex justify-between text-sm mb-1">
                        <span>Exam Results</span>
                        <span>{schoolStats.examResults}%</span>
                      </div>
                      <Progress value={schoolStats.examResults} />
                    </div>
                  </div>
                </CardContent>
              </Card>

              {/* Quick Actions */}
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                  <CardDescription>Common administrative tasks</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <Button className="h-20 flex flex-col items-center justify-center space-y-2">
                      <MessageSquare className="h-6 w-6" />
                      <span className="text-sm">Send SMS</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col items-center justify-center space-y-2 bg-transparent"
                    >
                      <Calendar className="h-6 w-6" />
                      <span className="text-sm">Schedule Event</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col items-center justify-center space-y-2 bg-transparent"
                    >
                      <FileText className="h-6 w-6" />
                      <span className="text-sm">Generate Report</span>
                    </Button>
                    <Button
                      variant="outline"
                      className="h-20 flex flex-col items-center justify-center space-y-2 bg-transparent"
                    >
                      <TrendingUp className="h-6 w-6" />
                      <span className="text-sm">View Analytics</span>
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          <TabsContent value="approvals" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Pending Approvals</CardTitle>
                <CardDescription>Items requiring your approval</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  {pendingApprovals.map((approval) => (
                    <div key={approval.id} className="flex items-center justify-between p-4 border rounded-lg">
                      <div>
                        <h3 className="font-semibold text-gray-900">
                          {approval.type === "leave" && `Leave Request - ${approval.teacher}`}
                          {approval.type === "event" && `Event Request - ${approval.title}`}
                          {approval.type === "budget" && `Budget Request - ${approval.title}`}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {approval.reason || approval.requestedBy || approval.department}
                        </p>
                        <p className="text-sm text-gray-500">
                          {approval.date} {approval.amount && `• ${approval.amount}`}
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        <Button size="sm" variant="outline">
                          Reject
                        </Button>
                        <Button size="sm">Approve</Button>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="teachers" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Teacher Management</CardTitle>
                <CardDescription>Manage faculty and staff</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <GraduationCap className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Teacher Management</h3>
                  <p className="text-gray-600 mb-4">Manage teacher profiles, schedules, and performance</p>
                  <Button>View All Teachers</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="communication" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Communication Center</CardTitle>
                <CardDescription>Send messages and announcements</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="text-center py-12">
                  <MessageSquare className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">SMS & Communication</h3>
                  <p className="text-gray-600 mb-4">Send messages to students, teachers, and parents</p>
                  <Button>Open Communication Panel</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
