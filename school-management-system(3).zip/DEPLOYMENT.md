# GitHub Pages Deployment Guide

This guide will help you deploy the School Management System to GitHub Pages.

## Prerequisites

1. A GitHub account
2. The repository should be named `edumanagement`
3. The repository should be public (required for free GitHub Pages)

## Deployment Steps

### 1. Repository Setup

1. Create a new repository named `edumanagement` on GitHub
2. Push your code to the `main` branch

### 2. Enable GitHub Pages

1. Go to your repository on GitHub
2. Click on **Settings** tab
3. Scroll down to **Pages** section in the left sidebar
4. Under **Source**, select **GitHub Actions**

### 3. Automatic Deployment

The GitHub Actions workflow (`.github/workflows/deploy.yml`) will automatically:
- Build the Next.js application
- Export it as static files
- Deploy to GitHub Pages

### 4. Access Your Site

After successful deployment, your site will be available at:
\`\`\`
https://8ytgggygt.github.io/edumanagement/
\`\`\`

## Configuration Details

### Next.js Configuration

The `next.config.mjs` file is configured for static export:

\`\`\`javascript
const nextConfig = {
  output: 'export',
  trailingSlash: true,
  basePath: '/edumanagement',
  assetPrefix: '/edumanagement/',
  // ... other configurations
}
\`\`\`

### GitHub Actions Workflow

The deployment workflow:
1. Triggers on push to `main` branch
2. Sets up Node.js environment
3. Installs dependencies
4. Builds the application
5. Deploys to `gh-pages` branch

## Troubleshooting

### Common Issues

1. **404 Error**: Make sure GitHub Pages is enabled and the workflow completed successfully
2. **Build Failures**: Check the Actions tab for build logs
3. **Asset Loading Issues**: Ensure `basePath` and `assetPrefix` are correctly set

### Manual Deployment

If automatic deployment fails, you can deploy manually:

\`\`\`bash
# Build the application
npm run build

# The built files will be in the 'out' directory
# Upload these files to the gh-pages branch
\`\`\`

## Demo Credentials

Once deployed, you can test the system with these credentials:

- **Super Admin**: superadmin / admin123
- **School Admin**: admin / admin123
- **Head Teacher**: headteacher / head123
- **Teacher**: teacher / teacher123
- **Student**: student / student123
- **Parent**: parent / parent123

## Features Available

✅ **Multi-role Authentication**
✅ **Responsive Design**
✅ **Bilingual Support (English/Bangla)**
✅ **Interactive Dashboards**
✅ **Demo Data Pre-loaded**
✅ **Modern UI Components**

## Support

If you encounter any issues:
1. Check the GitHub Actions logs
2. Ensure all files are properly committed
3. Verify the repository settings
4. Contact support if needed

---

**Note**: This is a demo version. For production use, you'll need to set up a proper backend and database.
