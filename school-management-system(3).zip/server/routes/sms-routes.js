// SMS Routes for Head Teacher Panel
const express = require("express")
const router = express.Router()
const SMSService = require("../services/sms-service")
const { authenticateToken, authorize } = require("../middleware/auth")
const { body, validationResult } = require("express-validator")

const smsService = new SMSService()

// Send SMS - Head Teacher only
router.post(
  "/send",
  authenticateToken,
  authorize(["head_teacher", "admin"]),
  [
    body("recipients").isObject().withMessage("Recipients must be an object"),
    body("recipients.type").isIn([
      "students",
      "guardians",
      "teachers",
      "class",
      "all_students",
      "all_guardians",
      "all_teachers",
    ]),
    body("recipients.ids").isArray().withMessage("Recipient IDs must be an array"),
    body("message").isLength({ min: 1, max: 1000 }).withMessage("Message must be between 1 and 1000 characters"),
    body("messageType").optional().isString(),
    body("templateType").optional().isString(),
    body("priority").optional().isIn(["low", "normal", "high", "urgent"]),
    body("scheduledAt").optional().isISO8601(),
    body("provider").optional().isIn(["muthofun", "bulksmsbd", "twilio"]),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const {
        recipients,
        message,
        messageType = "custom",
        templateType = null,
        priority = "normal",
        scheduledAt = null,
        provider = "muthofun",
      } = req.body

      const result = await smsService.sendSMS({
        senderId: req.user.id,
        recipients,
        message,
        messageType,
        templateType,
        priority,
        scheduledAt,
        provider,
      })

      res.json({
        success: true,
        message: scheduledAt ? "Message scheduled successfully" : "Message sent successfully",
        data: result,
      })
    } catch (error) {
      console.error("SMS send error:", error)
      res.status(500).json({
        success: false,
        message: "Failed to send SMS",
        error: error.message,
      })
    }
  },
)

// Get message templates
router.get("/templates", authenticateToken, authorize(["head_teacher", "admin", "teacher"]), async (req, res) => {
  try {
    const templates = await smsService.getMessageTemplates()
    res.json({
      success: true,
      data: templates,
    })
  } catch (error) {
    console.error("Get templates error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to get templates",
      error: error.message,
    })
  }
})

// Get SMS statistics
router.get("/statistics", authenticateToken, authorize(["head_teacher", "admin"]), async (req, res) => {
  try {
    const { timeRange = "30 days" } = req.query
    const schoolId = req.user.schoolId

    const stats = await smsService.getSMSStatistics(schoolId, timeRange)
    res.json({
      success: true,
      data: stats,
    })
  } catch (error) {
    console.error("Get SMS statistics error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to get SMS statistics",
      error: error.message,
    })
  }
})

// Get message logs
router.get("/logs", authenticateToken, authorize(["head_teacher", "admin"]), async (req, res) => {
  try {
    const { page = 1, limit = 20, status = null, messageType = null, startDate = null, endDate = null } = req.query

    const schoolId = req.user.schoolId

    const logs = await smsService.getMessageLogs(schoolId, {
      page: Number.parseInt(page),
      limit: Number.parseInt(limit),
      status,
      messageType,
      startDate,
      endDate,
    })

    res.json({
      success: true,
      data: logs,
    })
  } catch (error) {
    console.error("Get message logs error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to get message logs",
      error: error.message,
    })
  }
})

// Get recipients by type and filters
router.post(
  "/recipients",
  authenticateToken,
  authorize(["head_teacher", "admin", "teacher"]),
  [
    body("type").isIn(["students", "guardians", "teachers", "class", "all_students", "all_guardians", "all_teachers"]),
    body("filters").optional().isObject(),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { type, filters = {} } = req.body
      const schoolId = req.user.schoolId

      let query
      const values = [schoolId]
      let paramCount = 1

      switch (type) {
        case "students":
          query = `
            SELECT s.id, u.name, u.phone, c.name as class_name, sec.name as section_name
            FROM students s
            JOIN users u ON s.user_id = u.id
            LEFT JOIN classes c ON s.class_id = c.id
            LEFT JOIN sections sec ON s.section_id = sec.id
            WHERE u.school_id = $1 AND u.phone IS NOT NULL
          `
          break

        case "guardians":
          query = `
            SELECT DISTINCT g.id, u.name, u.phone
            FROM guardians g
            JOIN users u ON g.user_id = u.id
            WHERE u.school_id = $1 AND u.phone IS NOT NULL
          `
          break

        case "teachers":
          query = `
            SELECT t.id, u.name, u.phone, t.department, t.designation
            FROM teachers t
            JOIN users u ON t.user_id = u.id
            WHERE u.school_id = $1 AND u.phone IS NOT NULL
          `
          break

        case "class":
          if (filters.classId && filters.sectionId) {
            paramCount += 2
            query = `
              SELECT s.id, u.name, u.phone, s.roll_number
              FROM students s
              JOIN users u ON s.user_id = u.id
              WHERE u.school_id = $1 AND s.class_id = $2 AND s.section_id = $3 AND u.phone IS NOT NULL
            `
            values.push(filters.classId, filters.sectionId)
          } else {
            return res.status(400).json({
              success: false,
              message: "Class ID and Section ID are required for class type",
            })
          }
          break

        default:
          return res.status(400).json({
            success: false,
            message: "Invalid recipient type",
          })
      }

      // Apply additional filters
      if (filters.gender) {
        paramCount++
        query += ` AND s.gender = $${paramCount}`
        values.push(filters.gender)
      }

      if (filters.attendanceStatus === "absent") {
        query += ` AND s.id IN (
          SELECT student_id FROM attendance 
          WHERE date = CURRENT_DATE AND status = 'absent'
        )`
      } else if (filters.attendanceStatus === "low_attendance") {
        query += ` AND s.id IN (
          SELECT student_id FROM attendance 
          WHERE date >= CURRENT_DATE - INTERVAL '30 days'
          GROUP BY student_id
          HAVING (COUNT(CASE WHEN status = 'present' THEN 1 END)::float / COUNT(*)) < 0.8
        )`
      }

      query += " ORDER BY u.name"

      const result = await smsService.pool.query(query, values)

      res.json({
        success: true,
        data: {
          recipients: result.rows,
          count: result.rows.length,
        },
      })
    } catch (error) {
      console.error("Get recipients error:", error)
      res.status(500).json({
        success: false,
        message: "Failed to get recipients",
        error: error.message,
      })
    }
  },
)

// Retry failed message
router.post("/retry/:messageLogId", authenticateToken, authorize(["head_teacher", "admin"]), async (req, res) => {
  try {
    const { messageLogId } = req.params
    const { provider = "muthofun" } = req.body

    // Get original message details
    const query = `
        SELECT * FROM message_logs 
        WHERE id = $1 AND delivery_status = 'failed'
      `
    const result = await smsService.pool.query(query, [messageLogId])

    if (result.rows.length === 0) {
      return res.status(404).json({
        success: false,
        message: "Failed message not found",
      })
    }

    const originalMessage = result.rows[0]

    // Retry sending
    const retryResult = await smsService.sendImmediate({
      messageLogId,
      recipients: {
        type: originalMessage.recipient_type,
        ids: JSON.parse(originalMessage.recipient_ids),
      },
      message: originalMessage.message,
      provider,
    })

    res.json({
      success: true,
      message: "Message retry initiated",
      data: retryResult,
    })
  } catch (error) {
    console.error("Retry message error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to retry message",
      error: error.message,
    })
  }
})

// Cancel scheduled message
router.delete(
  "/scheduled/:scheduledMessageId",
  authenticateToken,
  authorize(["head_teacher", "admin"]),
  async (req, res) => {
    try {
      const { scheduledMessageId } = req.params

      const query = `
        UPDATE scheduled_messages 
        SET status = 'cancelled', updated_at = CURRENT_TIMESTAMP
        WHERE id = $1 AND status = 'scheduled'
        RETURNING *
      `

      const result = await smsService.pool.query(query, [scheduledMessageId])

      if (result.rows.length === 0) {
        return res.status(404).json({
          success: false,
          message: "Scheduled message not found or already processed",
        })
      }

      res.json({
        success: true,
        message: "Scheduled message cancelled successfully",
      })
    } catch (error) {
      console.error("Cancel scheduled message error:", error)
      res.status(500).json({
        success: false,
        message: "Failed to cancel scheduled message",
        error: error.message,
      })
    }
  },
)

// Get scheduled messages
router.get("/scheduled", authenticateToken, authorize(["head_teacher", "admin"]), async (req, res) => {
  try {
    const { page = 1, limit = 20, status = "scheduled" } = req.query
    const offset = (page - 1) * limit
    const schoolId = req.user.schoolId

    const query = `
        SELECT sm.*, u.name as sender_name
        FROM scheduled_messages sm
        JOIN users u ON sm.sender_id = u.id
        WHERE u.school_id = $1 AND sm.status = $2
        ORDER BY sm.scheduled_at ASC
        LIMIT $3 OFFSET $4
      `

    const result = await smsService.pool.query(query, [schoolId, status, limit, offset])

    // Get total count
    const countQuery = `
        SELECT COUNT(*) as total
        FROM scheduled_messages sm
        JOIN users u ON sm.sender_id = u.id
        WHERE u.school_id = $1 AND sm.status = $2
      `

    const countResult = await smsService.pool.query(countQuery, [schoolId, status])

    res.json({
      success: true,
      data: {
        messages: result.rows,
        total: Number.parseInt(countResult.rows[0].total),
        page: Number.parseInt(page),
        totalPages: Math.ceil(countResult.rows[0].total / limit),
      },
    })
  } catch (error) {
    console.error("Get scheduled messages error:", error)
    res.status(500).json({
      success: false,
      message: "Failed to get scheduled messages",
      error: error.message,
    })
  }
})

module.exports = router
