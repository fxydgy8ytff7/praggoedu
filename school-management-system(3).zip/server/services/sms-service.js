// SMS Service for School Management System
// Supports multiple SMS providers (Muthofun, BulkSMSBD, Twilio)

const axios = require("axios")
const { Pool } = require("pg")

class SMSService {
  constructor() {
    this.pool = new Pool({
      connectionString: process.env.DATABASE_URL,
    })
    this.providers = {
      muthofun: this.sendViaMuthofun.bind(this),
      bulksmsbd: this.sendViaBulkSMSBD.bind(this),
      twilio: this.sendViaTwilio.bind(this),
    }
  }

  // Main method to send SMS
  async sendSMS(options) {
    const {
      senderId,
      recipients,
      message,
      messageType = "custom",
      templateType = null,
      priority = "normal",
      scheduledAt = null,
      provider = process.env.SMS_PROVIDER || "muthofun",
    } = options

    try {
      // Create message log entry
      const messageLogId = await this.createMessageLog({
        senderId,
        recipients,
        message,
        messageType,
        templateType,
        priority,
        scheduledAt,
        provider,
      })

      // If scheduled, save to scheduled_messages table
      if (scheduledAt) {
        await this.scheduleMessage({
          messageLogId,
          senderId,
          recipients,
          message,
          messageType,
          templateType,
          scheduledAt,
          provider,
        })
        return { success: true, messageLogId, status: "scheduled" }
      }

      // Send immediately
      const result = await this.sendImmediate({
        messageLogId,
        recipients,
        message,
        provider,
      })

      return result
    } catch (error) {
      console.error("SMS Service Error:", error)
      throw error
    }
  }

  // Create message log entry
  async createMessageLog(options) {
    const { senderId, recipients, message, messageType, templateType, priority, scheduledAt, provider } = options

    const query = `
      INSERT INTO message_logs (
        sender_id, recipient_type, recipient_ids, message_type, 
        template_type, message, total_recipients, delivery_status, 
        provider, scheduled_at
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10)
      RETURNING id
    `

    const values = [
      senderId,
      recipients.type,
      JSON.stringify(recipients.ids),
      messageType,
      templateType,
      message,
      recipients.ids.length,
      scheduledAt ? "scheduled" : "pending",
      provider,
      scheduledAt,
    ]

    const result = await this.pool.query(query, values)
    return result.rows[0].id
  }

  // Schedule message for later sending
  async scheduleMessage(options) {
    const { messageLogId, senderId, recipients, message, messageType, templateType, scheduledAt, provider } = options

    const query = `
      INSERT INTO scheduled_messages (
        sender_id, recipient_type, recipient_ids, message_type,
        template_type, message, scheduled_at, message_log_id
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
    `

    const values = [
      senderId,
      recipients.type,
      JSON.stringify(recipients.ids),
      messageType,
      templateType,
      message,
      scheduledAt,
      messageLogId,
    ]

    await this.pool.query(query, values)
  }

  // Send SMS immediately
  async sendImmediate(options) {
    const { messageLogId, recipients, message, provider } = options

    try {
      // Update status to sending
      await this.updateMessageLogStatus(messageLogId, "sending")

      // Get phone numbers for recipients
      const phoneNumbers = await this.getRecipientPhoneNumbers(recipients)

      // Send via selected provider
      const sendFunction = this.providers[provider]
      if (!sendFunction) {
        throw new Error(`Unsupported SMS provider: ${provider}`)
      }

      const result = await sendFunction(phoneNumbers, message)

      // Update message log with results
      await this.updateMessageLogResults(messageLogId, result)

      return {
        success: true,
        messageLogId,
        status: result.success ? "sent" : "failed",
        sentCount: result.sentCount,
        failedCount: result.failedCount,
        cost: result.cost,
      }
    } catch (error) {
      await this.updateMessageLogStatus(messageLogId, "failed")
      throw error
    }
  }

  // Get phone numbers for recipients
  async getRecipientPhoneNumbers(recipients) {
    const { type, ids } = recipients
    let query
    let values

    switch (type) {
      case "students":
        query = `
          SELECT DISTINCT u.phone 
          FROM users u 
          JOIN students s ON u.id = s.user_id 
          WHERE s.id = ANY($1) AND u.phone IS NOT NULL
        `
        values = [ids]
        break

      case "guardians":
        query = `
          SELECT DISTINCT u.phone 
          FROM users u 
          JOIN guardians g ON u.id = g.user_id 
          WHERE g.id = ANY($1) AND u.phone IS NOT NULL
        `
        values = [ids]
        break

      case "teachers":
        query = `
          SELECT DISTINCT u.phone 
          FROM users u 
          JOIN teachers t ON u.id = t.user_id 
          WHERE t.id = ANY($1) AND u.phone IS NOT NULL
        `
        values = [ids]
        break

      case "class":
        query = `
          SELECT DISTINCT u.phone 
          FROM users u 
          JOIN students s ON u.id = s.user_id 
          WHERE s.class_id = $1 AND s.section_id = $2 AND u.phone IS NOT NULL
        `
        values = [ids[0], ids[1]] // [classId, sectionId]
        break

      case "all_students":
        query = `
          SELECT DISTINCT u.phone 
          FROM users u 
          JOIN students s ON u.id = s.user_id 
          WHERE u.phone IS NOT NULL
        `
        values = []
        break

      case "all_guardians":
        query = `
          SELECT DISTINCT u.phone 
          FROM users u 
          JOIN guardians g ON u.id = g.user_id 
          WHERE u.phone IS NOT NULL
        `
        values = []
        break

      case "all_teachers":
        query = `
          SELECT DISTINCT u.phone 
          FROM users u 
          JOIN teachers t ON u.id = t.user_id 
          WHERE u.phone IS NOT NULL
        `
        values = []
        break

      default:
        throw new Error(`Unsupported recipient type: ${type}`)
    }

    const result = await this.pool.query(query, values)
    return result.rows.map((row) => row.phone).filter((phone) => phone)
  }

  // Muthofun SMS Provider
  async sendViaMuthofun(phoneNumbers, message) {
    const apiKey = process.env.MUTHOFUN_API_KEY
    const apiSecret = process.env.MUTHOFUN_API_SECRET
    const senderId = process.env.MUTHOFUN_SENDER_ID || "SCHOOL"

    if (!apiKey || !apiSecret) {
      throw new Error("Muthofun API credentials not configured")
    }

    const url = "https://api.muthofun.com/api/v1/send-sms"

    let sentCount = 0
    let failedCount = 0
    const responses = []

    // Send in batches to avoid rate limiting
    const batchSize = 100
    for (let i = 0; i < phoneNumbers.length; i += batchSize) {
      const batch = phoneNumbers.slice(i, i + batchSize)

      try {
        const response = await axios.post(
          url,
          {
            api_key: apiKey,
            api_secret: apiSecret,
            request_type: "SINGLE_SMS",
            message_type: "TEXT",
            mobile: batch.join(","),
            message_body: message,
            sender_id: senderId,
          },
          {
            headers: {
              "Content-Type": "application/json",
            },
            timeout: 30000,
          },
        )

        if (response.data.success) {
          sentCount += batch.length
        } else {
          failedCount += batch.length
        }

        responses.push(response.data)
      } catch (error) {
        failedCount += batch.length
        responses.push({ error: error.message })
      }
    }

    return {
      success: sentCount > 0,
      sentCount,
      failedCount,
      cost: sentCount * 0.5, // Assuming 0.5 BDT per SMS
      providerResponse: responses,
    }
  }

  // BulkSMSBD Provider
  async sendViaBulkSMSBD(phoneNumbers, message) {
    const apiKey = process.env.BULKSMSBD_API_KEY
    const senderId = process.env.BULKSMSBD_SENDER_ID || "SCHOOL"

    if (!apiKey) {
      throw new Error("BulkSMSBD API credentials not configured")
    }

    const url = "https://api.bulksmsbd.com/api/smsapi"

    let sentCount = 0
    let failedCount = 0
    const responses = []

    for (const phone of phoneNumbers) {
      try {
        const response = await axios.post(url, {
          api_key: apiKey,
          type: "text",
          number: phone,
          senderid: senderId,
          message: message,
        })

        if (response.data.response_code === 202) {
          sentCount++
        } else {
          failedCount++
        }

        responses.push(response.data)
      } catch (error) {
        failedCount++
        responses.push({ error: error.message })
      }
    }

    return {
      success: sentCount > 0,
      sentCount,
      failedCount,
      cost: sentCount * 0.6, // Assuming 0.6 BDT per SMS
      providerResponse: responses,
    }
  }

  // Twilio Provider (International)
  async sendViaTwilio(phoneNumbers, message) {
    const accountSid = process.env.TWILIO_ACCOUNT_SID
    const authToken = process.env.TWILIO_AUTH_TOKEN
    const fromNumber = process.env.TWILIO_PHONE_NUMBER

    if (!accountSid || !authToken || !fromNumber) {
      throw new Error("Twilio credentials not configured")
    }

    const client = require("twilio")(accountSid, authToken)

    let sentCount = 0
    let failedCount = 0
    const responses = []

    for (const phone of phoneNumbers) {
      try {
        const response = await client.messages.create({
          body: message,
          from: fromNumber,
          to: phone.startsWith("+") ? phone : `+88${phone}`,
        })

        if (response.status === "sent" || response.status === "queued") {
          sentCount++
        } else {
          failedCount++
        }

        responses.push(response)
      } catch (error) {
        failedCount++
        responses.push({ error: error.message })
      }
    }

    return {
      success: sentCount > 0,
      sentCount,
      failedCount,
      cost: sentCount * 5.0, // Assuming 5 BDT per SMS for international
      providerResponse: responses,
    }
  }

  // Update message log status
  async updateMessageLogStatus(messageLogId, status) {
    const query = `
      UPDATE message_logs 
      SET delivery_status = $1, updated_at = CURRENT_TIMESTAMP 
      WHERE id = $2
    `
    await this.pool.query(query, [status, messageLogId])
  }

  // Update message log with results
  async updateMessageLogResults(messageLogId, result) {
    const query = `
      UPDATE message_logs 
      SET 
        sent_count = $1,
        failed_count = $2,
        delivery_status = $3,
        cost = $4,
        provider_response = $5,
        sent_at = CURRENT_TIMESTAMP,
        completed_at = CURRENT_TIMESTAMP,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = $6
    `

    const values = [
      result.sentCount,
      result.failedCount,
      result.success ? "sent" : "failed",
      result.cost,
      JSON.stringify(result.providerResponse),
      messageLogId,
    ]

    await this.pool.query(query, values)
  }

  // Process scheduled messages (to be called by cron job)
  async processScheduledMessages() {
    const query = `
      SELECT * FROM scheduled_messages 
      WHERE status = 'scheduled' 
      AND scheduled_at <= CURRENT_TIMESTAMP
      ORDER BY scheduled_at ASC
      LIMIT 50
    `

    const result = await this.pool.query(query)
    const scheduledMessages = result.rows

    for (const scheduledMessage of scheduledMessages) {
      try {
        // Mark as processing
        await this.pool.query("UPDATE scheduled_messages SET status = $1 WHERE id = $2", [
          "processing",
          scheduledMessage.id,
        ])

        // Send the message
        const sendResult = await this.sendImmediate({
          messageLogId: scheduledMessage.message_log_id,
          recipients: {
            type: scheduledMessage.recipient_type,
            ids: JSON.parse(scheduledMessage.recipient_ids),
          },
          message: scheduledMessage.message,
          provider: "muthofun", // Default provider for scheduled messages
        })

        // Mark as sent
        await this.pool.query("UPDATE scheduled_messages SET status = $1, sent_at = CURRENT_TIMESTAMP WHERE id = $2", [
          "sent",
          scheduledMessage.id,
        ])

        console.log(`Scheduled message ${scheduledMessage.id} sent successfully`)
      } catch (error) {
        // Mark as failed
        await this.pool.query("UPDATE scheduled_messages SET status = $1 WHERE id = $2", [
          "failed",
          scheduledMessage.id,
        ])

        console.error(`Failed to send scheduled message ${scheduledMessage.id}:`, error)
      }
    }

    return scheduledMessages.length
  }

  // Get message templates
  async getMessageTemplates() {
    return [
      {
        id: "attendance_alert",
        name: "Attendance Alert",
        template:
          "Your child {student_name} was absent from {subject} class today. Please contact the class teacher if this is an emergency.",
        variables: ["student_name", "subject"],
      },
      {
        id: "fee_due",
        name: "Fee Due Alert",
        template:
          "Dear Parent, your child's {fee_type} fee of ৳{amount} is due on {due_date}. Please pay at your earliest convenience.",
        variables: ["fee_type", "amount", "due_date"],
      },
      {
        id: "result_published",
        name: "Result Published",
        template:
          "Results for {exam_name} have been published. Your child {student_name} scored {marks} marks. Check the student portal for details.",
        variables: ["exam_name", "student_name", "marks"],
      },
      {
        id: "emergency",
        name: "Emergency Notice",
        template: "URGENT: {message}. Please contact the school immediately at {phone}.",
        variables: ["message", "phone"],
      },
      {
        id: "event_reminder",
        name: "Event Reminder",
        template: "Reminder: {event_name} is scheduled for {date} at {time}. Please ensure your child's participation.",
        variables: ["event_name", "date", "time"],
      },
    ]
  }

  // Replace template variables with actual values
  replaceTemplateVariables(template, variables) {
    let message = template
    for (const [key, value] of Object.entries(variables)) {
      const placeholder = `{${key}}`
      message = message.replace(new RegExp(placeholder, "g"), value)
    }
    return message
  }

  // Get SMS statistics
  async getSMSStatistics(schoolId, timeRange = "30 days") {
    const query = `
      SELECT 
        COUNT(*) as total_messages,
        SUM(sent_count) as total_sent,
        SUM(failed_count) as total_failed,
        SUM(cost) as total_cost,
        AVG(CASE WHEN total_recipients > 0 THEN (sent_count::float / total_recipients) * 100 ELSE 0 END) as avg_delivery_rate
      FROM message_logs ml
      JOIN users u ON ml.sender_id = u.id
      WHERE u.school_id = $1 
      AND ml.created_at >= CURRENT_TIMESTAMP - INTERVAL '${timeRange}'
    `

    const result = await this.pool.query(query, [schoolId])
    return result.rows[0]
  }

  // Get message logs with pagination
  async getMessageLogs(schoolId, options = {}) {
    const { page = 1, limit = 20, status = null, messageType = null, startDate = null, endDate = null } = options

    const offset = (page - 1) * limit
    const whereConditions = ["u.school_id = $1"]
    const values = [schoolId]
    let paramCount = 1

    if (status) {
      paramCount++
      whereConditions.push(`ml.delivery_status = $${paramCount}`)
      values.push(status)
    }

    if (messageType) {
      paramCount++
      whereConditions.push(`ml.message_type = $${paramCount}`)
      values.push(messageType)
    }

    if (startDate) {
      paramCount++
      whereConditions.push(`ml.created_at >= $${paramCount}`)
      values.push(startDate)
    }

    if (endDate) {
      paramCount++
      whereConditions.push(`ml.created_at <= $${paramCount}`)
      values.push(endDate)
    }

    const query = `
      SELECT 
        ml.*,
        u.name as sender_name
      FROM message_logs ml
      JOIN users u ON ml.sender_id = u.id
      WHERE ${whereConditions.join(" AND ")}
      ORDER BY ml.created_at DESC
      LIMIT $${paramCount + 1} OFFSET $${paramCount + 2}
    `

    values.push(limit, offset)

    const result = await this.pool.query(query, values)

    // Get total count
    const countQuery = `
      SELECT COUNT(*) as total
      FROM message_logs ml
      JOIN users u ON ml.sender_id = u.id
      WHERE ${whereConditions.join(" AND ")}
    `

    const countResult = await this.pool.query(countQuery, values.slice(0, -2))

    return {
      logs: result.rows,
      total: Number.parseInt(countResult.rows[0].total),
      page,
      totalPages: Math.ceil(countResult.rows[0].total / limit),
    }
  }
}

module.exports = SMSService
