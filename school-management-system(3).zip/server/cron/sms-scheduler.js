// SMS Scheduler - Cron job to process scheduled messages
const cron = require("node-cron")
const SMSService = require("../services/sms-service")

const smsService = new SMSService()

// Run every minute to check for scheduled messages
const startSMSScheduler = () => {
  console.log("Starting SMS Scheduler...")

  cron.schedule("* * * * *", async () => {
    try {
      const processedCount = await smsService.processScheduledMessages()
      if (processedCount > 0) {
        console.log(`Processed ${processedCount} scheduled messages`)
      }
    } catch (error) {
      console.error("SMS Scheduler error:", error)
    }
  })

  console.log("SMS Scheduler started - running every minute")
}

module.exports = { startSMSScheduler }
