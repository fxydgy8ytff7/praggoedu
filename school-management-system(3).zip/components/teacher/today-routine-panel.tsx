"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { CheckCircle, Clock, MapPin, Bell, Users, BookOpen } from "lucide-react"

interface ScheduleItem {
  id: number
  time: string
  endTime: string
  class: string
  class_bangla: string
  subject: string
  subject_bangla: string
  room: string
  completed: boolean
  studentCount: number
  isCurrentClass: boolean
  nextClass?: boolean
}

export function TodayRoutinePanel() {
  const [routineItems, setRoutineItems] = useState<ScheduleItem[]>([
    {
      id: 1,
      time: "08:00",
      endTime: "08:45",
      class: "Class 10-A",
      class_bangla: "দশম শ্রেণী-ক",
      subject: "Mathematics",
      subject_bangla: "গণিত",
      room: "Room 301",
      completed: true,
      studentCount: 35,
      isCurrentClass: false,
    },
    {
      id: 2,
      time: "08:45",
      endTime: "09:30",
      class: "Class 9-B",
      class_bangla: "নবম শ্রেণী-খ",
      subject: "Mathematics",
      subject_bangla: "গণিত",
      room: "Room 205",
      completed: true,
      studentCount: 32,
      isCurrentClass: false,
    },
    {
      id: 3,
      time: "09:45",
      endTime: "10:30",
      class: "Class 8-A",
      class_bangla: "অষ্টম শ্রেণী-ক",
      subject: "Mathematics",
      subject_bangla: "গণিত",
      room: "Room 102",
      completed: false,
      studentCount: 38,
      isCurrentClass: true,
    },
    {
      id: 4,
      time: "10:30",
      endTime: "11:15",
      class: "Class 7-B",
      class_bangla: "সপ্তম শ্রেণী-খ",
      subject: "Mathematics",
      subject_bangla: "গণিত",
      room: "Room 108",
      completed: false,
      studentCount: 30,
      isCurrentClass: false,
      nextClass: true,
    },
    {
      id: 5,
      time: "11:30",
      endTime: "12:15",
      class: "Class 6-A",
      class_bangla: "ষষ্ঠ শ্রেণী-ক",
      subject: "Mathematics",
      subject_bangla: "গণিত",
      room: "Room 105",
      completed: false,
      studentCount: 28,
      isCurrentClass: false,
    },
  ])

  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 60000) // Update every minute

    return () => clearInterval(timer)
  }, [])

  const markAsCompleted = (id: number) => {
    setRoutineItems((prev) => prev.map((item) => (item.id === id ? { ...item, completed: true } : item)))
  }

  const getCurrentClass = () => {
    return routineItems.find((item) => item.isCurrentClass)
  }

  const getNextClass = () => {
    return routineItems.find((item) => item.nextClass)
  }

  const currentClass = getCurrentClass()
  const nextClass = getNextClass()

  const stats = {
    total: routineItems.length,
    completed: routineItems.filter((item) => item.completed).length,
    remaining: routineItems.filter((item) => !item.completed).length,
    totalStudents: routineItems.reduce((sum, item) => sum + item.studentCount, 0),
  }

  return (
    <div className="space-y-6">
      {/* Header with Current Time */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-blue-900">Today's Class Routine</h2>
          <h3 className="text-xl text-blue-700">আজকের ক্লাস রুটিন</h3>
          <p className="text-gray-600">
            {new Date().toLocaleDateString("en-US", {
              weekday: "long",
              year: "numeric",
              month: "long",
              day: "numeric",
            })}
          </p>
        </div>
        <div className="text-right">
          <div className="text-3xl font-bold text-blue-600">
            {currentTime.toLocaleTimeString("en-US", {
              hour: "2-digit",
              minute: "2-digit",
            })}
          </div>
          <div className="text-sm text-gray-600">Current Time</div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm font-medium">Total Classes</p>
                <p className="text-2xl font-bold">{stats.total}</p>
              </div>
              <BookOpen className="h-6 w-6 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm font-medium">Completed</p>
                <p className="text-2xl font-bold">{stats.completed}</p>
              </div>
              <CheckCircle className="h-6 w-6 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-100 text-sm font-medium">Remaining</p>
                <p className="text-2xl font-bold">{stats.remaining}</p>
              </div>
              <Clock className="h-6 w-6 text-orange-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm font-medium">Total Students</p>
                <p className="text-2xl font-bold">{stats.totalStudents}</p>
              </div>
              <Users className="h-6 w-6 text-purple-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Current Class Alert */}
      {currentClass && (
        <Card className="border-3 border-green-400 bg-green-50">
          <CardContent className="p-6">
            <div className="flex items-center space-x-4">
              <div className="w-16 h-16 bg-green-500 rounded-full flex items-center justify-center animate-pulse">
                <Bell className="h-8 w-8 text-white" />
              </div>
              <div className="flex-1">
                <h3 className="text-2xl font-bold text-green-900">Current Class</h3>
                <p className="text-green-700 text-lg">
                  {currentClass.class} • {currentClass.subject}
                </p>
                <p className="text-green-600">
                  {currentClass.class_bangla} • {currentClass.subject_bangla}
                </p>
                <div className="flex items-center space-x-4 mt-2">
                  <Badge className="bg-green-600 text-white">
                    <Clock className="h-3 w-3 mr-1" />
                    {currentClass.time} - {currentClass.endTime}
                  </Badge>
                  <Badge className="bg-blue-600 text-white">
                    <MapPin className="h-3 w-3 mr-1" />
                    {currentClass.room}
                  </Badge>
                  <Badge className="bg-purple-600 text-white">
                    <Users className="h-3 w-3 mr-1" />
                    {currentClass.studentCount} students
                  </Badge>
                </div>
              </div>
              <Button
                onClick={() => markAsCompleted(currentClass.id)}
                className="bg-green-600 hover:bg-green-700 text-white font-bold px-6 py-3"
              >
                <CheckCircle className="h-5 w-5 mr-2" />
                Mark Complete
              </Button>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Next Class Preview */}
      {nextClass && (
        <Card className="border-2 border-blue-300 bg-blue-50">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <h4 className="text-lg font-bold text-blue-900">Next Class</h4>
                <p className="text-blue-700">
                  {nextClass.class} • {nextClass.subject} • {nextClass.room}
                </p>
                <p className="text-sm text-blue-600">
                  Starts at {nextClass.time} ({nextClass.studentCount} students)
                </p>
              </div>
              <Badge className="bg-blue-600 text-white px-3 py-2">
                <Clock className="h-4 w-4 mr-1" />
                Up Next
              </Badge>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Full Schedule */}
      <Card className="border-2 border-gray-200">
        <CardHeader className="bg-gray-50">
          <CardTitle className="text-gray-900">Complete Schedule</CardTitle>
          <CardDescription>সম্পূর্ণ সময়সূচী</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            {routineItems.map((item) => (
              <div
                key={item.id}
                className={`flex items-center justify-between p-6 border-2 rounded-lg transition-all ${
                  item.isCurrentClass
                    ? "bg-green-50 border-green-300 shadow-lg"
                    : item.nextClass
                      ? "bg-blue-50 border-blue-300"
                      : item.completed
                        ? "bg-gray-50 border-gray-200 opacity-75"
                        : "bg-white border-gray-200 hover:border-blue-300"
                }`}
              >
                <div className="flex items-center space-x-6">
                  <div className="text-center min-w-[100px]">
                    <div className="text-lg font-bold text-gray-900">{item.time}</div>
                    <div className="text-sm text-gray-600">to {item.endTime}</div>
                    {item.isCurrentClass && <Badge className="bg-green-500 text-white text-xs mt-1">CURRENT</Badge>}
                    {item.nextClass && <Badge className="bg-blue-500 text-white text-xs mt-1">NEXT</Badge>}
                  </div>

                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-xl font-bold text-gray-900">{item.class}</h3>
                      <span className="text-gray-600">({item.class_bangla})</span>
                    </div>
                    <div className="flex items-center space-x-6">
                      <div className="flex items-center space-x-2">
                        <BookOpen className="h-4 w-4 text-blue-500" />
                        <span className="font-semibold text-gray-700">{item.subject}</span>
                        <span className="text-sm text-gray-500">({item.subject_bangla})</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <MapPin className="h-4 w-4 text-purple-500" />
                        <span className="text-gray-700">{item.room}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <Users className="h-4 w-4 text-green-500" />
                        <span className="text-gray-700">{item.studentCount} students</span>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex items-center space-x-3">
                  {item.completed ? (
                    <Badge className="bg-green-500 text-white px-4 py-2 text-sm font-bold">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Completed
                    </Badge>
                  ) : (
                    <Button
                      onClick={() => markAsCompleted(item.id)}
                      variant={item.isCurrentClass ? "default" : "outline"}
                      className={`font-semibold ${
                        item.isCurrentClass
                          ? "bg-green-600 hover:bg-green-700 text-white"
                          : "border-2 border-green-300 text-green-700 hover:bg-green-50"
                      }`}
                      disabled={!item.isCurrentClass && !item.completed}
                    >
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Mark Complete
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
