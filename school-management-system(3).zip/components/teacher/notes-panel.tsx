"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Upload, FileText, ImageIcon, Mic, Video, Send, Eye, Download, Star, Users } from "lucide-react"

interface Note {
  id: number
  title: string
  title_bangla: string
  class: string
  subject: string
  fileType: string
  uploadDate: string
  views: number
  downloads: number
  isImportant: boolean
  status: "published" | "draft"
  studentFeedback: number
}

export function NotesPanel() {
  const [noteForm, setNoteForm] = useState({
    title: "",
    title_bangla: "",
    content: "",
    content_bangla: "",
    class: "",
    section: "",
    subject: "",
    fileType: "text",
    visibility: "class",
    isImportant: false,
  })

  const [isUploading, setIsUploading] = useState(false)
  const [uploadProgress, setUploadProgress] = useState(0)

  const [uploadedNotes, setUploadedNotes] = useState<Note[]>([
    {
      id: 1,
      title: "Chapter 5: Algebra Basics",
      title_bangla: "অধ্যায় ৫: বীজগণিতের মূলনীতি",
      class: "Class 10-A",
      subject: "Mathematics",
      fileType: "pdf",
      uploadDate: "2024-01-15",
      views: 45,
      downloads: 32,
      isImportant: true,
      status: "published",
      studentFeedback: 4.8,
    },
    {
      id: 2,
      title: "Quadratic Equations Practice",
      title_bangla: "দ্বিঘাত সমীকরণ অনুশীলন",
      class: "Class 9-B",
      subject: "Mathematics",
      fileType: "text",
      uploadDate: "2024-01-14",
      views: 32,
      downloads: 28,
      isImportant: false,
      status: "published",
      studentFeedback: 4.5,
    },
    {
      id: 3,
      title: "Geometry Audio Explanation",
      title_bangla: "জ্যামিতি অডিও ব্যাখ্যা",
      class: "Class 8-A",
      subject: "Mathematics",
      fileType: "audio",
      uploadDate: "2024-01-13",
      views: 28,
      downloads: 15,
      isImportant: false,
      status: "published",
      studentFeedback: 4.2,
    },
    {
      id: 4,
      title: "Trigonometry Video Tutorial",
      title_bangla: "ত্রিকোণমিতি ভিডিও টিউটোরিয়াল",
      class: "Class 10-A",
      subject: "Mathematics",
      fileType: "video",
      uploadDate: "2024-01-12",
      views: 67,
      downloads: 45,
      isImportant: true,
      status: "published",
      studentFeedback: 4.9,
    },
  ])

  const handleUpload = async () => {
    if (!noteForm.title || !noteForm.class || !noteForm.subject) {
      alert("Please fill in all required fields")
      return
    }

    setIsUploading(true)
    setUploadProgress(0)

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval)
          setIsUploading(false)

          // Add new note to the list
          const newNote: Note = {
            id: uploadedNotes.length + 1,
            title: noteForm.title,
            title_bangla: noteForm.title_bangla,
            class: noteForm.class,
            subject: noteForm.subject,
            fileType: noteForm.fileType,
            uploadDate: new Date().toISOString().split("T")[0],
            views: 0,
            downloads: 0,
            isImportant: noteForm.isImportant,
            status: "published",
            studentFeedback: 0,
          }

          setUploadedNotes((prev) => [newNote, ...prev])

          // Reset form
          setNoteForm({
            title: "",
            title_bangla: "",
            content: "",
            content_bangla: "",
            class: "",
            section: "",
            subject: "",
            fileType: "text",
            visibility: "class",
            isImportant: false,
          })

          alert("Note uploaded successfully and students have been notified!")
          return 0
        }
        return prev + 10
      })
    }, 200)
  }

  const getFileIcon = (fileType: string) => {
    switch (fileType) {
      case "pdf":
      case "text":
        return <FileText className="h-4 w-4" />
      case "image":
        return <ImageIcon className="h-4 w-4" />
      case "audio":
        return <Mic className="h-4 w-4" />
      case "video":
        return <Video className="h-4 w-4" />
      default:
        return <FileText className="h-4 w-4" />
    }
  }

  const getFileTypeColor = (fileType: string) => {
    switch (fileType) {
      case "pdf":
        return "bg-red-100 text-red-700 border-red-300"
      case "text":
        return "bg-blue-100 text-blue-700 border-blue-300"
      case "image":
        return "bg-green-100 text-green-700 border-green-300"
      case "audio":
        return "bg-purple-100 text-purple-700 border-purple-300"
      case "video":
        return "bg-orange-100 text-orange-700 border-orange-300"
      default:
        return "bg-gray-100 text-gray-700 border-gray-300"
    }
  }

  const totalViews = uploadedNotes.reduce((sum, note) => sum + note.views, 0)
  const totalDownloads = uploadedNotes.reduce((sum, note) => sum + note.downloads, 0)
  const averageRating = uploadedNotes.reduce((sum, note) => sum + note.studentFeedback, 0) / uploadedNotes.length

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-purple-900">Teacher Notes Panel</h2>
          <h3 className="text-xl text-purple-700">শিক্ষক নোট প্যানেল</h3>
          <p className="text-gray-600">Upload and manage study materials for students</p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-purple-600">{uploadedNotes.length}</div>
          <div className="text-sm text-gray-600">Total Notes</div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm font-medium">Total Views</p>
                <p className="text-2xl font-bold">{totalViews}</p>
              </div>
              <Eye className="h-6 w-6 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm font-medium">Downloads</p>
                <p className="text-2xl font-bold">{totalDownloads}</p>
              </div>
              <Download className="h-6 w-6 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-yellow-100 text-sm font-medium">Avg Rating</p>
                <p className="text-2xl font-bold">{averageRating.toFixed(1)}</p>
              </div>
              <Star className="h-6 w-6 text-yellow-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm font-medium">Published</p>
                <p className="text-2xl font-bold">{uploadedNotes.filter((n) => n.status === "published").length}</p>
              </div>
              <FileText className="h-6 w-6 text-purple-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Upload New Note */}
      <Card className="border-2 border-purple-200">
        <CardHeader className="bg-purple-50">
          <CardTitle className="text-purple-900 flex items-center">
            <Upload className="h-5 w-5 mr-2" />
            Upload New Study Material
          </CardTitle>
          <CardDescription className="text-purple-700">
            নতুন অধ্যয়ন উপকরণ আপলোড করুন - Support for text, PDF, images, audio, and video
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Title (English) *</Label>
              <Input
                placeholder="Enter note title"
                value={noteForm.title}
                onChange={(e) => setNoteForm({ ...noteForm, title: e.target.value })}
                className="border-2 border-gray-300 focus:border-purple-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Title (Bangla)</Label>
              <Input
                placeholder="নোটের শিরোনাম লিখুন"
                value={noteForm.title_bangla}
                onChange={(e) => setNoteForm({ ...noteForm, title_bangla: e.target.value })}
                className="border-2 border-gray-300 focus:border-purple-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Class *</Label>
              <Select value={noteForm.class} onValueChange={(value) => setNoteForm({ ...noteForm, class: value })}>
                <SelectTrigger className="border-2 border-gray-300 focus:border-purple-500">
                  <SelectValue placeholder="Select Class" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Class 6-A">Class 6-A (ষষ্ঠ শ্রেণী-ক)</SelectItem>
                  <SelectItem value="Class 7-A">Class 7-A (সপ্তম শ্রেণী-ক)</SelectItem>
                  <SelectItem value="Class 8-A">Class 8-A (অষ্টম শ্রেণী-ক)</SelectItem>
                  <SelectItem value="Class 9-B">Class 9-B (নবম শ্রেণী-খ)</SelectItem>
                  <SelectItem value="Class 10-A">Class 10-A (দশম শ্রেণী-ক)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Section</Label>
              <Select value={noteForm.section} onValueChange={(value) => setNoteForm({ ...noteForm, section: value })}>
                <SelectTrigger className="border-2 border-gray-300 focus:border-purple-500">
                  <SelectValue placeholder="Select Section" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="A">Section A</SelectItem>
                  <SelectItem value="B">Section B</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Subject *</Label>
              <Select value={noteForm.subject} onValueChange={(value) => setNoteForm({ ...noteForm, subject: value })}>
                <SelectTrigger className="border-2 border-gray-300 focus:border-purple-500">
                  <SelectValue placeholder="Select Subject" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Mathematics">Mathematics (গণিত)</SelectItem>
                  <SelectItem value="English">English (ইংরেজি)</SelectItem>
                  <SelectItem value="Bangla">Bangla (বাংলা)</SelectItem>
                  <SelectItem value="Physics">Physics (পদার্থবিজ্ঞান)</SelectItem>
                  <SelectItem value="Chemistry">Chemistry (রসায়ন)</SelectItem>
                  <SelectItem value="Biology">Biology (জীববিজ্ঞান)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-gray-700 font-semibold">Content (English)</Label>
            <Textarea
              placeholder="Write your note content here..."
              value={noteForm.content}
              onChange={(e) => setNoteForm({ ...noteForm, content: e.target.value })}
              rows={4}
              className="border-2 border-gray-300 focus:border-purple-500 resize-none"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-gray-700 font-semibold">Content (Bangla)</Label>
            <Textarea
              placeholder="এখানে আপনার নোটের বিষয়বস্তু লিখুন..."
              value={noteForm.content_bangla}
              onChange={(e) => setNoteForm({ ...noteForm, content_bangla: e.target.value })}
              rows={4}
              className="border-2 border-gray-300 focus:border-purple-500 resize-none"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">File Type</Label>
              <Select
                value={noteForm.fileType}
                onValueChange={(value) => setNoteForm({ ...noteForm, fileType: value })}
              >
                <SelectTrigger className="border-2 border-gray-300 focus:border-purple-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="text">📝 Text Note</SelectItem>
                  <SelectItem value="pdf">📄 PDF Document</SelectItem>
                  <SelectItem value="image">🖼️ Image/Photo</SelectItem>
                  <SelectItem value="audio">🎵 Voice Recording</SelectItem>
                  <SelectItem value="video">🎥 Video Explanation</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Visibility</Label>
              <Select
                value={noteForm.visibility}
                onValueChange={(value) => setNoteForm({ ...noteForm, visibility: value })}
              >
                <SelectTrigger className="border-2 border-gray-300 focus:border-purple-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="class">👥 Entire Class</SelectItem>
                  <SelectItem value="section">📚 Specific Section</SelectItem>
                  <SelectItem value="individual">👤 Individual Students</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          {noteForm.fileType !== "text" && (
            <div className="border-2 border-dashed border-purple-300 rounded-lg p-8 text-center bg-purple-50">
              <Upload className="h-12 w-12 mx-auto text-purple-400 mb-4" />
              <p className="text-lg font-semibold text-purple-700 mb-2">Upload {noteForm.fileType} file</p>
              <p className="text-sm text-purple-600 mb-4">Click to browse or drag and drop your file here</p>
              <p className="text-xs text-gray-500">Max file size: 50MB • Supported formats: PDF, JPG, PNG, MP3, MP4</p>
            </div>
          )}

          <div className="flex items-center space-x-4">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={noteForm.isImportant}
                onChange={(e) => setNoteForm({ ...noteForm, isImportant: e.target.checked })}
                className="w-4 h-4 text-red-600 rounded focus:ring-red-500"
              />
              <span className="text-sm font-semibold text-red-600">⭐ Mark as Important</span>
            </label>
          </div>

          {isUploading && (
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-purple-700">Uploading...</span>
                <span className="text-sm text-purple-600">{uploadProgress}%</span>
              </div>
              <Progress value={uploadProgress} className="h-2" />
            </div>
          )}

          <div className="flex space-x-3">
            <Button
              onClick={handleUpload}
              disabled={isUploading}
              className="flex-1 bg-purple-600 hover:bg-purple-700 text-white font-bold py-3"
            >
              {isUploading ? (
                <>
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                  Uploading...
                </>
              ) : (
                <>
                  <Upload className="h-4 w-4 mr-2" />
                  Upload & Notify Students
                </>
              )}
            </Button>
            <Button
              variant="outline"
              className="border-2 border-purple-300 text-purple-700 font-semibold bg-transparent"
            >
              <Eye className="h-4 w-4 mr-2" />
              Preview
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Uploaded Notes List */}
      <Card className="border-2 border-green-200">
        <CardHeader className="bg-green-50">
          <CardTitle className="text-green-900">My Uploaded Notes</CardTitle>
          <CardDescription>আমার আপলোড করা নোটসমূহ - Manage your study materials</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            {uploadedNotes.map((note) => (
              <Card key={note.id} className="border border-gray-200 hover:border-green-300 transition-colors">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex items-start space-x-4">
                      <div
                        className={`flex items-center justify-center w-12 h-12 rounded-lg ${getFileTypeColor(note.fileType)}`}
                      >
                        {getFileIcon(note.fileType)}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center space-x-2 mb-2">
                          <h3 className="text-xl font-bold text-gray-900">{note.title}</h3>
                          {note.isImportant && (
                            <Badge className="bg-red-500 text-white text-xs px-2 py-1">⭐ Important</Badge>
                          )}
                        </div>
                        <p className="text-gray-600 mb-2">{note.title_bangla}</p>
                        <div className="flex items-center space-x-4 text-sm text-gray-500">
                          <span>
                            {note.class} • {note.subject}
                          </span>
                          <span>📅 {note.uploadDate}</span>
                          <Badge className={`${getFileTypeColor(note.fileType)} text-xs`}>
                            {note.fileType.toUpperCase()}
                          </Badge>
                        </div>
                      </div>
                    </div>
                    <Badge className="bg-green-500 text-white px-3 py-1 font-semibold">
                      {note.status.toUpperCase()}
                    </Badge>
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{note.views}</div>
                      <div className="text-xs text-blue-700">Views</div>
                    </div>
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">{note.downloads}</div>
                      <div className="text-xs text-green-700">Downloads</div>
                    </div>
                    <div className="text-center p-3 bg-yellow-50 rounded-lg">
                      <div className="text-2xl font-bold text-yellow-600">{note.studentFeedback}</div>
                      <div className="text-xs text-yellow-700">Rating</div>
                    </div>
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">{Math.round((note.views / 35) * 100)}%</div>
                      <div className="text-xs text-purple-700">Reach</div>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold">
                      <Eye className="h-4 w-4 mr-2" />
                      View Details
                    </Button>
                    <Button className="flex-1 bg-green-600 hover:bg-green-700 text-white font-semibold">
                      <Send className="h-4 w-4 mr-2" />
                      Notify Again
                    </Button>
                    <Button
                      variant="outline"
                      className="border-2 border-gray-300 text-gray-700 font-semibold bg-transparent"
                    >
                      <Users className="h-4 w-4 mr-2" />
                      Analytics
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
