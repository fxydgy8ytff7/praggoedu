"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import {
  Users,
  Search,
  MessageSquare,
  CheckCircle,
  XCircle,
  Clock,
  BookOpen,
  Calendar,
  TrendingUp,
  AlertTriangle,
} from "lucide-react"

export function TeacherManagementPanel() {
  const [filterSubject, setFilterSubject] = useState("all")
  const [filterClass, setFilterClass] = useState("all")
  const [filterActivity, setFilterActivity] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")

  const [teachers] = useState([
    {
      id: 1,
      name: "Ms. Sarah Ahmed",
      name_bangla: "সারাহ আহমেদ",
      subject: "Mathematics",
      subject_bangla: "গণিত",
      classes: ["Class 8-A", "Class 9-B", "Class 10-A"],
      phone: "+8801712345678",
      email: "sarah.ahmed@school.edu.bd",
      joinDate: "2020-01-15",
      status: "active",
      todayAttendance: "present",
      lastActive: "2 hours ago",
      notesUploaded: 15,
      homeworkAssigned: 8,
      attendanceSubmitted: 3,
      totalClasses: 3,
      activityLevel: "high",
      studentCount: 95,
    },
    {
      id: 2,
      name: "Mr. Karim Hassan",
      name_bangla: "করিম হাসান",
      subject: "Physics",
      subject_bangla: "পদার্থবিজ্ঞান",
      classes: ["Class 9-A", "Class 10-B"],
      phone: "+8801812345678",
      email: "karim.hassan@school.edu.bd",
      joinDate: "2019-03-20",
      status: "active",
      todayAttendance: "present",
      lastActive: "1 hour ago",
      notesUploaded: 12,
      homeworkAssigned: 5,
      attendanceSubmitted: 2,
      totalClasses: 2,
      activityLevel: "medium",
      studentCount: 68,
    },
    {
      id: 3,
      name: "Dr. Fatima Khan",
      name_bangla: "ফাতিমা খান",
      subject: "Chemistry",
      subject_bangla: "রসায়ন",
      classes: ["Class 9-A", "Class 10-A", "Class 10-B"],
      phone: "+8801912345678",
      email: "fatima.khan@school.edu.bd",
      joinDate: "2018-07-10",
      status: "active",
      todayAttendance: "late",
      lastActive: "30 minutes ago",
      notesUploaded: 8,
      homeworkAssigned: 3,
      attendanceSubmitted: 1,
      totalClasses: 3,
      activityLevel: "low",
      studentCount: 85,
    },
    {
      id: 4,
      name: "Ms. Rashida Begum",
      name_bangla: "রাশিদা বেগম",
      subject: "Biology",
      subject_bangla: "জীববিজ্ঞান",
      classes: ["Class 8-B", "Class 9-B"],
      phone: "+8801612345678",
      email: "rashida.begum@school.edu.bd",
      joinDate: "2021-02-01",
      status: "active",
      todayAttendance: "absent",
      lastActive: "1 day ago",
      notesUploaded: 5,
      homeworkAssigned: 2,
      attendanceSubmitted: 0,
      totalClasses: 2,
      activityLevel: "low",
      studentCount: 62,
    },
  ])

  const getActivityColor = (level: string) => {
    switch (level) {
      case "high":
        return "bg-green-500 text-white"
      case "medium":
        return "bg-yellow-500 text-white"
      case "low":
        return "bg-red-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  const getAttendanceColor = (status: string) => {
    switch (status) {
      case "present":
        return "bg-green-500 text-white"
      case "late":
        return "bg-yellow-500 text-white"
      case "absent":
        return "bg-red-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  const getAttendanceIcon = (status: string) => {
    switch (status) {
      case "present":
        return <CheckCircle className="h-4 w-4" />
      case "late":
        return <Clock className="h-4 w-4" />
      case "absent":
        return <XCircle className="h-4 w-4" />
      default:
        return <Clock className="h-4 w-4" />
    }
  }

  const filteredTeachers = teachers.filter((teacher) => {
    const matchesSubject =
      filterSubject === "all" || teacher.subject.toLowerCase().includes(filterSubject.toLowerCase())
    const matchesClass = filterClass === "all" || teacher.classes.some((cls) => cls.includes(filterClass))
    const matchesActivity = filterActivity === "all" || teacher.activityLevel === filterActivity
    const matchesSearch =
      teacher.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      teacher.subject.toLowerCase().includes(searchTerm.toLowerCase())

    return matchesSubject && matchesClass && matchesActivity && matchesSearch
  })

  const stats = {
    total: teachers.length,
    present: teachers.filter((t) => t.todayAttendance === "present").length,
    late: teachers.filter((t) => t.todayAttendance === "late").length,
    absent: teachers.filter((t) => t.todayAttendance === "absent").length,
    highActivity: teachers.filter((t) => t.activityLevel === "high").length,
    lowActivity: teachers.filter((t) => t.activityLevel === "low").length,
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-purple-900">Teacher Management Center</h2>
          <h3 className="text-xl text-purple-700">শিক্ষক ব্যবস্থাপনা কেন্দ্র</h3>
          <p className="text-gray-600">Monitor teacher activity, attendance, and performance</p>
        </div>
        <Button className="bg-purple-600 hover:bg-purple-700 text-white font-semibold">
          <MessageSquare className="h-4 w-4 mr-2" />
          Broadcast Message
        </Button>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm font-medium">Total Teachers</p>
                <p className="text-3xl font-bold">{stats.total}</p>
              </div>
              <Users className="h-8 w-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm font-medium">Present Today</p>
                <p className="text-3xl font-bold">{stats.present}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-yellow-100 text-sm font-medium">Late/Absent</p>
                <p className="text-3xl font-bold">{stats.late + stats.absent}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-yellow-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm font-medium">High Activity</p>
                <p className="text-3xl font-bold">{stats.highActivity}</p>
              </div>
              <TrendingUp className="h-8 w-8 text-purple-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="border-2 border-purple-200">
        <CardHeader className="bg-purple-50">
          <CardTitle className="text-purple-900">Filter Teachers</CardTitle>
          <CardDescription>শিক্ষক ফিল্টার করুন</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search teachers..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 border-2 border-gray-300 focus:border-purple-500"
              />
            </div>

            <Select value={filterSubject} onValueChange={setFilterSubject}>
              <SelectTrigger className="border-2 border-gray-300 focus:border-purple-500">
                <SelectValue placeholder="Filter by subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Subjects</SelectItem>
                <SelectItem value="mathematics">Mathematics</SelectItem>
                <SelectItem value="physics">Physics</SelectItem>
                <SelectItem value="chemistry">Chemistry</SelectItem>
                <SelectItem value="biology">Biology</SelectItem>
                <SelectItem value="english">English</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterClass} onValueChange={setFilterClass}>
              <SelectTrigger className="border-2 border-gray-300 focus:border-purple-500">
                <SelectValue placeholder="Filter by class" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Classes</SelectItem>
                <SelectItem value="8">Class 8</SelectItem>
                <SelectItem value="9">Class 9</SelectItem>
                <SelectItem value="10">Class 10</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterActivity} onValueChange={setFilterActivity}>
              <SelectTrigger className="border-2 border-gray-300 focus:border-purple-500">
                <SelectValue placeholder="Activity level" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Activity Levels</SelectItem>
                <SelectItem value="high">High Activity</SelectItem>
                <SelectItem value="medium">Medium Activity</SelectItem>
                <SelectItem value="low">Low Activity</SelectItem>
              </SelectContent>
            </Select>

            <Button className="bg-purple-600 hover:bg-purple-700 text-white font-semibold">
              <Search className="h-4 w-4 mr-2" />
              Search
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Teachers List */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {filteredTeachers.map((teacher) => (
          <Card key={teacher.id} className="border-2 border-gray-200 hover:border-purple-300 transition-colors">
            <CardContent className="p-6">
              <div className="flex items-start space-x-4 mb-4">
                <Avatar className="w-16 h-16 border-2 border-purple-200">
                  <AvatarImage src={`/placeholder.svg?height=64&width=64&text=${teacher.name.charAt(0)}`} />
                  <AvatarFallback className="bg-purple-100 text-purple-700 text-xl font-bold">
                    {teacher.name.charAt(0)}
                  </AvatarFallback>
                </Avatar>
                <div className="flex-1">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <h3 className="text-xl font-bold text-gray-900">{teacher.name}</h3>
                      <p className="text-gray-600">{teacher.name_bangla}</p>
                    </div>
                    <Badge className={`${getAttendanceColor(teacher.todayAttendance)} px-3 py-1 font-semibold`}>
                      {getAttendanceIcon(teacher.todayAttendance)}
                      <span className="ml-1 capitalize">{teacher.todayAttendance}</span>
                    </Badge>
                  </div>
                  <div className="flex items-center space-x-4 mb-2">
                    <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300 font-semibold">
                      <BookOpen className="h-3 w-3 mr-1" />
                      {teacher.subject}
                    </Badge>
                    <Badge className={`${getActivityColor(teacher.activityLevel)} px-2 py-1 text-xs font-semibold`}>
                      {teacher.activityLevel} activity
                    </Badge>
                  </div>
                  <p className="text-sm text-gray-600">
                    Classes: {teacher.classes.join(", ")} • {teacher.studentCount} students
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                <div className="text-center p-3 bg-blue-50 rounded-lg">
                  <div className="text-2xl font-bold text-blue-600">{teacher.notesUploaded}</div>
                  <div className="text-xs text-blue-700">Notes</div>
                </div>
                <div className="text-center p-3 bg-green-50 rounded-lg">
                  <div className="text-2xl font-bold text-green-600">{teacher.homeworkAssigned}</div>
                  <div className="text-xs text-green-700">Homework</div>
                </div>
                <div className="text-center p-3 bg-purple-50 rounded-lg">
                  <div className="text-2xl font-bold text-purple-600">
                    {teacher.attendanceSubmitted}/{teacher.totalClasses}
                  </div>
                  <div className="text-xs text-purple-700">Attendance</div>
                </div>
                <div className="text-center p-3 bg-orange-50 rounded-lg">
                  <div className="text-2xl font-bold text-orange-600">{teacher.classes.length}</div>
                  <div className="text-xs text-orange-700">Classes</div>
                </div>
              </div>

              <div className="space-y-2 mb-4">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Last Active:</span>
                  <span className="font-semibold text-gray-900">{teacher.lastActive}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Join Date:</span>
                  <span className="font-semibold text-gray-900">{teacher.joinDate}</span>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600">Contact:</span>
                  <span className="font-semibold text-gray-900">{teacher.phone}</span>
                </div>
              </div>

              <div className="flex space-x-2">
                <Button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold">
                  <MessageSquare className="h-4 w-4 mr-2" />
                  Message
                </Button>
                <Button
                  variant="outline"
                  className="flex-1 border-2 border-purple-300 text-purple-700 font-semibold bg-transparent"
                >
                  <Calendar className="h-4 w-4 mr-2" />
                  View Schedule
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
