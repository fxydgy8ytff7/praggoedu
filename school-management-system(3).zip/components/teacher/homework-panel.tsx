"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { FileText, Eye, CheckCircle, Clock, Star, Download } from "lucide-react"

interface Homework {
  id: number
  title: string
  title_bangla: string
  class: string
  subject: string
  dueDate: string
  totalMarks: number
  submitted: number
  total: number
  status: "active" | "completed" | "overdue"
  averageScore?: number
}

interface Submission {
  id: number
  studentName: string
  studentName_bangla: string
  roll: number
  submittedAt: string
  status: "submitted" | "graded" | "late"
  isLate: boolean
  marks?: number
  fileType: string
  feedback?: string
}

export function HomeworkPanel() {
  const [homeworkForm, setHomeworkForm] = useState({
    title: "",
    title_bangla: "",
    description: "",
    description_bangla: "",
    instructions: "",
    instructions_bangla: "",
    class: "",
    section: "",
    subject: "",
    dueDate: "",
    dueTime: "",
    totalMarks: "",
    submissionType: "file",
    isGroupWork: false,
  })

  const [isCreating, setIsCreating] = useState(false)
  const [selectedHomework, setSelectedHomework] = useState<number | null>(null)

  const [assignedHomework, setAssignedHomework] = useState<Homework[]>([
    {
      id: 1,
      title: "Algebra Problem Set 1",
      title_bangla: "বীজগণিত সমস্যা সেট ১",
      class: "Class 10-A",
      subject: "Mathematics",
      dueDate: "2024-01-20",
      totalMarks: 20,
      submitted: 28,
      total: 35,
      status: "active",
      averageScore: 16.5,
    },
    {
      id: 2,
      title: "Quadratic Equations Practice",
      title_bangla: "দ্বিঘাত সমীকরণ অনুশীলন",
      class: "Class 9-B",
      subject: "Mathematics",
      dueDate: "2024-01-18",
      totalMarks: 15,
      submitted: 30,
      total: 32,
      status: "completed",
      averageScore: 12.8,
    },
    {
      id: 3,
      title: "Geometry Theorems",
      title_bangla: "জ্যামিতি উপপাদ্য",
      class: "Class 8-A",
      subject: "Mathematics",
      dueDate: "2024-01-15",
      totalMarks: 25,
      submitted: 28,
      total: 28,
      status: "completed",
      averageScore: 21.2,
    },
    {
      id: 4,
      title: "Calculus Derivatives",
      title_bangla: "ক্যালকুলাস অন্তরীকরণ",
      class: "Class 10-A",
      subject: "Mathematics",
      dueDate: "2024-01-25",
      totalMarks: 30,
      submitted: 15,
      total: 35,
      status: "overdue",
      averageScore: 18.5,
    },
  ])

  const [submissions] = useState<Submission[]>([
    {
      id: 1,
      studentName: "Ahmed Rahman",
      studentName_bangla: "আহমেদ রহমান",
      roll: 15,
      submittedAt: "2024-01-18 14:30",
      status: "graded",
      isLate: false,
      marks: 18,
      fileType: "pdf",
      feedback: "Excellent work! Clear explanations and correct solutions.",
    },
    {
      id: 2,
      studentName: "Fatima Khatun",
      studentName_bangla: "ফাতিমা খাতুন",
      roll: 23,
      submittedAt: "2024-01-19 09:15",
      status: "graded",
      isLate: true,
      marks: 15,
      fileType: "image",
      feedback: "Good attempt but some calculation errors. Please review chapter 3.",
    },
    {
      id: 3,
      studentName: "Karim Hassan",
      studentName_bangla: "করিম হাসান",
      roll: 8,
      submittedAt: "2024-01-17 16:45",
      status: "submitted",
      isLate: false,
      fileType: "pdf",
    },
    {
      id: 4,
      studentName: "Rashida Begum",
      studentName_bangla: "রাশিদা বেগম",
      roll: 12,
      submittedAt: "2024-01-18 11:20",
      status: "graded",
      isLate: false,
      marks: 20,
      fileType: "pdf",
      feedback: "Perfect! Outstanding understanding of concepts.",
    },
  ])

  const handleAssignHomework = async () => {
    if (!homeworkForm.title || !homeworkForm.class || !homeworkForm.subject || !homeworkForm.dueDate) {
      alert("Please fill in all required fields")
      return
    }

    setIsCreating(true)

    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))

    const newHomework: Homework = {
      id: assignedHomework.length + 1,
      title: homeworkForm.title,
      title_bangla: homeworkForm.title_bangla,
      class: homeworkForm.class,
      subject: homeworkForm.subject,
      dueDate: homeworkForm.dueDate,
      totalMarks: Number.parseInt(homeworkForm.totalMarks),
      submitted: 0,
      total: 35, // Default class size
      status: "active",
    }

    setAssignedHomework((prev) => [newHomework, ...prev])

    // Reset form
    setHomeworkForm({
      title: "",
      title_bangla: "",
      description: "",
      description_bangla: "",
      instructions: "",
      instructions_bangla: "",
      class: "",
      section: "",
      subject: "",
      dueDate: "",
      dueTime: "",
      totalMarks: "",
      submissionType: "file",
      isGroupWork: false,
    })

    setIsCreating(false)
    alert("Homework assigned successfully! Students have been notified.")
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "completed":
        return "bg-green-500 text-white"
      case "active":
        return "bg-blue-500 text-white"
      case "overdue":
        return "bg-red-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  const getSubmissionStatusColor = (status: string, isLate: boolean) => {
    if (isLate) return "bg-yellow-500 text-white"
    switch (status) {
      case "graded":
        return "bg-green-500 text-white"
      case "submitted":
        return "bg-blue-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  const totalHomework = assignedHomework.length
  const activeHomework = assignedHomework.filter((h) => h.status === "active").length
  const completedHomework = assignedHomework.filter((h) => h.status === "completed").length
  const overdueHomework = assignedHomework.filter((h) => h.status === "overdue").length

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-indigo-900">Homework Management</h2>
          <h3 className="text-xl text-indigo-700">হোমওয়ার্ক ব্যবস্থাপনা</h3>
          <p className="text-gray-600">Create, assign and grade homework with smart features</p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-indigo-600">{totalHomework}</div>
          <div className="text-sm text-gray-600">Total Assigned</div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm font-medium">Active</p>
                <p className="text-2xl font-bold">{activeHomework}</p>
              </div>
              <Clock className="h-6 w-6 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm font-medium">Completed</p>
                <p className="text-2xl font-bold">{completedHomework}</p>
              </div>
              <CheckCircle className="h-6 w-6 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-100 text-sm font-medium">Overdue</p>
                <p className="text-2xl font-bold">{overdueHomework}</p>
              </div>
              <FileText className="h-6 w-6 text-red-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm font-medium">Avg Score</p>
                <p className="text-2xl font-bold">
                  {assignedHomework.filter((h) => h.averageScore).length > 0
                    ? (
                        assignedHomework.reduce((sum, h) => sum + (h.averageScore || 0), 0) /
                        assignedHomework.filter((h) => h.averageScore).length
                      ).toFixed(1)
                    : "0"}
                </p>
              </div>
              <Star className="h-6 w-6 text-purple-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Assign New Homework */}
      <Card className="border-2 border-indigo-200">
        <CardHeader className="bg-indigo-50">
          <CardTitle className="text-indigo-900 flex items-center">
            <FileText className="h-5 w-5 mr-2" />
            Assign New Homework
          </CardTitle>
          <CardDescription className="text-indigo-700">
            নতুন হোমওয়ার্ক প্রদান - Students can submit via mobile camera or file upload
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6 space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Title (English) *</Label>
              <Input
                placeholder="Enter homework title"
                value={homeworkForm.title}
                onChange={(e) => setHomeworkForm({ ...homeworkForm, title: e.target.value })}
                className="border-2 border-gray-300 focus:border-indigo-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Title (Bangla)</Label>
              <Input
                placeholder="হোমওয়ার্কের শিরোনাম লিখুন"
                value={homeworkForm.title_bangla}
                onChange={(e) => setHomeworkForm({ ...homeworkForm, title_bangla: e.target.value })}
                className="border-2 border-gray-300 focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Class *</Label>
              <Select
                value={homeworkForm.class}
                onValueChange={(value) => setHomeworkForm({ ...homeworkForm, class: value })}
              >
                <SelectTrigger className="border-2 border-gray-300 focus:border-indigo-500">
                  <SelectValue placeholder="Select Class" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Class 6-A">Class 6-A (ষষ্ঠ শ্রেণী-ক)</SelectItem>
                  <SelectItem value="Class 7-A">Class 7-A (সপ্তম শ্রেণী-ক)</SelectItem>
                  <SelectItem value="Class 8-A">Class 8-A (অষ্টম শ্রেণী-ক)</SelectItem>
                  <SelectItem value="Class 9-B">Class 9-B (নবম শ্রেণী-খ)</SelectItem>
                  <SelectItem value="Class 10-A">Class 10-A (দশম শ্রেণী-ক)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Subject *</Label>
              <Select
                value={homeworkForm.subject}
                onValueChange={(value) => setHomeworkForm({ ...homeworkForm, subject: value })}
              >
                <SelectTrigger className="border-2 border-gray-300 focus:border-indigo-500">
                  <SelectValue placeholder="Select Subject" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Mathematics">Mathematics (গণিত)</SelectItem>
                  <SelectItem value="English">English (ইংরেজি)</SelectItem>
                  <SelectItem value="Bangla">Bangla (বাংলা)</SelectItem>
                  <SelectItem value="Physics">Physics (পদার্থবিজ্ঞান)</SelectItem>
                  <SelectItem value="Chemistry">Chemistry (রসায়ন)</SelectItem>
                  <SelectItem value="Biology">Biology (জীববিজ্ঞান)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Total Marks *</Label>
              <Input
                type="number"
                placeholder="20"
                value={homeworkForm.totalMarks}
                onChange={(e) => setHomeworkForm({ ...homeworkForm, totalMarks: e.target.value })}
                className="border-2 border-gray-300 focus:border-indigo-500"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-gray-700 font-semibold">Description (English) *</Label>
            <Textarea
              placeholder="Describe the homework assignment..."
              value={homeworkForm.description}
              onChange={(e) => setHomeworkForm({ ...homeworkForm, description: e.target.value })}
              rows={3}
              className="border-2 border-gray-300 focus:border-indigo-500 resize-none"
            />
          </div>

          <div className="space-y-2">
            <Label className="text-gray-700 font-semibold">Description (Bangla)</Label>
            <Textarea
              placeholder="হোমওয়ার্ক অ্যাসাইনমেন্টের বর্ণনা দিন..."
              value={homeworkForm.description_bangla}
              onChange={(e) => setHomeworkForm({ ...homeworkForm, description_bangla: e.target.value })}
              rows={3}
              className="border-2 border-gray-300 focus:border-indigo-500 resize-none"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Due Date *</Label>
              <Input
                type="date"
                value={homeworkForm.dueDate}
                onChange={(e) => setHomeworkForm({ ...homeworkForm, dueDate: e.target.value })}
                className="border-2 border-gray-300 focus:border-indigo-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Due Time</Label>
              <Input
                type="time"
                value={homeworkForm.dueTime}
                onChange={(e) => setHomeworkForm({ ...homeworkForm, dueTime: e.target.value })}
                className="border-2 border-gray-300 focus:border-indigo-500"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Submission Type</Label>
              <Select
                value={homeworkForm.submissionType}
                onValueChange={(value) => setHomeworkForm({ ...homeworkForm, submissionType: value })}
              >
                <SelectTrigger className="border-2 border-gray-300 focus:border-indigo-500">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="file">📁 File Upload</SelectItem>
                  <SelectItem value="text">📝 Text Submission</SelectItem>
                  <SelectItem value="both">📁📝 Both File & Text</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="flex items-center space-x-4">
            <label className="flex items-center space-x-2 cursor-pointer">
              <input
                type="checkbox"
                checked={homeworkForm.isGroupWork}
                onChange={(e) => setHomeworkForm({ ...homeworkForm, isGroupWork: e.target.checked })}
                className="w-4 h-4 text-indigo-600 rounded focus:ring-indigo-500"
              />
              <span className="text-sm font-semibold text-indigo-600">👥 Group Work Assignment</span>
            </label>
          </div>

          <Button
            onClick={handleAssignHomework}
            disabled={isCreating}
            className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-4 text-lg"
          >
            {isCreating ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                Creating Assignment...
              </>
            ) : (
              <>
                <FileText className="h-5 w-5 mr-2" />
                Assign Homework & Notify Students
              </>
            )}
          </Button>
        </CardContent>
      </Card>

      {/* Assigned Homework List */}
      <Card className="border-2 border-green-200">
        <CardHeader className="bg-green-50">
          <CardTitle className="text-green-900">Assigned Homework</CardTitle>
          <CardDescription>প্রদত্ত হোমওয়ার্ক তালিকা - Track submissions and grade work</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            {assignedHomework.map((homework) => (
              <Card key={homework.id} className="border border-gray-200 hover:border-green-300 transition-colors">
                <CardContent className="p-6">
                  <div className="flex items-start justify-between mb-4">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <h3 className="text-xl font-bold text-gray-900">{homework.title}</h3>
                        <Badge className={`${getStatusColor(homework.status)} px-3 py-1 font-semibold`}>
                          {homework.status.toUpperCase()}
                        </Badge>
                      </div>
                      <p className="text-gray-600 mb-2">{homework.title_bangla}</p>
                      <div className="flex items-center space-x-6 text-sm text-gray-500">
                        <span>
                          📚 {homework.class} • {homework.subject}
                        </span>
                        <span>📅 Due: {homework.dueDate}</span>
                        <span>📊 {homework.totalMarks} marks</span>
                        {homework.averageScore && <span>⭐ Avg: {homework.averageScore.toFixed(1)}</span>}
                      </div>
                    </div>
                  </div>

                  <div className="mb-4">
                    <div className="flex items-center justify-between mb-2">
                      <span className="text-sm font-semibold text-gray-700">
                        Submission Progress: {homework.submitted}/{homework.total}
                      </span>
                      <span className="text-sm text-gray-600">
                        {Math.round((homework.submitted / homework.total) * 100)}%
                      </span>
                    </div>
                    <Progress value={(homework.submitted / homework.total) * 100} className="h-3" />
                  </div>

                  <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                    <div className="text-center p-3 bg-blue-50 rounded-lg">
                      <div className="text-2xl font-bold text-blue-600">{homework.submitted}</div>
                      <div className="text-xs text-blue-700">Submitted</div>
                    </div>
                    <div className="text-center p-3 bg-orange-50 rounded-lg">
                      <div className="text-2xl font-bold text-orange-600">{homework.total - homework.submitted}</div>
                      <div className="text-xs text-orange-700">Pending</div>
                    </div>
                    <div className="text-center p-3 bg-green-50 rounded-lg">
                      <div className="text-2xl font-bold text-green-600">
                        {submissions.filter((s) => s.status === "graded").length}
                      </div>
                      <div className="text-xs text-green-700">Graded</div>
                    </div>
                    <div className="text-center p-3 bg-purple-50 rounded-lg">
                      <div className="text-2xl font-bold text-purple-600">{homework.totalMarks}</div>
                      <div className="text-xs text-purple-700">Max Marks</div>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button
                      onClick={() => setSelectedHomework(homework.id)}
                      className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold"
                    >
                      <Eye className="h-4 w-4 mr-2" />
                      View Submissions ({homework.submitted})
                    </Button>
                    <Button className="flex-1 bg-green-600 hover:bg-green-700 text-white font-semibold">
                      <CheckCircle className="h-4 w-4 mr-2" />
                      Grade Work
                    </Button>
                    <Button
                      variant="outline"
                      className="border-2 border-gray-300 text-gray-700 font-semibold bg-transparent"
                    >
                      <Download className="h-4 w-4 mr-2" />
                      Export
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Recent Submissions */}
      <Card className="border-2 border-purple-200">
        <CardHeader className="bg-purple-50">
          <CardTitle className="text-purple-900">Recent Submissions</CardTitle>
          <CardDescription>সাম্প্রতিক জমাদান - Latest student submissions</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            {submissions.map((submission) => (
              <Card key={submission.id} className="border border-gray-200 hover:border-purple-300 transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                        <span className="text-purple-600 font-bold text-lg">{submission.roll}</span>
                      </div>
                      <div className="flex-1">
                        <h3 className="font-bold text-gray-900">{submission.studentName}</h3>
                        <p className="text-sm text-gray-600">{submission.studentName_bangla}</p>
                        <div className="flex items-center space-x-4 mt-1">
                          <span className="text-xs text-gray-500">📅 {submission.submittedAt}</span>
                          <Badge variant="outline" className="text-xs">
                            {submission.fileType.toUpperCase()}
                          </Badge>
                          {submission.isLate && <Badge className="bg-yellow-500 text-white text-xs">LATE</Badge>}
                        </div>
                        {submission.feedback && (
                          <p className="text-sm text-green-700 mt-2 bg-green-50 p-2 rounded">
                            💬 {submission.feedback}
                          </p>
                        )}
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      {submission.marks && (
                        <Badge className="bg-green-500 text-white px-3 py-2 text-lg font-bold">
                          {submission.marks}/20
                        </Badge>
                      )}
                      <Badge
                        className={`${getSubmissionStatusColor(submission.status, submission.isLate)} px-3 py-1 font-semibold`}
                      >
                        {submission.status.toUpperCase()}
                      </Badge>
                      <Button
                        variant="outline"
                        size="sm"
                        className="border-2 border-purple-300 text-purple-700 font-semibold bg-transparent"
                      >
                        <Eye className="h-4 w-4 mr-1" />
                        View
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
