"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { CheckCircle, Calendar, TrendingUp, AlertTriangle, Search, Send, UserCheck } from "lucide-react"

interface Student {
  id: number
  name: string
  name_bangla: string
  roll: number
  status: "present" | "absent" | "late"
  lastAttendance: number
  totalClasses: number
  photo?: string
}

interface ClassInfo {
  id: string
  name: string
  name_bangla: string
  subject: string
  subject_bangla: string
  students: number
  time: string
}

export function AttendancePanel() {
  const [selectedClass, setSelectedClass] = useState<string>("class-8a-math")
  const [searchTerm, setSearchTerm] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)

  const [classes] = useState<ClassInfo[]>([
    {
      id: "class-8a-math",
      name: "Class 8-A",
      name_bangla: "অষ্টম শ্রেণী-ক",
      subject: "Mathematics",
      subject_bangla: "গণিত",
      students: 35,
      time: "09:45 - 10:30",
    },
    {
      id: "class-9b-math",
      name: "Class 9-B",
      name_bangla: "নবম শ্রেণী-খ",
      subject: "Mathematics",
      subject_bangla: "গণিত",
      students: 32,
      time: "08:45 - 09:30",
    },
    {
      id: "class-10a-math",
      name: "Class 10-A",
      name_bangla: "দশম শ্রেণী-ক",
      subject: "Mathematics",
      subject_bangla: "গণিত",
      students: 38,
      time: "08:00 - 08:45",
    },
  ])

  const [students, setStudents] = useState<Student[]>([
    {
      id: 1,
      name: "Ahmed Rahman",
      name_bangla: "আহমেদ রহমান",
      roll: 1,
      status: "present",
      lastAttendance: 18,
      totalClasses: 20,
    },
    {
      id: 2,
      name: "Fatima Khatun",
      name_bangla: "ফাতিমা খাতুন",
      roll: 2,
      status: "present",
      lastAttendance: 19,
      totalClasses: 20,
    },
    {
      id: 3,
      name: "Karim Hassan",
      name_bangla: "করিম হাসান",
      roll: 3,
      status: "absent",
      lastAttendance: 15,
      totalClasses: 20,
    },
    {
      id: 4,
      name: "Rashida Begum",
      name_bangla: "রাশিদা বেগম",
      roll: 4,
      status: "present",
      lastAttendance: 20,
      totalClasses: 20,
    },
    {
      id: 5,
      name: "Nasir Uddin",
      name_bangla: "নাসির উদ্দিন",
      roll: 5,
      status: "late",
      lastAttendance: 17,
      totalClasses: 20,
    },
    {
      id: 6,
      name: "Shahida Akter",
      name_bangla: "শাহিদা আক্তার",
      roll: 6,
      status: "present",
      lastAttendance: 19,
      totalClasses: 20,
    },
    {
      id: 7,
      name: "Mizanur Rahman",
      name_bangla: "মিজানুর রহমান",
      roll: 7,
      status: "absent",
      lastAttendance: 12,
      totalClasses: 20,
    },
    {
      id: 8,
      name: "Nasreen Khatun",
      name_bangla: "নাসরিন খাতুন",
      roll: 8,
      status: "present",
      lastAttendance: 18,
      totalClasses: 20,
    },
  ])

  const updateStudentStatus = (studentId: number, status: "present" | "absent" | "late") => {
    setStudents((prev) => prev.map((student) => (student.id === studentId ? { ...student, status } : student)))
  }

  const markAllPresent = () => {
    setStudents((prev) => prev.map((student) => ({ ...student, status: "present" as const })))
  }

  const submitAttendance = async () => {
    setIsSubmitting(true)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 2000))
    setIsSubmitting(false)
    alert("Attendance submitted successfully!")
  }

  const filteredStudents = students.filter(
    (student) =>
      student.name.toLowerCase().includes(searchTerm.toLowerCase()) || student.roll.toString().includes(searchTerm),
  )

  const stats = {
    present: students.filter((s) => s.status === "present").length,
    absent: students.filter((s) => s.status === "absent").length,
    late: students.filter((s) => s.status === "late").length,
    total: students.length,
  }

  const attendanceRate = (((stats.present + stats.late) / stats.total) * 100).toFixed(1)

  const irregularStudents = students.filter((s) => s.lastAttendance / s.totalClasses < 0.8)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-green-900">Smart Attendance Management</h2>
          <h3 className="text-xl text-green-700">স্মার্ট উপস্থিতি ব্যবস্থাপনা</h3>
          <p className="text-gray-600">Take attendance with one-click actions and smart insights</p>
        </div>
        <div className="text-right">
          <div className="text-2xl font-bold text-green-600">{attendanceRate}%</div>
          <div className="text-sm text-gray-600">Today's Rate</div>
        </div>
      </div>

      {/* Class Selection */}
      <Card className="border-2 border-green-200 bg-green-50">
        <CardContent className="p-6">
          <div className="flex items-center space-x-4">
            <div className="flex-1">
              <Select value={selectedClass} onValueChange={setSelectedClass}>
                <SelectTrigger className="border-2 border-green-300 focus:border-green-500 bg-white">
                  <SelectValue placeholder="Select Class & Section" />
                </SelectTrigger>
                <SelectContent>
                  {classes.map((cls) => (
                    <SelectItem key={cls.id} value={cls.id}>
                      {cls.name} - {cls.subject} ({cls.name_bangla} - {cls.subject_bangla}) • {cls.time}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <Button onClick={markAllPresent} className="bg-green-600 hover:bg-green-700 text-white font-bold px-6">
              <UserCheck className="h-4 w-4 mr-2" />
              Mark All Present
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Today's Attendance Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm font-medium">Present</p>
                <p className="text-3xl font-bold">{stats.present}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-100 text-sm font-medium">Absent</p>
                <p className="text-3xl font-bold">{stats.absent}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-yellow-500 to-yellow-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-yellow-100 text-sm font-medium">Late</p>
                <p className="text-3xl font-bold">{stats.late}</p>
              </div>
              <Calendar className="h-8 w-8 text-yellow-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm font-medium">Rate</p>
                <p className="text-3xl font-bold">{attendanceRate}%</p>
              </div>
              <TrendingUp className="h-8 w-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card className="border-2 border-blue-200">
        <CardContent className="p-4">
          <div className="relative">
            <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
            <Input
              placeholder="Search by name or roll number..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 border-2 border-gray-300 focus:border-blue-500"
            />
          </div>
        </CardContent>
      </Card>

      {/* Student List */}
      <Card className="border-2 border-gray-200">
        <CardHeader className="bg-gray-50">
          <CardTitle className="text-gray-900">Student Attendance</CardTitle>
          <CardDescription>ছাত্র উপস্থিতি - Click to mark attendance</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredStudents.map((student) => (
              <Card
                key={student.id}
                className={`border-2 transition-all cursor-pointer ${
                  student.status === "present"
                    ? "border-green-300 bg-green-50"
                    : student.status === "absent"
                      ? "border-red-300 bg-red-50"
                      : student.status === "late"
                        ? "border-yellow-300 bg-yellow-50"
                        : "border-gray-300 bg-white"
                }`}
              >
                <CardContent className="p-4">
                  <div className="flex items-center space-x-3 mb-3">
                    <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                      <span className="text-blue-600 font-bold text-lg">{student.roll}</span>
                    </div>
                    <div className="flex-1">
                      <h3 className="font-bold text-gray-900">{student.name}</h3>
                      <p className="text-sm text-gray-600">{student.name_bangla}</p>
                      <p className="text-xs text-gray-500">
                        {student.lastAttendance}/{student.totalClasses} classes
                      </p>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-2">
                    <Button
                      onClick={() => updateStudentStatus(student.id, "present")}
                      variant={student.status === "present" ? "default" : "outline"}
                      className={`text-xs font-bold ${
                        student.status === "present"
                          ? "bg-green-600 hover:bg-green-700 text-white"
                          : "border-green-300 text-green-700 hover:bg-green-50"
                      }`}
                    >
                      Present
                    </Button>
                    <Button
                      onClick={() => updateStudentStatus(student.id, "late")}
                      variant={student.status === "late" ? "default" : "outline"}
                      className={`text-xs font-bold ${
                        student.status === "late"
                          ? "bg-yellow-600 hover:bg-yellow-700 text-white"
                          : "border-yellow-300 text-yellow-700 hover:bg-yellow-50"
                      }`}
                    >
                      Late
                    </Button>
                    <Button
                      onClick={() => updateStudentStatus(student.id, "absent")}
                      variant={student.status === "absent" ? "default" : "outline"}
                      className={`text-xs font-bold ${
                        student.status === "absent"
                          ? "bg-red-600 hover:bg-red-700 text-white"
                          : "border-red-300 text-red-700 hover:bg-red-50"
                      }`}
                    >
                      Absent
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Irregular Students Alert */}
      {irregularStudents.length > 0 && (
        <Card className="border-2 border-orange-300 bg-orange-50">
          <CardHeader>
            <CardTitle className="text-orange-900 flex items-center">
              <AlertTriangle className="h-5 w-5 mr-2" />
              Students with Low Attendance
            </CardTitle>
            <CardDescription>কম উপস্থিতির ছাত্রছাত্রী - Below 80% attendance</CardDescription>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {irregularStudents.map((student) => (
                <div key={student.id} className="flex items-center justify-between p-4 bg-white rounded-lg border">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-red-100 rounded-full flex items-center justify-center">
                      <span className="text-red-600 font-bold">{student.roll}</span>
                    </div>
                    <div>
                      <p className="font-semibold text-gray-900">{student.name}</p>
                      <p className="text-sm text-gray-600">{student.name_bangla}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="destructive" className="font-bold">
                      {((student.lastAttendance / student.totalClasses) * 100).toFixed(0)}%
                    </Badge>
                    <p className="text-xs text-gray-500 mt-1">
                      {student.lastAttendance}/{student.totalClasses}
                    </p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Submit Button */}
      <Card className="border-2 border-blue-200 bg-blue-50">
        <CardContent className="p-6">
          <Button
            onClick={submitAttendance}
            disabled={isSubmitting}
            className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 text-lg"
          >
            {isSubmitting ? (
              <>
                <div className="animate-spin rounded-full h-5 w-5 border-b-2 border-white mr-2"></div>
                Submitting Attendance...
              </>
            ) : (
              <>
                <Send className="h-5 w-5 mr-2" />
                Submit Today's Attendance
              </>
            )}
          </Button>
        </CardContent>
      </Card>
    </div>
  )
}
