"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BarChart3, TrendingUp, Users, GraduationCap, DollarSign, MessageSquare, Download } from "lucide-react"

export function AdvancedAnalytics() {
  const [timeRange, setTimeRange] = useState("month")
  const [selectedClass, setSelectedClass] = useState("all")

  const [analyticsData] = useState({
    attendance: {
      overall: 92.5,
      byClass: [
        { class: "Class 6", attendance: 94.2 },
        { class: "Class 7", attendance: 91.8 },
        { class: "Class 8", attendance: 89.5 },
        { class: "Class 9", attendance: 93.1 },
        { class: "Class 10", attendance: 95.3 },
      ],
      trend: [
        { date: "Jan 1", rate: 89.2 },
        { date: "Jan 8", rate: 91.5 },
        { date: "Jan 15", rate: 92.8 },
        { date: "Jan 22", rate: 94.1 },
        { date: "Jan 29", rate: 92.5 },
      ],
    },
    academic: {
      averageGPA: 3.85,
      passRate: 94.2,
      bySubject: [
        { subject: "Mathematics", average: 3.9, passRate: 92 },
        { subject: "English", average: 4.1, passRate: 96 },
        { subject: "Science", average: 3.7, passRate: 89 },
        { subject: "Bangla", average: 4.0, passRate: 95 },
      ],
    },
    financial: {
      totalRevenue: 4250000,
      collectionRate: 87.5,
      pendingAmount: 625000,
      monthlyTrend: [
        { month: "Sep", collected: 380000, pending: 45000 },
        { month: "Oct", collected: 420000, pending: 38000 },
        { month: "Nov", collected: 395000, pending: 52000 },
        { month: "Dec", collected: 445000, pending: 35000 },
        { month: "Jan", collected: 425000, pending: 62500 },
      ],
    },
    communication: {
      totalMessagesSent: 2450,
      deliveryRate: 96.8,
      responseRate: 23.5,
      byType: [
        { type: "Attendance Alert", count: 850, deliveryRate: 97.2 },
        { type: "Fee Reminder", count: 420, deliveryRate: 95.8 },
        { type: "Result Notification", count: 380, deliveryRate: 98.1 },
        { type: "General Announcement", count: 800, deliveryRate: 96.5 },
      ],
    },
  })

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Advanced Analytics</h2>
          <p className="text-gray-600">Comprehensive school performance insights</p>
        </div>
        <div className="flex space-x-2">
          <Select value={timeRange} onValueChange={setTimeRange}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="week">This Week</SelectItem>
              <SelectItem value="month">This Month</SelectItem>
              <SelectItem value="quarter">This Quarter</SelectItem>
              <SelectItem value="year">This Year</SelectItem>
            </SelectContent>
          </Select>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export Report
          </Button>
        </div>
      </div>

      <Tabs defaultValue="attendance" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="attendance">Attendance</TabsTrigger>
          <TabsTrigger value="academic">Academic</TabsTrigger>
          <TabsTrigger value="financial">Financial</TabsTrigger>
          <TabsTrigger value="communication">Communication</TabsTrigger>
        </TabsList>

        <TabsContent value="attendance" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <Users className="h-5 w-5 mr-2" />
                  Overall Attendance
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">{analyticsData.attendance.overall}%</div>
                <p className="text-sm text-gray-600">This month average</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Attendance Trend</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="h-32 flex items-center justify-center text-gray-500">
                  <TrendingUp className="h-8 w-8 mr-2" />
                  <span>Trend chart will be implemented</span>
                </div>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Class-wise Performance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="space-y-2">
                  {analyticsData.attendance.byClass.map((item, index) => (
                    <div key={index} className="flex justify-between items-center">
                      <span className="text-sm">{item.class}</span>
                      <span className="font-semibold">{item.attendance}%</span>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Detailed Attendance Analysis</CardTitle>
              <CardDescription>Weekly attendance patterns and insights</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center text-gray-500">
                <BarChart3 className="h-16 w-16 mr-4" />
                <span>Detailed attendance charts will be implemented here</span>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="academic" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <GraduationCap className="h-5 w-5 mr-2" />
                  Average GPA
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">{analyticsData.academic.averageGPA}</div>
                <p className="text-sm text-gray-600">Out of 5.0</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Pass Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">{analyticsData.academic.passRate}%</div>
                <p className="text-sm text-gray-600">Students passing</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Top Performing Subject</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-xl font-bold text-purple-600">English</div>
                <p className="text-sm text-gray-600">4.1 GPA Average</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Subject-wise Performance</CardTitle>
              <CardDescription>Academic performance breakdown by subject</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analyticsData.academic.bySubject.map((subject, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-semibold">{subject.subject}</h4>
                      <p className="text-sm text-gray-600">Pass Rate: {subject.passRate}%</p>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold">{subject.average}</div>
                      <p className="text-xs text-gray-600">Average GPA</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="financial" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <DollarSign className="h-5 w-5 mr-2" />
                  Total Revenue
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">
                  ৳{(analyticsData.financial.totalRevenue / 1000000).toFixed(2)}M
                </div>
                <p className="text-sm text-gray-600">This academic year</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Collection Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">{analyticsData.financial.collectionRate}%</div>
                <p className="text-sm text-gray-600">Fees collected</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Pending Amount</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-orange-600">
                  ৳{(analyticsData.financial.pendingAmount / 1000).toFixed(0)}K
                </div>
                <p className="text-sm text-gray-600">Outstanding fees</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Monthly Revenue Trend</CardTitle>
              <CardDescription>Fee collection patterns over time</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64 flex items-center justify-center text-gray-500">
                <BarChart3 className="h-16 w-16 mr-4" />
                <span>Revenue trend charts will be implemented here</span>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="communication" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center">
                  <MessageSquare className="h-5 w-5 mr-2" />
                  Messages Sent
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-blue-600">{analyticsData.communication.totalMessagesSent}</div>
                <p className="text-sm text-gray-600">This month</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Delivery Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-green-600">{analyticsData.communication.deliveryRate}%</div>
                <p className="text-sm text-gray-600">Successfully delivered</p>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Response Rate</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="text-3xl font-bold text-purple-600">{analyticsData.communication.responseRate}%</div>
                <p className="text-sm text-gray-600">Parents responded</p>
              </CardContent>
            </Card>
          </div>

          <Card>
            <CardHeader>
              <CardTitle>Message Type Analysis</CardTitle>
              <CardDescription>Performance breakdown by message category</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {analyticsData.communication.byType.map((type, index) => (
                  <div key={index} className="flex items-center justify-between p-3 border rounded-lg">
                    <div>
                      <h4 className="font-semibold">{type.type}</h4>
                      <p className="text-sm text-gray-600">Delivery: {type.deliveryRate}%</p>
                    </div>
                    <div className="text-right">
                      <div className="text-lg font-bold">{type.count}</div>
                      <p className="text-xs text-gray-600">Messages sent</p>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
