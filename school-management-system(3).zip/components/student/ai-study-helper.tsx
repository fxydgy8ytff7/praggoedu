"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Brain, Send, HelpCircle, Lightbulb, MessageSquare, Star } from "lucide-react"

export function AIStudyHelper() {
  const [question, setQuestion] = useState("")
  const [subject, setSubject] = useState("")
  const [language, setLanguage] = useState("both")
  const [isLoading, setIsLoading] = useState(false)

  const [chatHistory] = useState([
    {
      id: 1,
      type: "user",
      message: "What is the quadratic formula?",
      message_bangla: "দ্বিঘাত সূত্র কী?",
      timestamp: "10:30 AM",
    },
    {
      id: 2,
      type: "ai",
      message: "The quadratic formula is: x = (-b ± √(b²-4ac)) / 2a",
      message_bangla: "দ্বিঘাত সূত্র হল: x = (-b ± √(b²-4ac)) / 2a",
      explanation: "This formula is used to find the roots of a quadratic equation ax² + bx + c = 0",
      explanation_bangla: "এই সূত্রটি ax² + bx + c = 0 দ্বিঘাত সমীকরণের মূল বের করতে ব্যবহৃত হয়",
      timestamp: "10:31 AM",
      subject: "Mathematics",
    },
    {
      id: 3,
      type: "user",
      message: "Can you give me an example?",
      message_bangla: "আপনি কি আমাকে একটি উদাহরণ দিতে পারেন?",
      timestamp: "10:32 AM",
    },
    {
      id: 4,
      type: "ai",
      message: "Let's solve x² - 5x + 6 = 0",
      message_bangla: "অবশ্যই! আসুন x² - 5x + 6 = 0 সমাধান করি",
      explanation: "Here a=1, b=-5, c=6. Using the formula: x = (5 ± √(25-24))/2 = (5 ± 1)/2. So x = 3 or x = 2",
      explanation_bangla: "এখানে a=1, b=-5, c=6। সূত্র ব্যবহার করে: x = (5 ± √(25-24))/2 = (5 ± 1)/2। সুতরাং x = 3 অথবা x = 2",
      timestamp: "10:33 AM",
      subject: "Mathematics",
    },
  ])

  const [quickQuestions] = useState([
    {
      question: "Explain photosynthesis process",
      question_bangla: "সালোকসংশ্লেষণ প্রক্রিয়া ব্যাখ্যা করুন",
      subject: "Biology",
      difficulty: "medium",
    },
    {
      question: "What are Newton's laws of motion?",
      question_bangla: "নিউটনের গতির সূত্রগুলি কী?",
      subject: "Physics",
      difficulty: "easy",
    },
    {
      question: "How to solve linear equations?",
      question_bangla: "রৈখিক সমীকরণ কীভাবে সমাধান করবেন?",
      subject: "Mathematics",
      difficulty: "easy",
    },
    {
      question: "Explain the periodic table structure",
      question_bangla: "পর্যায় সারণির গঠন ব্যাখ্যা করুন",
      subject: "Chemistry",
      difficulty: "medium",
    },
  ])

  const handleSendQuestion = async () => {
    if (!question.trim()) return

    setIsLoading(true)
    // Simulate AI response
    setTimeout(() => {
      setIsLoading(false)
      setQuestion("")
    }, 2000)
  }

  const handleQuickQuestion = (quickQ: any) => {
    setQuestion(quickQ.question)
    setSubject(quickQ.subject.toLowerCase())
  }

  const getDifficultyColor = (difficulty: string) => {
    switch (difficulty) {
      case "easy":
        return "bg-green-500 text-white"
      case "medium":
        return "bg-yellow-500 text-white"
      case "hard":
        return "bg-red-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  return (
    <Card className="border-2 border-purple-200">
      <CardHeader className="bg-purple-50">
        <CardTitle className="text-purple-900 flex items-center text-xl">
          <Brain className="h-6 w-6 mr-2" />
          AI Study Helper
        </CardTitle>
        <CardDescription className="text-purple-700">
          AI অধ্যয়ন সহায়ক - Get instant help with homework and textbook explanations
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-6">
          {/* Quick Questions */}
          <div>
            <h3 className="text-lg font-bold text-gray-900 mb-3 flex items-center">
              <Lightbulb className="h-5 w-5 mr-2 text-yellow-500" />
              Quick Questions
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {quickQuestions.map((quickQ, index) => (
                <Card
                  key={index}
                  className="border border-gray-200 hover:border-purple-300 cursor-pointer transition-colors"
                  onClick={() => handleQuickQuestion(quickQ)}
                >
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between mb-2">
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300 text-xs">
                        {quickQ.subject}
                      </Badge>
                      <Badge className={`${getDifficultyColor(quickQ.difficulty)} text-xs px-2 py-1`}>
                        {quickQ.difficulty}
                      </Badge>
                    </div>
                    <p className="text-sm font-semibold text-gray-900">{quickQ.question}</p>
                    <p className="text-xs text-gray-600 mt-1">{quickQ.question_bangla}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>

          {/* Ask Question Form */}
          <Card className="bg-blue-50 border-2 border-blue-200">
            <CardContent className="p-6">
              <h3 className="text-lg font-bold text-blue-900 mb-4 flex items-center">
                <HelpCircle className="h-5 w-5 mr-2" />
                Ask Your Question
              </h3>
              <div className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Select value={subject} onValueChange={setSubject}>
                    <SelectTrigger className="border-2 border-blue-300 focus:border-blue-500">
                      <SelectValue placeholder="Select Subject" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mathematics">Mathematics (গণিত)</SelectItem>
                      <SelectItem value="physics">Physics (পদার্থবিজ্ঞান)</SelectItem>
                      <SelectItem value="chemistry">Chemistry (রসায়ন)</SelectItem>
                      <SelectItem value="biology">Biology (জীববিজ্ঞান)</SelectItem>
                      <SelectItem value="english">English (ইংরেজি)</SelectItem>
                      <SelectItem value="bangla">Bangla (বাংলা)</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select value={language} onValueChange={setLanguage}>
                    <SelectTrigger className="border-2 border-blue-300 focus:border-blue-500">
                      <SelectValue placeholder="Response Language" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="english">English Only</SelectItem>
                      <SelectItem value="bangla">Bangla Only</SelectItem>
                      <SelectItem value="both">Both Languages</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Textarea
                  placeholder="Type your question here... (এখানে আপনার প্রশ্ন লিখুন...)"
                  value={question}
                  onChange={(e) => setQuestion(e.target.value)}
                  rows={4}
                  className="border-2 border-blue-300 focus:border-blue-500 resize-none"
                />

                <Button
                  onClick={handleSendQuestion}
                  disabled={!question.trim() || isLoading}
                  className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-3"
                >
                  {isLoading ? (
                    <>
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      AI is thinking...
                    </>
                  ) : (
                    <>
                      <Send className="h-5 w-5 mr-2" />
                      Ask AI Helper
                    </>
                  )}
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Chat History */}
          <Card className="border-2 border-green-200">
            <CardHeader className="bg-green-50">
              <CardTitle className="text-green-900 flex items-center">
                <MessageSquare className="h-5 w-5 mr-2" />
                Recent Conversations
              </CardTitle>
              <CardDescription>সাম্প্রতিক কথোপকথন</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4 max-h-96 overflow-y-auto">
                {chatHistory.map((chat) => (
                  <div key={chat.id} className={`flex ${chat.type === "user" ? "justify-end" : "justify-start"}`}>
                    <div
                      className={`max-w-[80%] p-4 rounded-lg ${
                        chat.type === "user"
                          ? "bg-blue-500 text-white"
                          : "bg-gray-100 text-gray-900 border-2 border-gray-200"
                      }`}
                    >
                      <div className="flex items-center space-x-2 mb-2">
                        {chat.type === "ai" && <Brain className="h-4 w-4 text-purple-600" />}
                        {chat.type === "user" && <MessageSquare className="h-4 w-4" />}
                        <span className="text-xs font-semibold">{chat.type === "ai" ? "AI Helper" : "You"}</span>
                        <span className="text-xs opacity-75">{chat.timestamp}</span>
                        {chat.subject && (
                          <Badge variant="outline" className="text-xs">
                            {chat.subject}
                          </Badge>
                        )}
                      </div>
                      <p className="text-sm font-semibold">{chat.message}</p>
                      {chat.message_bangla && <p className="text-xs mt-1 opacity-90">{chat.message_bangla}</p>}
                      {chat.explanation && (
                        <div className="mt-3 p-3 bg-white bg-opacity-20 rounded-lg">
                          <p className="text-sm">{chat.explanation}</p>
                          {chat.explanation_bangla && (
                            <p className="text-xs mt-1 opacity-90">{chat.explanation_bangla}</p>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Study Statistics */}
          <Card className="bg-gradient-to-r from-purple-50 to-indigo-50 border-2 border-purple-200">
            <CardContent className="p-6">
              <h3 className="text-lg font-bold text-purple-900 mb-4 flex items-center">
                <Star className="h-5 w-5 mr-2 text-yellow-500" />
                Your Study Progress
              </h3>
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-2xl font-bold text-blue-600">45</div>
                  <div className="text-sm text-blue-700">Questions Asked</div>
                  <div className="text-xs text-blue-600">প্রশ্ন করেছেন</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-green-600">28</div>
                  <div className="text-sm text-green-700">Study Hours</div>
                  <div className="text-xs text-green-600">অধ্যয়নের ঘন্টা</div>
                </div>
                <div>
                  <div className="text-2xl font-bold text-purple-600">6</div>
                  <div className="text-sm text-purple-700">Subjects Covered</div>
                  <div className="text-xs text-purple-600">বিষয় কভার</div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </CardContent>
    </Card>
  )
}
