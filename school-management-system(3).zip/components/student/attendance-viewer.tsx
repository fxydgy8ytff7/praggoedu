"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, CheckCircle, XCircle, Clock, TrendingUp, Download } from "lucide-react"

export function AttendanceViewer() {
  const [selectedMonth, setSelectedMonth] = useState("january")
  const [selectedSubject, setSelectedSubject] = useState("all")

  const [attendanceData] = useState({
    overall: 92.5,
    thisMonth: 94.2,
    lastMonth: 90.8,
    trend: "improving",
    totalDays: 20,
    presentDays: 18,
    absentDays: 2,
    lateDays: 0,
  })

  const [monthlyCalendar] = useState([
    { date: 1, day: "Mon", status: "present" },
    { date: 2, day: "Tue", status: "present" },
    { date: 3, day: "Wed", status: "absent" },
    { date: 4, day: "Thu", status: "present" },
    { date: 5, day: "Fri", status: "present" },
    { date: 6, day: "Sat", status: "holiday" },
    { date: 7, day: "Sun", status: "holiday" },
    { date: 8, day: "Mon", status: "present" },
    { date: 9, day: "Tue", status: "present" },
    { date: 10, day: "Wed", status: "present" },
    { date: 11, day: "Thu", status: "late" },
    { date: 12, day: "Fri", status: "present" },
    { date: 13, day: "Sat", status: "holiday" },
    { date: 14, day: "Sun", status: "holiday" },
    { date: 15, day: "Mon", status: "present" },
    { date: 16, day: "Tue", status: "present" },
    { date: 17, day: "Wed", status: "present" },
    { date: 18, day: "Thu", status: "present" },
    { date: 19, day: "Fri", status: "absent" },
    { date: 20, day: "Sat", status: "holiday" },
  ])

  const [subjectWiseAttendance] = useState([
    { subject: "Mathematics", subject_bangla: "গণিত", attendance: 95, present: 19, total: 20, trend: "stable" },
    { subject: "Physics", subject_bangla: "পদার্থবিজ্ঞান", attendance: 90, present: 18, total: 20, trend: "improving" },
    { subject: "Chemistry", subject_bangla: "রসায়ন", attendance: 88, present: 17, total: 19, trend: "declining" },
    { subject: "Biology", subject_bangla: "জীববিজ্ঞান", attendance: 92, present: 18, total: 19, trend: "stable" },
    { subject: "English", subject_bangla: "ইংরেজি", attendance: 94, present: 19, total: 20, trend: "improving" },
    { subject: "Bangla", subject_bangla: "বাংলা", attendance: 96, present: 19, total: 20, trend: "stable" },
  ])

  const getStatusColor = (status: string) => {
    switch (status) {
      case "present":
        return "bg-green-500 text-white"
      case "absent":
        return "bg-red-500 text-white"
      case "late":
        return "bg-yellow-500 text-white"
      case "holiday":
        return "bg-gray-300 text-gray-600"
      default:
        return "bg-gray-200 text-gray-600"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "present":
        return <CheckCircle className="h-3 w-3" />
      case "absent":
        return <XCircle className="h-3 w-3" />
      case "late":
        return <Clock className="h-3 w-3" />
      default:
        return null
    }
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "improving":
        return <TrendingUp className="h-4 w-4 text-green-500" />
      case "declining":
        return <TrendingUp className="h-4 w-4 text-red-500 rotate-180" />
      case "stable":
        return <TrendingUp className="h-4 w-4 text-blue-500 rotate-90" />
      default:
        return null
    }
  }

  return (
    <Card className="border-2 border-blue-200">
      <CardHeader className="bg-blue-50">
        <CardTitle className="text-blue-900 flex items-center text-xl">
          <Calendar className="h-6 w-6 mr-2" />
          Attendance Viewer
        </CardTitle>
        <CardDescription className="text-blue-700">
          উপস্থিতি দর্শক - Monthly calendar view with color-coded status
        </CardDescription>
      </CardHeader>
      <CardContent className="p-6">
        <div className="space-y-6">
          {/* Overall Stats */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-green-100 text-sm font-medium">Overall</p>
                    <p className="text-2xl font-bold">{attendanceData.overall}%</p>
                  </div>
                  <CheckCircle className="h-6 w-6 text-green-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-blue-100 text-sm font-medium">Present Days</p>
                    <p className="text-2xl font-bold">{attendanceData.presentDays}</p>
                  </div>
                  <CheckCircle className="h-6 w-6 text-blue-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-red-100 text-sm font-medium">Absent Days</p>
                    <p className="text-2xl font-bold">{attendanceData.absentDays}</p>
                  </div>
                  <XCircle className="h-6 w-6 text-red-200" />
                </div>
              </CardContent>
            </Card>

            <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
              <CardContent className="p-4">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-purple-100 text-sm font-medium">This Month</p>
                    <p className="text-2xl font-bold">{attendanceData.thisMonth}%</p>
                  </div>
                  <TrendingUp className="h-6 w-6 text-purple-200" />
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Filters */}
          <div className="flex items-center space-x-4">
            <Select value={selectedMonth} onValueChange={setSelectedMonth}>
              <SelectTrigger className="w-48 border-2 border-blue-300 focus:border-blue-500">
                <SelectValue placeholder="Select Month" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="january">January 2024</SelectItem>
                <SelectItem value="december">December 2023</SelectItem>
                <SelectItem value="november">November 2023</SelectItem>
              </SelectContent>
            </Select>

            <Select value={selectedSubject} onValueChange={setSelectedSubject}>
              <SelectTrigger className="w-48 border-2 border-blue-300 focus:border-blue-500">
                <SelectValue placeholder="Select Subject" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Subjects</SelectItem>
                <SelectItem value="mathematics">Mathematics</SelectItem>
                <SelectItem value="physics">Physics</SelectItem>
                <SelectItem value="chemistry">Chemistry</SelectItem>
                <SelectItem value="biology">Biology</SelectItem>
              </SelectContent>
            </Select>

            <Button className="bg-blue-600 hover:bg-blue-700 text-white font-semibold">
              <Download className="h-4 w-4 mr-2" />
              Download Report
            </Button>
          </div>

          {/* Calendar View */}
          <Card className="bg-gray-50 border-2 border-gray-200">
            <CardHeader>
              <CardTitle className="text-gray-900">Monthly Calendar</CardTitle>
              <CardDescription>মাসিক ক্যালেন্ডার - January 2024</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-7 gap-2 mb-4">
                {["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"].map((day) => (
                  <div key={day} className="text-center font-semibold text-gray-700 p-2">
                    {day}
                  </div>
                ))}
              </div>
              <div className="grid grid-cols-7 gap-2">
                {monthlyCalendar.map((day) => (
                  <div
                    key={day.date}
                    className={`aspect-square flex items-center justify-center rounded-lg text-sm font-semibold ${getStatusColor(day.status)} transition-colors hover:opacity-80`}
                  >
                    <div className="text-center">
                      <div>{day.date}</div>
                      <div className="mt-1">{getStatusIcon(day.status)}</div>
                    </div>
                  </div>
                ))}
              </div>
              <div className="flex items-center justify-center space-x-6 mt-6">
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-green-500 rounded"></div>
                  <span className="text-sm text-gray-700">Present (উপস্থিত)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-red-500 rounded"></div>
                  <span className="text-sm text-gray-700">Absent (অনুপস্থিত)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-yellow-500 rounded"></div>
                  <span className="text-sm text-gray-700">Late (দেরি)</span>
                </div>
                <div className="flex items-center space-x-2">
                  <div className="w-4 h-4 bg-gray-300 rounded"></div>
                  <span className="text-sm text-gray-700">Holiday (ছুটি)</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Subject-wise Attendance */}
          <Card className="border-2 border-green-200">
            <CardHeader className="bg-green-50">
              <CardTitle className="text-green-900">Subject-wise Attendance</CardTitle>
              <CardDescription>বিষয়ভিত্তিক উপস্থিতি</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-4">
                {subjectWiseAttendance.map((subject, index) => (
                  <div key={index} className="flex items-center justify-between p-4 bg-gray-50 rounded-lg border">
                    <div className="flex items-center space-x-4">
                      <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                        <CheckCircle className="h-6 w-6 text-blue-600" />
                      </div>
                      <div>
                        <h3 className="font-bold text-gray-900">{subject.subject}</h3>
                        <p className="text-sm text-gray-600">{subject.subject_bangla}</p>
                        <p className="text-xs text-gray-500">
                          {subject.present}/{subject.total} classes attended
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center space-x-4">
                      {getTrendIcon(subject.trend)}
                      <div className="text-right">
                        <div className="text-2xl font-bold text-green-600">{subject.attendance}%</div>
                        <Progress value={subject.attendance} className="w-24 mt-1" />
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </CardContent>
    </Card>
  )
}
