"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { FileText, Send, CheckCircle, Clock, XCircle, Calendar } from "lucide-react"

export function LeaveApplication() {
  const [leaveForm, setLeaveForm] = useState({
    reason: "",
    reason_bangla: "",
    startDate: "",
    endDate: "",
    description: "",
    description_bangla: "",
    guardianContact: "",
    emergencyContact: "",
  })

  const [previousApplications] = useState([
    {
      id: 1,
      reason: "Family Emergency",
      reason_bangla: "পারিবারিক জরুরি অবস্থা",
      startDate: "2024-01-20",
      endDate: "2024-01-22",
      days: 3,
      status: "approved",
      appliedDate: "2024-01-18",
      approvedBy: "Dr. Rashida Begum",
      approvedDate: "2024-01-19",
      description: "Need to attend family function in village",
    },
    {
      id: 2,
      reason: "Medical Appointment",
      reason_bangla: "চিকিৎসা সাক্ষাৎ",
      startDate: "2024-01-15",
      endDate: "2024-01-15",
      days: 1,
      status: "approved",
      appliedDate: "2024-01-14",
      approvedBy: "Dr. Rashida Begum",
      approvedDate: "2024-01-14",
      description: "Doctor appointment for regular checkup",
    },
    {
      id: 3,
      reason: "Sick Leave",
      reason_bangla: "অসুস্থতার ছুটি",
      startDate: "2024-01-25",
      endDate: "2024-01-27",
      days: 3,
      status: "pending",
      appliedDate: "2024-01-24",
      description: "Fever and cold symptoms",
    },
  ])

  const handleSubmitApplication = () => {
    console.log("Submitting leave application:", leaveForm)
    // Reset form after submission
    setLeaveForm({
      reason: "",
      reason_bangla: "",
      startDate: "",
      endDate: "",
      description: "",
      description_bangla: "",
      guardianContact: "",
      emergencyContact: "",
    })
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-green-500 text-white"
      case "rejected":
        return "bg-red-500 text-white"
      case "pending":
        return "bg-yellow-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="h-4 w-4" />
      case "rejected":
        return <XCircle className="h-4 w-4" />
      case "pending":
        return <Clock className="h-4 w-4" />
      default:
        return <Clock className="h-4 w-4" />
    }
  }

  const calculateDays = () => {
    if (leaveForm.startDate && leaveForm.endDate) {
      const start = new Date(leaveForm.startDate)
      const end = new Date(leaveForm.endDate)
      const diffTime = Math.abs(end.getTime() - start.getTime())
      const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24)) + 1
      return diffDays
    }
    return 0
  }

  return (
    <div className="space-y-6">
      {/* New Application Form */}
      <Card className="border-2 border-blue-200">
        <CardHeader className="bg-blue-50">
          <CardTitle className="text-blue-900 flex items-center text-xl">
            <FileText className="h-6 w-6 mr-2" />
            Submit Leave Application
          </CardTitle>
          <CardDescription className="text-blue-700">
            ছুটির আবেদন জমা দিন - Submit to Head Teacher for approval
          </CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-700 font-semibold">Reason (English)</Label>
                <Select
                  value={leaveForm.reason}
                  onValueChange={(value) => setLeaveForm({ ...leaveForm, reason: value })}
                >
                  <SelectTrigger className="border-2 border-gray-300 focus:border-blue-500">
                    <SelectValue placeholder="Select reason for leave" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="sick">Sick Leave</SelectItem>
                    <SelectItem value="family_emergency">Family Emergency</SelectItem>
                    <SelectItem value="medical_appointment">Medical Appointment</SelectItem>
                    <SelectItem value="personal">Personal Reasons</SelectItem>
                    <SelectItem value="other">Other</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-gray-700 font-semibold">Reason (Bangla)</Label>
                <Input
                  placeholder="ছুটির কারণ লিখুন"
                  value={leaveForm.reason_bangla}
                  onChange={(e) => setLeaveForm({ ...leaveForm, reason_bangla: e.target.value })}
                  className="border-2 border-gray-300 focus:border-blue-500"
                />
              </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-700 font-semibold">Start Date</Label>
                <Input
                  type="date"
                  value={leaveForm.startDate}
                  onChange={(e) => setLeaveForm({ ...leaveForm, startDate: e.target.value })}
                  className="border-2 border-gray-300 focus:border-blue-500"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-gray-700 font-semibold">End Date</Label>
                <Input
                  type="date"
                  value={leaveForm.endDate}
                  onChange={(e) => setLeaveForm({ ...leaveForm, endDate: e.target.value })}
                  className="border-2 border-gray-300 focus:border-blue-500"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-gray-700 font-semibold">Total Days</Label>
                <div className="border-2 border-gray-300 rounded-md p-3 bg-gray-50">
                  <span className="text-2xl font-bold text-blue-600">{calculateDays()}</span>
                  <span className="text-sm text-gray-600 ml-2">days</span>
                </div>
              </div>
            </div>

            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Description (English)</Label>
              <Textarea
                placeholder="Provide detailed description of your leave request..."
                value={leaveForm.description}
                onChange={(e) => setLeaveForm({ ...leaveForm, description: e.target.value })}
                rows={3}
                className="border-2 border-gray-300 focus:border-blue-500 resize-none"
              />
            </div>

            <div className="space-y-2">
              <Label className="text-gray-700 font-semibold">Description (Bangla)</Label>
              <Textarea
                placeholder="আপনার ছুটির আবেদনের বিস্তারিত বিবরণ দিন..."
                value={leaveForm.description_bangla}
                onChange={(e) => setLeaveForm({ ...leaveForm, description_bangla: e.target.value })}
                rows={3}
                className="border-2 border-gray-300 focus:border-blue-500 resize-none"
              />
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-gray-700 font-semibold">Guardian Contact</Label>
                <Input
                  placeholder="+8801XXXXXXXXX"
                  value={leaveForm.guardianContact}
                  onChange={(e) => setLeaveForm({ ...leaveForm, guardianContact: e.target.value })}
                  className="border-2 border-gray-300 focus:border-blue-500"
                />
              </div>
              <div className="space-y-2">
                <Label className="text-gray-700 font-semibold">Emergency Contact</Label>
                <Input
                  placeholder="+8801XXXXXXXXX"
                  value={leaveForm.emergencyContact}
                  onChange={(e) => setLeaveForm({ ...leaveForm, emergencyContact: e.target.value })}
                  className="border-2 border-gray-300 focus:border-blue-500"
                />
              </div>
            </div>

            <Button
              onClick={handleSubmitApplication}
              className="w-full bg-blue-600 hover:bg-blue-700 text-white font-bold py-4 text-lg"
              disabled={!leaveForm.reason || !leaveForm.startDate || !leaveForm.endDate || !leaveForm.description}
            >
              <Send className="h-5 w-5 mr-2" />
              Submit Leave Application
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Previous Applications */}
      <Card className="border-2 border-green-200">
        <CardHeader className="bg-green-50">
          <CardTitle className="text-green-900 flex items-center">
            <Calendar className="h-5 w-5 mr-2" />
            Previous Applications
          </CardTitle>
          <CardDescription>পূর্ববর্তী আবেদনসমূহ - View approval status</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="space-y-4">
            {previousApplications.map((application) => (
              <Card key={application.id} className="border border-gray-200 hover:border-green-300 transition-colors">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between mb-3">
                    <div>
                      <h3 className="text-lg font-bold text-gray-900">{application.reason}</h3>
                      <p className="text-gray-600">{application.reason_bangla}</p>
                      <p className="text-sm text-gray-600 mt-1">{application.description}</p>
                    </div>
                    <Badge className={`${getStatusColor(application.status)} px-3 py-1 font-semibold`}>
                      {getStatusIcon(application.status)}
                      <span className="ml-1 capitalize">{application.status}</span>
                    </Badge>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-3">
                    <div>
                      <p className="text-sm font-semibold text-gray-700">Leave Period:</p>
                      <p className="text-gray-900">
                        {application.startDate} to {application.endDate}
                      </p>
                      <p className="text-sm text-blue-600 font-semibold">{application.days} days</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-700">Applied Date:</p>
                      <p className="text-gray-900">{application.appliedDate}</p>
                    </div>
                    <div>
                      <p className="text-sm font-semibold text-gray-700">Status:</p>
                      <p className="text-gray-900 capitalize">{application.status}</p>
                      {application.approvedBy && (
                        <p className="text-sm text-green-600">Approved by: {application.approvedBy}</p>
                      )}
                    </div>
                  </div>

                  {application.status === "approved" && (
                    <div className="bg-green-50 border border-green-200 rounded-lg p-3">
                      <p className="text-sm text-green-800">
                        <strong>✓ Approved</strong> by {application.approvedBy} on {application.approvedDate}
                      </p>
                    </div>
                  )}

                  {application.status === "pending" && (
                    <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-3">
                      <p className="text-sm text-yellow-800">
                        <strong>⏳ Pending</strong> - Waiting for Head Teacher approval
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
