"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Brain, Wand2, FileText, Download, Eye, RefreshCw, Copy } from "lucide-react"

export function AIQuestionMaker() {
  const [questionForm, setQuestionForm] = useState({
    subject: "",
    class: "",
    chapter: "",
    chapter_bangla: "",
    questionType: "mcq",
    difficulty: "medium",
    numberOfQuestions: "5",
    sourceMaterial: "",
    language: "both",
  })

  const [generatedQuestions] = useState([
    {
      id: 1,
      type: "mcq",
      question: "What is the value of x in the equation 2x + 5 = 15?",
      question_bangla: "2x + 5 = 15 সমীকরণে x এর মান কত?",
      options: {
        A: "5",
        B: "10",
        C: "15",
        D: "20",
      },
      correctAnswer: "A",
      correctAnswer_bangla: "ক",
      explanation: "Subtract 5 from both sides: 2x = 10, then divide by 2: x = 5",
      explanation_bangla: "উভয় পক্ষ থেকে ৫ বিয়োগ করুন: 2x = 10, তারপর ২ দিয়ে ভাগ করুন: x = 5",
      difficulty: "medium",
      marks: 2,
    },
    {
      id: 2,
      type: "short",
      question: "Define quadratic equation and give an example.",
      question_bangla: "দ্বিঘাত সমীকরণের সংজ্ঞা দিন এবং একটি উদাহরণ দিন।",
      correctAnswer: "A quadratic equation is a polynomial equation of degree 2. Example: ax² + bx + c = 0",
      correctAnswer_bangla: "দ্বিঘাত সমীকরণ হল ২ ডিগ্রির একটি বহুপদী সমীকরণ। উদাহরণ: ax² + bx + c = 0",
      difficulty: "easy",
      marks: 3,
    },
    {
      id: 3,
      type: "broad",
      question: "Explain the different methods of solving quadratic equations with examples.",
      question_bangla: "উদাহরণসহ দ্বিঘাত সমীকরণ সমাধানের বিভিন্ন পদ্ধতি ব্যাখ্যা করুন।",
      correctAnswer: "Methods include: 1) Factoring, 2) Completing the square, 3) Quadratic formula",
      correctAnswer_bangla: "পদ্ধতিসমূহ: ১) উৎপাদকে বিশ্লেষণ, ২) পূর্ণবর্গ সম্পূর্ণকরণ, ৩) দ্বিঘাত সূত্র",
      difficulty: "hard",
      marks: 5,
    },
  ])

  const [questionBank] = useState([
    {
      id: 1,
      subject: "Mathematics",
      class: "Class 10",
      chapter: "Algebra",
      totalQuestions: 45,
      mcq: 20,
      short: 15,
      broad: 10,
      lastUpdated: "2024-01-15",
    },
    {
      id: 2,
      subject: "Mathematics",
      class: "Class 9",
      chapter: "Geometry",
      totalQuestions: 38,
      mcq: 18,
      short: 12,
      broad: 8,
      lastUpdated: "2024-01-14",
    },
    {
      id: 3,
      subject: "English",
      class: "Class 8",
      chapter: "Grammar",
      totalQuestions: 52,
      mcq: 25,
      short: 20,
      broad: 7,
      lastUpdated: "2024-01-13",
    },
  ])

  const handleGenerateQuestions = () => {
    console.log("Generating questions with AI:", questionForm)
  }

  const getQuestionTypeIcon = (type: string) => {
    switch (type) {
      case "mcq":
        return "MCQ"
      case "short":
        return "Short"
      case "broad":
        return "Broad"
      case "fill_blank":
        return "Fill"
      case "true_false":
        return "T/F"
      default:
        return "Q"
    }
  }

  return (
    <div className="space-y-6">
      <Tabs defaultValue="generate" className="space-y-4">
        <TabsList>
          <TabsTrigger value="generate">Generate Questions</TabsTrigger>
          <TabsTrigger value="bank">Question Bank</TabsTrigger>
          <TabsTrigger value="preview">Preview & Export</TabsTrigger>
        </TabsList>

        <TabsContent value="generate">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Brain className="h-5 w-5 mr-2" />
                AI Question Generator
              </CardTitle>
              <CardDescription>
                AI প্রশ্ন জেনারেটর - Auto-generate MCQ, short, and broad questions from syllabus
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Subject</Label>
                  <Select
                    value={questionForm.subject}
                    onValueChange={(value) => setQuestionForm({ ...questionForm, subject: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select Subject" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mathematics">Mathematics</SelectItem>
                      <SelectItem value="english">English</SelectItem>
                      <SelectItem value="bangla">Bangla</SelectItem>
                      <SelectItem value="physics">Physics</SelectItem>
                      <SelectItem value="chemistry">Chemistry</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Class</Label>
                  <Select
                    value={questionForm.class}
                    onValueChange={(value) => setQuestionForm({ ...questionForm, class: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select Class" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="class-6">Class 6</SelectItem>
                      <SelectItem value="class-7">Class 7</SelectItem>
                      <SelectItem value="class-8">Class 8</SelectItem>
                      <SelectItem value="class-9">Class 9</SelectItem>
                      <SelectItem value="class-10">Class 10</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Question Type</Label>
                  <Select
                    value={questionForm.questionType}
                    onValueChange={(value) => setQuestionForm({ ...questionForm, questionType: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="mcq">Multiple Choice (MCQ)</SelectItem>
                      <SelectItem value="short">Short Questions</SelectItem>
                      <SelectItem value="broad">Broad Questions</SelectItem>
                      <SelectItem value="fill_blank">Fill in the Blanks</SelectItem>
                      <SelectItem value="true_false">True/False</SelectItem>
                      <SelectItem value="mixed">Mixed Types</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>Chapter (English)</Label>
                  <Input
                    placeholder="Enter chapter name"
                    value={questionForm.chapter}
                    onChange={(e) => setQuestionForm({ ...questionForm, chapter: e.target.value })}
                  />
                </div>
                <div className="space-y-2">
                  <Label>Chapter (Bangla)</Label>
                  <Input
                    placeholder="অধ্যায়ের নাম লিখুন"
                    value={questionForm.chapter_bangla}
                    onChange={(e) => setQuestionForm({ ...questionForm, chapter_bangla: e.target.value })}
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <Label>Difficulty Level</Label>
                  <Select
                    value={questionForm.difficulty}
                    onValueChange={(value) => setQuestionForm({ ...questionForm, difficulty: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="easy">Easy</SelectItem>
                      <SelectItem value="medium">Medium</SelectItem>
                      <SelectItem value="hard">Hard</SelectItem>
                      <SelectItem value="mixed">Mixed</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Number of Questions</Label>
                  <Select
                    value={questionForm.numberOfQuestions}
                    onValueChange={(value) => setQuestionForm({ ...questionForm, numberOfQuestions: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="5">5 Questions</SelectItem>
                      <SelectItem value="10">10 Questions</SelectItem>
                      <SelectItem value="15">15 Questions</SelectItem>
                      <SelectItem value="20">20 Questions</SelectItem>
                      <SelectItem value="25">25 Questions</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>Language</Label>
                  <Select
                    value={questionForm.language}
                    onValueChange={(value) => setQuestionForm({ ...questionForm, language: value })}
                  >
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="english">English Only</SelectItem>
                      <SelectItem value="bangla">Bangla Only</SelectItem>
                      <SelectItem value="both">Both Languages</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="space-y-2">
                <Label>Source Material (Optional)</Label>
                <Textarea
                  placeholder="Paste textbook content, notes, or specific topics to generate questions from..."
                  value={questionForm.sourceMaterial}
                  onChange={(e) => setQuestionForm({ ...questionForm, sourceMaterial: e.target.value })}
                  rows={4}
                />
              </div>

              <div className="flex space-x-2">
                <Button onClick={handleGenerateQuestions} className="flex-1">
                  <Wand2 className="h-4 w-4 mr-2" />
                  Generate Questions with AI
                </Button>
                <Button variant="outline">
                  <RefreshCw className="h-4 w-4 mr-2" />
                  Regenerate
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="bank">
          <Card>
            <CardHeader>
              <CardTitle>Question Bank</CardTitle>
              <CardDescription>প্রশ্ন ব্যাংক - All generated questions organized by subject and chapter</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {questionBank.map((bank) => (
                  <div key={bank.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div>
                        <h3 className="font-semibold">
                          {bank.subject} - {bank.class}
                        </h3>
                        <p className="text-sm text-gray-600">Chapter: {bank.chapter}</p>
                        <p className="text-xs text-gray-500">Last updated: {bank.lastUpdated}</p>
                      </div>
                      <Badge variant="outline">{bank.totalQuestions} questions</Badge>
                    </div>

                    <div className="grid grid-cols-3 gap-4 mb-3">
                      <div className="text-center">
                        <div className="text-lg font-bold text-blue-600">{bank.mcq}</div>
                        <div className="text-xs text-gray-600">MCQ</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-green-600">{bank.short}</div>
                        <div className="text-xs text-gray-600">Short</div>
                      </div>
                      <div className="text-center">
                        <div className="text-lg font-bold text-purple-600">{bank.broad}</div>
                        <div className="text-xs text-gray-600">Broad</div>
                      </div>
                    </div>

                    <div className="flex space-x-2">
                      <Button variant="outline" size="sm">
                        <Eye className="h-4 w-4 mr-1" />
                        View Questions
                      </Button>
                      <Button variant="outline" size="sm">
                        <Download className="h-4 w-4 mr-1" />
                        Export
                      </Button>
                      <Button variant="outline" size="sm">
                        <Wand2 className="h-4 w-4 mr-1" />
                        Generate More
                      </Button>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="preview">
          <Card>
            <CardHeader>
              <CardTitle>Generated Questions Preview</CardTitle>
              <CardDescription>উৎপন্ন প্রশ্নের পূর্বরূপ - Review and export questions</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                {generatedQuestions.map((question, index) => (
                  <div key={question.id} className="border rounded-lg p-4">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center space-x-2">
                        <Badge variant="outline">{getQuestionTypeIcon(question.type)}</Badge>
                        <Badge variant="secondary">{question.difficulty}</Badge>
                        <Badge variant="outline">{question.marks} marks</Badge>
                      </div>
                      <div className="flex space-x-1">
                        <Button variant="ghost" size="sm">
                          <Copy className="h-4 w-4" />
                        </Button>
                        <Button variant="ghost" size="sm">
                          <RefreshCw className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <p className="font-medium">
                          Q{index + 1}. {question.question}
                        </p>
                        <p className="text-sm text-gray-600 mt-1">{question.question_bangla}</p>
                      </div>

                      {question.type === "mcq" && question.options && (
                        <div className="grid grid-cols-2 gap-2 ml-4">
                          {Object.entries(question.options).map(([key, value]) => (
                            <div
                              key={key}
                              className={`p-2 rounded ${key === question.correctAnswer ? "bg-green-50 border border-green-200" : "bg-gray-50"}`}
                            >
                              <span className="font-medium">{key})</span> {value}
                            </div>
                          ))}
                        </div>
                      )}

                      <div className="bg-blue-50 p-3 rounded">
                        <p className="text-sm font-medium text-blue-800">Answer:</p>
                        <p className="text-sm text-blue-700">{question.correctAnswer}</p>
                        {question.correctAnswer_bangla && (
                          <p className="text-sm text-blue-600">{question.correctAnswer_bangla}</p>
                        )}
                      </div>

                      {question.explanation && (
                        <div className="bg-gray-50 p-3 rounded">
                          <p className="text-sm font-medium text-gray-800">Explanation:</p>
                          <p className="text-sm text-gray-700">{question.explanation}</p>
                          {question.explanation_bangla && (
                            <p className="text-sm text-gray-600">{question.explanation_bangla}</p>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))}

                <div className="flex space-x-2 pt-4">
                  <Button className="flex-1">
                    <Download className="h-4 w-4 mr-2" />
                    Export as PDF
                  </Button>
                  <Button variant="outline" className="flex-1 bg-transparent">
                    <FileText className="h-4 w-4 mr-2" />
                    Export as Word
                  </Button>
                  <Button variant="outline" className="flex-1 bg-transparent">
                    <Copy className="h-4 w-4 mr-2" />
                    Copy to Clipboard
                  </Button>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
