"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Brain,
  TrendingUp,
  TrendingDown,
  Users,
  AlertTriangle,
  CheckCircle,
  BookOpen,
  Target,
  Lightbulb,
  BarChart3,
} from "lucide-react"

export function AIInsightsPanel() {
  const [selectedPeriod, setSelectedPeriod] = useState("this_month")

  const [aiInsights] = useState({
    weakStudents: [
      {
        name: "Ahmed Rahman",
        name_bangla: "আহমেদ রহমান",
        class: "Class 10-A",
        roll: 15,
        subjects: ["Mathematics", "Physics"],
        averageScore: 45,
        attendanceRate: 78,
        riskLevel: "high",
        recommendations: [
          "Schedule extra tutoring sessions",
          "Contact parents for discussion",
          "Provide additional practice materials",
        ],
        recommendations_bangla: [
          "অতিরিক্ত টিউটরিং সেশনের ব্যবস্থা করুন",
          "আলোচনার জন্য অভিভাবকদের সাথে যোগাযোগ করুন",
          "অতিরিক্ত অনুশীলনের উপকরণ প্রদান করুন",
        ],
      },
      {
        name: "Fatima Khatun",
        name_bangla: "ফাতিমা খাতুন",
        class: "Class 9-B",
        roll: 23,
        subjects: ["Chemistry", "Biology"],
        averageScore: 52,
        attendanceRate: 85,
        riskLevel: "medium",
        recommendations: [
          "Focus on practical experiments",
          "Pair with high-performing student",
          "Regular progress monitoring",
        ],
        recommendations_bangla: ["ব্যবহারিক পরীক্ষায় মনোযোগ দিন", "ভাল ছাত্রের সাথে জোড়া বানান", "নিয়মিত অগ্রগতি পর্যবেক্ষণ করুন"],
      },
    ],
    attendanceTrends: {
      overall: 92.5,
      thisWeek: 94.2,
      lastWeek: 90.8,
      trend: "improving",
      classWise: [
        { class: "Class 6", attendance: 95.2, trend: "stable" },
        { class: "Class 7", attendance: 93.8, trend: "improving" },
        { class: "Class 8", attendance: 91.5, trend: "declining" },
        { class: "Class 9", attendance: 92.1, trend: "stable" },
        { class: "Class 10", attendance: 89.7, trend: "declining" },
      ],
    },
    performanceAnalysis: {
      topPerformers: [
        { name: "Rashida Akter", class: "Class 10-A", score: 96.5 },
        { name: "Karim Hassan", class: "Class 9-A", score: 94.8 },
        { name: "Nasreen Begum", class: "Class 8-B", score: 93.2 },
      ],
      subjectAnalysis: [
        { subject: "Mathematics", average: 78.5, trend: "improving" },
        { subject: "English", average: 82.1, trend: "stable" },
        { subject: "Bangla", average: 85.3, trend: "improving" },
        { subject: "Physics", average: 74.2, trend: "declining" },
        { subject: "Chemistry", average: 76.8, trend: "stable" },
      ],
    },
    teacherInsights: [
      {
        teacher: "Ms. Sarah Ahmed",
        subject: "Mathematics",
        classEngagement: 87,
        studentProgress: 82,
        suggestions: ["Increase interactive activities", "Use more visual aids", "Implement peer learning"],
      },
      {
        teacher: "Mr. Karim Hassan",
        subject: "Physics",
        classEngagement: 79,
        studentProgress: 75,
        suggestions: ["Add more practical demonstrations", "Simplify complex concepts", "Regular concept revision"],
      },
    ],
  })

  const getRiskColor = (level: string) => {
    switch (level) {
      case "high":
        return "bg-red-500 text-white"
      case "medium":
        return "bg-yellow-500 text-white"
      case "low":
        return "bg-green-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  const getTrendIcon = (trend: string) => {
    switch (trend) {
      case "improving":
        return <TrendingUp className="h-4 w-4 text-green-500" />
      case "declining":
        return <TrendingDown className="h-4 w-4 text-red-500" />
      case "stable":
        return <Target className="h-4 w-4 text-blue-500" />
      default:
        return <Target className="h-4 w-4 text-gray-500" />
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-indigo-900">AI Insights Dashboard</h2>
          <h3 className="text-xl text-indigo-700">AI অন্তর্দৃষ্টি ড্যাশবোর্ড</h3>
          <p className="text-gray-600">Smart analytics and recommendations for better education outcomes</p>
        </div>
        <Button className="bg-indigo-600 hover:bg-indigo-700 text-white font-semibold">
          <BarChart3 className="h-4 w-4 mr-2" />
          Generate Report
        </Button>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-100 text-sm font-medium">At-Risk Students</p>
                <p className="text-3xl font-bold">{aiInsights.weakStudents.length}</p>
              </div>
              <AlertTriangle className="h-8 w-8 text-red-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-blue-500 to-blue-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm font-medium">Overall Attendance</p>
                <p className="text-3xl font-bold">{aiInsights.attendanceTrends.overall}%</p>
              </div>
              <Users className="h-8 w-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm font-medium">Top Performers</p>
                <p className="text-3xl font-bold">{aiInsights.performanceAnalysis.topPerformers.length}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-purple-500 to-purple-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-purple-100 text-sm font-medium">AI Suggestions</p>
                <p className="text-3xl font-bold">12</p>
              </div>
              <Brain className="h-8 w-8 text-purple-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="weak-students" className="space-y-4">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="weak-students">At-Risk Students</TabsTrigger>
          <TabsTrigger value="attendance">Attendance Trends</TabsTrigger>
          <TabsTrigger value="performance">Performance Analysis</TabsTrigger>
          <TabsTrigger value="teacher-insights">Teacher Insights</TabsTrigger>
        </TabsList>

        <TabsContent value="weak-students">
          <Card className="border-2 border-red-200">
            <CardHeader className="bg-red-50">
              <CardTitle className="text-red-900 flex items-center">
                <AlertTriangle className="h-5 w-5 mr-2" />
                Students Needing Extra Attention
              </CardTitle>
              <CardDescription>ঝুঁকিপূর্ণ ছাত্রদের তালিকা - AI-identified students who need immediate support</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-6">
                {aiInsights.weakStudents.map((student, index) => (
                  <Card key={index} className="border-2 border-orange-200 bg-orange-50">
                    <CardContent className="p-6">
                      <div className="flex items-start justify-between mb-4">
                        <div className="flex items-center space-x-4">
                          <div className="w-12 h-12 bg-red-100 rounded-full flex items-center justify-center">
                            <span className="text-red-600 font-bold">{student.roll}</span>
                          </div>
                          <div>
                            <h3 className="text-xl font-bold text-gray-900">{student.name}</h3>
                            <p className="text-gray-600">{student.name_bangla}</p>
                            <p className="text-sm text-gray-600">{student.class}</p>
                          </div>
                        </div>
                        <Badge className={`${getRiskColor(student.riskLevel)} px-3 py-1 font-semibold`}>
                          {student.riskLevel.toUpperCase()} RISK
                        </Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-4">
                        <div>
                          <p className="text-sm font-semibold text-gray-700 mb-2">Weak Subjects:</p>
                          <div className="flex flex-wrap gap-2">
                            {student.subjects.map((subject, idx) => (
                              <Badge key={idx} variant="outline" className="bg-red-100 text-red-700 border-red-300">
                                {subject}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-gray-700 mb-2">Average Score:</p>
                          <div className="flex items-center space-x-2">
                            <Progress value={student.averageScore} className="flex-1" />
                            <span className="text-lg font-bold text-red-600">{student.averageScore}%</span>
                          </div>
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-gray-700 mb-2">Attendance Rate:</p>
                          <div className="flex items-center space-x-2">
                            <Progress value={student.attendanceRate} className="flex-1" />
                            <span className="text-lg font-bold text-orange-600">{student.attendanceRate}%</span>
                          </div>
                        </div>
                      </div>

                      <div className="bg-white rounded-lg p-4 border border-blue-200">
                        <h4 className="font-semibold text-blue-900 mb-3 flex items-center">
                          <Lightbulb className="h-4 w-4 mr-2" />
                          AI Recommendations:
                        </h4>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div>
                            <p className="text-sm font-medium text-gray-700 mb-2">English:</p>
                            <ul className="space-y-1">
                              {student.recommendations.map((rec, idx) => (
                                <li key={idx} className="text-sm text-gray-600 flex items-start">
                                  <CheckCircle className="h-3 w-3 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                                  {rec}
                                </li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <p className="text-sm font-medium text-gray-700 mb-2">বাংলা:</p>
                            <ul className="space-y-1">
                              {student.recommendations_bangla.map((rec, idx) => (
                                <li key={idx} className="text-sm text-gray-600 flex items-start">
                                  <CheckCircle className="h-3 w-3 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                                  {rec}
                                </li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>

                      <div className="flex space-x-3 mt-4">
                        <Button className="flex-1 bg-blue-600 hover:bg-blue-700 text-white font-semibold">
                          <Users className="h-4 w-4 mr-2" />
                          Contact Parents
                        </Button>
                        <Button className="flex-1 bg-green-600 hover:bg-green-700 text-white font-semibold">
                          <BookOpen className="h-4 w-4 mr-2" />
                          Create Study Plan
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="attendance">
          <Card className="border-2 border-blue-200">
            <CardHeader className="bg-blue-50">
              <CardTitle className="text-blue-900 flex items-center">
                <TrendingUp className="h-5 w-5 mr-2" />
                Attendance Trends Analysis
              </CardTitle>
              <CardDescription>উপস্থিতির প্রবণতা বিশ্লেষণ - AI-powered attendance pattern analysis</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-200">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-bold text-blue-900 mb-4">Overall Trend</h3>
                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <span className="text-gray-700">This Week:</span>
                        <div className="flex items-center space-x-2">
                          <span className="text-2xl font-bold text-green-600">
                            {aiInsights.attendanceTrends.thisWeek}%
                          </span>
                          <TrendingUp className="h-4 w-4 text-green-500" />
                        </div>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-700">Last Week:</span>
                        <span className="text-xl font-bold text-gray-600">{aiInsights.attendanceTrends.lastWeek}%</span>
                      </div>
                      <div className="flex items-center justify-between">
                        <span className="text-gray-700">Overall:</span>
                        <span className="text-xl font-bold text-blue-600">{aiInsights.attendanceTrends.overall}%</span>
                      </div>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border border-gray-200">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-bold text-gray-900 mb-4">Class-wise Analysis</h3>
                    <div className="space-y-3">
                      {aiInsights.attendanceTrends.classWise.map((classData, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <span className="font-semibold text-gray-900">{classData.class}</span>
                            {getTrendIcon(classData.trend)}
                          </div>
                          <div className="flex items-center space-x-2">
                            <Progress value={classData.attendance} className="w-20" />
                            <span className="font-bold text-gray-900 min-w-[50px]">{classData.attendance}%</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="performance">
          <Card className="border-2 border-green-200">
            <CardHeader className="bg-green-50">
              <CardTitle className="text-green-900 flex items-center">
                <BarChart3 className="h-5 w-5 mr-2" />
                Academic Performance Analysis
              </CardTitle>
              <CardDescription>একাডেমিক কর্মক্ষমতা বিশ্লেষণ - Comprehensive performance insights</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <Card className="bg-gradient-to-r from-green-50 to-emerald-50 border border-green-200">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-bold text-green-900 mb-4 flex items-center">
                      <CheckCircle className="h-5 w-5 mr-2" />
                      Top Performers
                    </h3>
                    <div className="space-y-3">
                      {aiInsights.performanceAnalysis.topPerformers.map((student, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-white rounded-lg border">
                          <div>
                            <p className="font-semibold text-gray-900">{student.name}</p>
                            <p className="text-sm text-gray-600">{student.class}</p>
                          </div>
                          <Badge className="bg-green-500 text-white px-3 py-1 font-bold">{student.score}%</Badge>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>

                <Card className="border border-gray-200">
                  <CardContent className="p-6">
                    <h3 className="text-lg font-bold text-gray-900 mb-4 flex items-center">
                      <BookOpen className="h-5 w-5 mr-2" />
                      Subject-wise Performance
                    </h3>
                    <div className="space-y-3">
                      {aiInsights.performanceAnalysis.subjectAnalysis.map((subject, index) => (
                        <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                          <div className="flex items-center space-x-3">
                            <span className="font-semibold text-gray-900">{subject.subject}</span>
                            {getTrendIcon(subject.trend)}
                          </div>
                          <div className="flex items-center space-x-2">
                            <Progress value={subject.average} className="w-20" />
                            <span className="font-bold text-gray-900 min-w-[50px]">{subject.average}%</span>
                          </div>
                        </div>
                      ))}
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="teacher-insights">
          <Card className="border-2 border-purple-200">
            <CardHeader className="bg-purple-50">
              <CardTitle className="text-purple-900 flex items-center">
                <Brain className="h-5 w-5 mr-2" />
                Teacher Performance Insights
              </CardTitle>
              <CardDescription>শিক্ষক কর্মক্ষমতার অন্তর্দৃষ্টি - AI recommendations for teaching improvement</CardDescription>
            </CardHeader>
            <CardContent className="p-6">
              <div className="space-y-6">
                {aiInsights.teacherInsights.map((teacher, index) => (
                  <Card key={index} className="border border-purple-200 bg-purple-50">
                    <CardContent className="p-6">
                      <div className="flex items-center justify-between mb-4">
                        <div>
                          <h3 className="text-xl font-bold text-gray-900">{teacher.teacher}</h3>
                          <p className="text-gray-600">{teacher.subject}</p>
                        </div>
                        <Badge variant="outline" className="bg-purple-100 text-purple-700 border-purple-300">
                          {teacher.subject}
                        </Badge>
                      </div>

                      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                        <div>
                          <p className="text-sm font-semibold text-gray-700 mb-2">Class Engagement:</p>
                          <div className="flex items-center space-x-2">
                            <Progress value={teacher.classEngagement} className="flex-1" />
                            <span className="text-lg font-bold text-purple-600">{teacher.classEngagement}%</span>
                          </div>
                        </div>
                        <div>
                          <p className="text-sm font-semibold text-gray-700 mb-2">Student Progress:</p>
                          <div className="flex items-center space-x-2">
                            <Progress value={teacher.studentProgress} className="flex-1" />
                            <span className="text-lg font-bold text-blue-600">{teacher.studentProgress}%</span>
                          </div>
                        </div>
                      </div>

                      <div className="bg-white rounded-lg p-4 border border-purple-200">
                        <h4 className="font-semibold text-purple-900 mb-3 flex items-center">
                          <Lightbulb className="h-4 w-4 mr-2" />
                          AI Suggestions for Improvement:
                        </h4>
                        <ul className="space-y-2">
                          {teacher.suggestions.map((suggestion, idx) => (
                            <li key={idx} className="text-sm text-gray-700 flex items-start">
                              <CheckCircle className="h-3 w-3 text-green-500 mr-2 mt-0.5 flex-shrink-0" />
                              {suggestion}
                            </li>
                          ))}
                        </ul>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
