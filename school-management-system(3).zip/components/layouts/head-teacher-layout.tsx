"use client"

import type React from "react"

import {
  SidebarProvider,
  Sidebar,
  SidebarContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuItem,
  SidebarMenuButton,
  SidebarFooter,
  SidebarTrigger,
  SidebarInset,
} from "@/components/ui/sidebar"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import {
  LayoutDashboard,
  Users,
  MessageSquare,
  UserCheck,
  BarChart3,
  Settings,
  LogOut,
  User,
  ChevronDown,
  GraduationCap,
  Brain,
  Calendar,
  FileText,
  DollarSign,
  Bell,
  Shield,
} from "lucide-react"

const menuItems = [
  { title: "Dashboard", title_bangla: "ড্যাশবোর্ড", icon: LayoutDashboard, href: "/head-teacher/dashboard" },
  { title: "SMS Panel", title_bangla: "SMS প্যানেল", icon: MessageSquare, href: "/head-teacher/sms" },
  { title: "Leave Approval", title_bangla: "ছুটি অনুমোদন", icon: UserCheck, href: "/head-teacher/leaves" },
  { title: "Teacher Management", title_bangla: "শিক্ষক ব্যবস্থাপনা", icon: Users, href: "/head-teacher/teachers" },
  { title: "Student Management", title_bangla: "ছাত্র ব্যবস্থাপনা", icon: GraduationCap, href: "/head-teacher/students" },
  { title: "AI Insights", title_bangla: "AI অন্তর্দৃষ্টি", icon: Brain, href: "/head-teacher/ai-insights" },
  { title: "Analytics", title_bangla: "বিশ্লেষণ", icon: BarChart3, href: "/head-teacher/analytics" },
  { title: "Events", title_bangla: "অনুষ্ঠান", icon: Calendar, href: "/head-teacher/events" },
  { title: "Reports", title_bangla: "রিপোর্ট", icon: FileText, href: "/head-teacher/reports" },
  { title: "Finance", title_bangla: "অর্থ", icon: DollarSign, href: "/head-teacher/finance" },
  { title: "Notifications", title_bangla: "বিজ্ঞপ্তি", icon: Bell, href: "/head-teacher/notifications" },
  { title: "Settings", title_bangla: "সেটিংস", icon: Settings, href: "/head-teacher/settings" },
]

export function HeadTeacherLayout({ children }: { children: React.ReactNode }) {
  return (
    <SidebarProvider>
      <Sidebar>
        <SidebarHeader>
          <div className="flex items-center space-x-2 px-2 py-4">
            <Shield className="h-8 w-8 text-red-600" />
            <div>
              <h2 className="font-bold text-lg">Head Teacher</h2>
              <h3 className="text-sm text-gray-600">প্রধান শিক্ষক</h3>
              <p className="text-xs text-gray-600">Portal</p>
            </div>
          </div>
        </SidebarHeader>

        <SidebarContent>
          <SidebarMenu>
            {menuItems.map((item) => (
              <SidebarMenuItem key={item.title}>
                <SidebarMenuButton asChild>
                  <a href={item.href} className="flex items-center space-x-3">
                    <item.icon className="h-4 w-4" />
                    <div className="flex flex-col">
                      <span className="text-sm">{item.title}</span>
                      <span className="text-xs text-gray-500">{item.title_bangla}</span>
                    </div>
                  </a>
                </SidebarMenuButton>
              </SidebarMenuItem>
            ))}
          </SidebarMenu>
        </SidebarContent>

        <SidebarFooter>
          <SidebarMenu>
            <SidebarMenuItem>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <SidebarMenuButton>
                    <Avatar className="h-6 w-6">
                      <AvatarImage src="/placeholder.svg?height=24&width=24" />
                      <AvatarFallback>RB</AvatarFallback>
                    </Avatar>
                    <div className="flex flex-col text-left">
                      <span className="text-sm">Dr. Rashida</span>
                      <span className="text-xs text-gray-500">ডঃ রাশিদা</span>
                    </div>
                    <ChevronDown className="ml-auto h-4 w-4" />
                  </SidebarMenuButton>
                </DropdownMenuTrigger>
                <DropdownMenuContent side="top" className="w-[--radix-popper-anchor-width]">
                  <DropdownMenuItem>
                    <User className="h-4 w-4 mr-2" />
                    Profile
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <Settings className="h-4 w-4 mr-2" />
                    Settings
                  </DropdownMenuItem>
                  <DropdownMenuItem>
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </SidebarMenuItem>
          </SidebarMenu>
        </SidebarFooter>
      </Sidebar>

      <SidebarInset>
        <header className="flex h-16 shrink-0 items-center gap-2 border-b px-4">
          <SidebarTrigger className="-ml-1" />
          <div className="ml-auto flex items-center space-x-4">
            <Button variant="outline" size="sm">
              <Brain className="h-4 w-4 mr-2" />
              AI Assistant
            </Button>
            <Button variant="outline" size="sm">
              Dhaka Model High School
            </Button>
          </div>
        </header>
        <main className="flex-1 p-6">{children}</main>
      </SidebarInset>
    </SidebarProvider>
  )
}
