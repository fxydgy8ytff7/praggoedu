"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Input } from "@/components/ui/input"
import { CheckCircle, XCircle, Clock, User, Calendar, FileText, Search } from "lucide-react"

export function LeaveApprovalPanel() {
  const [filterStatus, setFilterStatus] = useState("all")
  const [filterType, setFilterType] = useState("all")
  const [searchTerm, setSearchTerm] = useState("")

  const [leaveApplications] = useState([
    {
      id: 1,
      applicantName: "Ahmed Rahman",
      applicantName_bangla: "আহমেদ রহমান",
      type: "student",
      class: "Class 10-A",
      roll: 15,
      reason: "Family Emergency",
      reason_bangla: "পারিবারিক জরুরি অবস্থা",
      startDate: "2024-01-20",
      endDate: "2024-01-22",
      days: 3,
      status: "pending",
      appliedDate: "2024-01-18",
      guardianContact: "+8801712345678",
      description: "Need to attend family function in village",
      description_bangla: "গ্রামে পারিবারিক অনুষ্ঠানে যোগদান করতে হবে",
    },
    {
      id: 2,
      applicantName: "Ms. Sarah Ahmed",
      applicantName_bangla: "সারাহ আহমেদ",
      type: "teacher",
      department: "Mathematics",
      reason: "Medical Leave",
      reason_bangla: "চিকিৎসা ছুটি",
      startDate: "2024-01-25",
      endDate: "2024-01-27",
      days: 3,
      status: "pending",
      appliedDate: "2024-01-19",
      contact: "+8801812345678",
      description: "Doctor appointment and medical checkup",
      description_bangla: "ডাক্তারের সাথে দেখা এবং স্বাস্থ্য পরীক্ষা",
    },
    {
      id: 3,
      applicantName: "Fatima Khatun",
      applicantName_bangla: "ফাতিমা খাতুন",
      type: "student",
      class: "Class 9-B",
      roll: 23,
      reason: "Sick Leave",
      reason_bangla: "অসুস্থতার ছুটি",
      startDate: "2024-01-16",
      endDate: "2024-01-18",
      days: 3,
      status: "approved",
      appliedDate: "2024-01-15",
      guardianContact: "+8801912345678",
      description: "Fever and cold symptoms",
      description_bangla: "জ্বর এবং সর্দি-কাশির লক্ষণ",
      approvedBy: "Dr. Rashida Begum",
      approvedDate: "2024-01-16",
    },
  ])

  const handleApprove = (id: number) => {
    console.log("Approving leave application:", id)
    // Implementation for approving leave
  }

  const handleReject = (id: number) => {
    console.log("Rejecting leave application:", id)
    // Implementation for rejecting leave
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "approved":
        return "bg-green-500 text-white"
      case "rejected":
        return "bg-red-500 text-white"
      case "pending":
        return "bg-orange-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "approved":
        return <CheckCircle className="h-4 w-4" />
      case "rejected":
        return <XCircle className="h-4 w-4" />
      case "pending":
        return <Clock className="h-4 w-4" />
      default:
        return <Clock className="h-4 w-4" />
    }
  }

  const filteredApplications = leaveApplications.filter((app) => {
    const matchesStatus = filterStatus === "all" || app.status === filterStatus
    const matchesType = filterType === "all" || app.type === filterType
    const matchesSearch =
      app.applicantName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      app.reason.toLowerCase().includes(searchTerm.toLowerCase())

    return matchesStatus && matchesType && matchesSearch
  })

  const stats = {
    total: leaveApplications.length,
    pending: leaveApplications.filter((app) => app.status === "pending").length,
    approved: leaveApplications.filter((app) => app.status === "approved").length,
    rejected: leaveApplications.filter((app) => app.status === "rejected").length,
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-3xl font-bold text-blue-900">Leave Approval Center</h2>
          <h3 className="text-xl text-blue-700">ছুটি অনুমোদন কেন্দ্র</h3>
          <p className="text-gray-600">Approve or reject student and teacher leave applications</p>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card className="bg-gradient-to-r from-blue-600 to-blue-700 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm font-medium">Total Applications</p>
                <p className="text-3xl font-bold">{stats.total}</p>
              </div>
              <FileText className="h-8 w-8 text-blue-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-orange-500 to-orange-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-orange-100 text-sm font-medium">Pending</p>
                <p className="text-3xl font-bold">{stats.pending}</p>
              </div>
              <Clock className="h-8 w-8 text-orange-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-green-500 to-green-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm font-medium">Approved</p>
                <p className="text-3xl font-bold">{stats.approved}</p>
              </div>
              <CheckCircle className="h-8 w-8 text-green-200" />
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-r from-red-500 to-red-600 text-white">
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-100 text-sm font-medium">Rejected</p>
                <p className="text-3xl font-bold">{stats.rejected}</p>
              </div>
              <XCircle className="h-8 w-8 text-red-200" />
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="border-2 border-blue-200">
        <CardHeader className="bg-blue-50">
          <CardTitle className="text-blue-900">Filter Applications</CardTitle>
          <CardDescription>আবেদন ফিল্টার করুন</CardDescription>
        </CardHeader>
        <CardContent className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search by name or reason..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10 border-2 border-gray-300 focus:border-blue-500"
              />
            </div>

            <Select value={filterStatus} onValueChange={setFilterStatus}>
              <SelectTrigger className="border-2 border-gray-300 focus:border-blue-500">
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="approved">Approved</SelectItem>
                <SelectItem value="rejected">Rejected</SelectItem>
              </SelectContent>
            </Select>

            <Select value={filterType} onValueChange={setFilterType}>
              <SelectTrigger className="border-2 border-gray-300 focus:border-blue-500">
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="student">Students</SelectItem>
                <SelectItem value="teacher">Teachers</SelectItem>
              </SelectContent>
            </Select>

            <Button className="bg-blue-600 hover:bg-blue-700 text-white font-semibold">
              <Search className="h-4 w-4 mr-2" />
              Search
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Applications List */}
      <div className="space-y-4">
        {filteredApplications.map((application) => (
          <Card key={application.id} className="border-2 border-gray-200 hover:border-blue-300 transition-colors">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center space-x-4">
                  <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                    <User className="h-6 w-6 text-blue-600" />
                  </div>
                  <div>
                    <h3 className="text-xl font-bold text-gray-900">{application.applicantName}</h3>
                    <p className="text-gray-600">{application.applicantName_bangla}</p>
                    <div className="flex items-center space-x-4 mt-1">
                      <Badge variant="outline" className="bg-blue-50 text-blue-700 border-blue-300">
                        {application.type === "student" ? "Student" : "Teacher"}
                      </Badge>
                      {application.type === "student" ? (
                        <span className="text-sm text-gray-600">
                          {application.class} • Roll: {application.roll}
                        </span>
                      ) : (
                        <span className="text-sm text-gray-600">{application.department}</span>
                      )}
                    </div>
                  </div>
                </div>
                <Badge className={`${getStatusColor(application.status)} px-3 py-1 text-sm font-semibold`}>
                  {getStatusIcon(application.status)}
                  <span className="ml-1 capitalize">{application.status}</span>
                </Badge>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-4">
                <div className="space-y-3">
                  <div>
                    <p className="text-sm font-semibold text-gray-700">Reason:</p>
                    <p className="text-gray-900">{application.reason}</p>
                    <p className="text-sm text-gray-600">{application.reason_bangla}</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-700">Description:</p>
                    <p className="text-gray-900">{application.description}</p>
                    <p className="text-sm text-gray-600">{application.description_bangla}</p>
                  </div>
                </div>

                <div className="space-y-3">
                  <div className="flex items-center space-x-4">
                    <Calendar className="h-4 w-4 text-blue-600" />
                    <div>
                      <p className="text-sm font-semibold text-gray-700">Leave Period:</p>
                      <p className="text-gray-900">
                        {application.startDate} to {application.endDate}
                      </p>
                      <p className="text-sm text-blue-600 font-semibold">{application.days} days</p>
                    </div>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-700">Applied Date:</p>
                    <p className="text-gray-900">{application.appliedDate}</p>
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-gray-700">Contact:</p>
                    <p className="text-gray-900">
                      {application.type === "student" ? application.guardianContact : application.contact}
                    </p>
                  </div>
                </div>
              </div>

              {application.status === "approved" && (
                <div className="bg-green-50 border border-green-200 rounded-lg p-3 mb-4">
                  <p className="text-sm text-green-800">
                    <strong>Approved by:</strong> {application.approvedBy} on {application.approvedDate}
                  </p>
                </div>
              )}

              {application.status === "pending" && (
                <div className="flex space-x-3">
                  <Button
                    onClick={() => handleApprove(application.id)}
                    className="flex-1 bg-green-600 hover:bg-green-700 text-white font-semibold py-3"
                  >
                    <CheckCircle className="h-5 w-5 mr-2" />
                    Approve Leave
                  </Button>
                  <Button
                    onClick={() => handleReject(application.id)}
                    variant="destructive"
                    className="flex-1 bg-red-600 hover:bg-red-700 text-white font-semibold py-3"
                  >
                    <XCircle className="h-5 w-5 mr-2" />
                    Reject Leave
                  </Button>
                </div>
              )}

              {application.status !== "pending" && (
                <div className="flex space-x-3">
                  <Button
                    variant="outline"
                    className="flex-1 border-2 border-blue-300 text-blue-700 font-semibold bg-transparent"
                  >
                    View Details
                  </Button>
                  <Button
                    variant="outline"
                    className="flex-1 border-2 border-gray-300 text-gray-700 font-semibold bg-transparent"
                  >
                    Print Certificate
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  )
}
