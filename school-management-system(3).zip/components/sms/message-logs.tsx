"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Download, Filter, CheckCircle, XCircle, Clock, Send, AlertTriangle, Users } from "lucide-react"

export function MessageLogs() {
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("all")
  const [typeFilter, setTypeFilter] = useState("all")

  const [messageLogs] = useState([
    {
      id: 1,
      sender: "Dr. Rashida Begum",
      recipientType: "guardians",
      recipientCount: 25,
      messageType: "attendance_alert",
      subject: "Attendance Alert",
      message: "Your child was absent from Mathematics class today...",
      status: "sent",
      sentAt: "2024-01-15 10:30 AM",
      deliveredCount: 23,
      failedCount: 2,
      cost: 12.5,
      provider: "muthofun",
    },
    {
      id: 2,
      sender: "Dr. Rashida Begum",
      recipientType: "all_guardians",
      recipientCount: 850,
      messageType: "custom",
      subject: "Academic Year Welcome",
      message: "Welcome to new academic year 2024. Classes will start...",
      status: "sent",
      sentAt: "2024-01-01 09:00 AM",
      deliveredCount: 845,
      failedCount: 5,
      cost: 425.0,
      provider: "muthofun",
    },
    {
      id: 3,
      sender: "Dr. Rashida Begum",
      recipientType: "teachers",
      recipientCount: 85,
      messageType: "custom",
      subject: "Staff Meeting",
      message: "Staff meeting tomorrow at 10 AM in conference room...",
      status: "sent",
      sentAt: "2024-01-14 04:00 PM",
      deliveredCount: 85,
      failedCount: 0,
      cost: 42.5,
      provider: "muthofun",
    },
    {
      id: 4,
      sender: "Dr. Rashida Begum",
      recipientType: "class_9_a",
      recipientCount: 40,
      messageType: "result_published",
      subject: "Mid-term Results",
      message: "Mid-term examination results have been published...",
      status: "pending",
      sentAt: "2024-01-15 02:00 PM",
      deliveredCount: 0,
      failedCount: 0,
      cost: 20.0,
      provider: "muthofun",
    },
    {
      id: 5,
      sender: "Dr. Rashida Begum",
      recipientType: "guardians",
      recipientCount: 120,
      messageType: "fee_due",
      subject: "Fee Due Alert",
      message: "Monthly tuition fee is due on January 31st...",
      status: "failed",
      sentAt: "2024-01-13 11:00 AM",
      deliveredCount: 0,
      failedCount: 120,
      cost: 0.0,
      provider: "muthofun",
    },
  ])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "sent":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "failed":
        return <XCircle className="h-4 w-4 text-red-500" />
      case "pending":
        return <Clock className="h-4 w-4 text-orange-500" />
      default:
        return <Send className="h-4 w-4 text-blue-500" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "sent":
        return <Badge className="bg-green-100 text-green-800">Sent</Badge>
      case "failed":
        return <Badge variant="destructive">Failed</Badge>
      case "pending":
        return <Badge variant="secondary">Pending</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const getRecipientTypeLabel = (type: string) => {
    switch (type) {
      case "all_guardians":
        return "All Guardians"
      case "guardians":
        return "Selected Guardians"
      case "teachers":
        return "Teachers"
      case "students":
        return "Students"
      case "class_9_a":
        return "Class 9-A"
      default:
        return type
    }
  }

  const filteredLogs = messageLogs.filter((log) => {
    const matchesSearch =
      log.subject.toLowerCase().includes(searchTerm.toLowerCase()) ||
      log.message.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = statusFilter === "all" || log.status === statusFilter
    const matchesType = typeFilter === "all" || log.messageType === typeFilter

    return matchesSearch && matchesStatus && matchesType
  })

  const totalStats = {
    totalMessages: messageLogs.length,
    totalSent: messageLogs.filter((log) => log.status === "sent").length,
    totalFailed: messageLogs.filter((log) => log.status === "failed").length,
    totalCost: messageLogs.reduce((sum, log) => sum + log.cost, 0),
    totalRecipients: messageLogs.reduce((sum, log) => sum + log.recipientCount, 0),
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Message Logs</h2>
          <p className="text-gray-600">Track all sent messages and delivery status</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export CSV
          </Button>
          <Button variant="outline">
            <Download className="h-4 w-4 mr-2" />
            Export PDF
          </Button>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-4">
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Send className="h-4 w-4 text-blue-500" />
              <div>
                <p className="text-sm font-medium">Total Messages</p>
                <p className="text-2xl font-bold">{totalStats.totalMessages}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-4 w-4 text-green-500" />
              <div>
                <p className="text-sm font-medium">Successfully Sent</p>
                <p className="text-2xl font-bold">{totalStats.totalSent}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <XCircle className="h-4 w-4 text-red-500" />
              <div>
                <p className="text-sm font-medium">Failed</p>
                <p className="text-2xl font-bold">{totalStats.totalFailed}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <Users className="h-4 w-4 text-purple-500" />
              <div>
                <p className="text-sm font-medium">Total Recipients</p>
                <p className="text-2xl font-bold">{totalStats.totalRecipients}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-4">
            <div className="flex items-center space-x-2">
              <AlertTriangle className="h-4 w-4 text-orange-500" />
              <div>
                <p className="text-sm font-medium">Total Cost</p>
                <p className="text-2xl font-bold">৳{totalStats.totalCost.toFixed(2)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card>
        <CardHeader>
          <CardTitle>Filter Messages</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <div className="relative">
              <Search className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
              <Input
                placeholder="Search messages..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>

            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by status" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                <SelectItem value="sent">Sent</SelectItem>
                <SelectItem value="pending">Pending</SelectItem>
                <SelectItem value="failed">Failed</SelectItem>
              </SelectContent>
            </Select>

            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger>
                <SelectValue placeholder="Filter by type" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                <SelectItem value="custom">Custom</SelectItem>
                <SelectItem value="attendance_alert">Attendance Alert</SelectItem>
                <SelectItem value="fee_due">Fee Due</SelectItem>
                <SelectItem value="result_published">Result Published</SelectItem>
              </SelectContent>
            </Select>

            <Button variant="outline">
              <Filter className="h-4 w-4 mr-2" />
              Advanced Filter
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Message Logs Table */}
      <Card>
        <CardHeader>
          <CardTitle>Message History</CardTitle>
          <CardDescription>Detailed log of all sent messages</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {filteredLogs.map((log) => (
              <div key={log.id} className="border rounded-lg p-4 hover:bg-gray-50">
                <div className="flex items-start justify-between">
                  <div className="flex-1">
                    <div className="flex items-center space-x-2 mb-2">
                      {getStatusIcon(log.status)}
                      <h3 className="font-semibold">{log.subject}</h3>
                      {getStatusBadge(log.status)}
                    </div>

                    <p className="text-sm text-gray-600 mb-2">{log.message}</p>

                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                      <div>
                        <span className="font-medium">Recipients:</span>
                        <p>
                          {getRecipientTypeLabel(log.recipientType)} ({log.recipientCount})
                        </p>
                      </div>
                      <div>
                        <span className="font-medium">Delivery:</span>
                        <p>
                          {log.deliveredCount} sent, {log.failedCount} failed
                        </p>
                      </div>
                      <div>
                        <span className="font-medium">Cost:</span>
                        <p>৳{log.cost.toFixed(2)}</p>
                      </div>
                      <div>
                        <span className="font-medium">Sent:</span>
                        <p>{log.sentAt}</p>
                      </div>
                    </div>
                  </div>

                  <div className="flex space-x-2">
                    <Button variant="ghost" size="sm">
                      View Details
                    </Button>
                    {log.status === "failed" && (
                      <Button variant="outline" size="sm">
                        Retry
                      </Button>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
