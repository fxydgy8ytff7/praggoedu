"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Checkbox } from "@/components/ui/checkbox"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Send, Users, MessageSquare, Clock, Eye } from "lucide-react"

export function SMSPanel() {
  const [selectedRecipients, setSelectedRecipients] = useState<string[]>([])
  const [messageType, setMessageType] = useState("custom")
  const [message, setMessage] = useState("")
  const [scheduledDate, setScheduledDate] = useState("")
  const [scheduledTime, setScheduledTime] = useState("")

  const [recipientFilters, setRecipientFilters] = useState({
    type: "all",
    class: "6", // Updated default value
    section: "A", // Updated default value
    gender: "", // Updated default value
    attendanceStatus: "", // Updated default value
  })

  const [messageTemplates] = useState([
    {
      id: "attendance_alert",
      name: "Attendance Alert",
      template:
        "Your child {student_name} was absent from {subject} class today. Please contact the class teacher if this is an emergency.",
    },
    {
      id: "fee_due",
      name: "Fee Due Alert",
      template:
        "Dear Parent, your child's {fee_type} fee of ৳{amount} is due on {due_date}. Please pay at your earliest convenience.",
    },
    {
      id: "result_published",
      name: "Result Published",
      template:
        "Results for {exam_name} have been published. Your child {student_name} scored {marks} marks. Check the student portal for details.",
    },
    {
      id: "emergency",
      name: "Emergency Notice",
      template: "URGENT: {message}. Please contact the school immediately at {phone}.",
    },
    {
      id: "event_reminder",
      name: "Event Reminder",
      template: "Reminder: {event_name} is scheduled for {date} at {time}. Please ensure your child's participation.",
    },
  ])

  const [recipientStats] = useState({
    totalStudents: 1250,
    totalGuardians: 850,
    totalTeachers: 85,
    selectedCount: 0,
  })

  const handleRecipientTypeChange = (type: string) => {
    setRecipientFilters({ ...recipientFilters, type })
    // Reset selections when type changes
    setSelectedRecipients([])
  }

  const handleTemplateSelect = (templateId: string) => {
    const template = messageTemplates.find((t) => t.id === templateId)
    if (template) {
      setMessage(template.template)
      setMessageType(templateId)
    }
  }

  const handleSendMessage = () => {
    // Implementation for sending message
    console.log("Sending message:", {
      recipients: selectedRecipients,
      message,
      type: messageType,
      scheduled: scheduledDate && scheduledTime ? `${scheduledDate} ${scheduledTime}` : null,
    })
  }

  const getRecipientCount = () => {
    switch (recipientFilters.type) {
      case "students":
        return recipientStats.totalStudents
      case "guardians":
        return recipientStats.totalGuardians
      case "teachers":
        return recipientStats.totalTeachers
      case "class":
        return 40 // Estimated per class
      default:
        return recipientStats.totalStudents + recipientStats.totalGuardians + recipientStats.totalTeachers
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">SMS Management Panel</h2>
          <p className="text-gray-600">Send targeted messages to students, guardians, and teachers</p>
        </div>
        <div className="flex space-x-2">
          <Button variant="outline">
            <Eye className="h-4 w-4 mr-2" />
            Preview
          </Button>
          <Button variant="outline">
            <Clock className="h-4 w-4 mr-2" />
            Schedule
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Recipient Selection */}
        <div className="lg:col-span-1">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <Users className="h-5 w-5 mr-2" />
                Select Recipients
              </CardTitle>
              <CardDescription>Choose who will receive your message</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {/* Recipient Type */}
              <div className="space-y-2">
                <Label>Recipient Type</Label>
                <Select value={recipientFilters.type} onValueChange={handleRecipientTypeChange}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All (Students + Guardians + Teachers)</SelectItem>
                    <SelectItem value="students">Students Only</SelectItem>
                    <SelectItem value="guardians">Guardians Only</SelectItem>
                    <SelectItem value="teachers">Teachers Only</SelectItem>
                    <SelectItem value="class">Specific Class/Section</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Class/Section Filter */}
              {recipientFilters.type === "class" && (
                <div className="grid grid-cols-2 gap-2">
                  <div className="space-y-2">
                    <Label>Class</Label>
                    <Select
                      value={recipientFilters.class}
                      onValueChange={(value) => setRecipientFilters({ ...recipientFilters, class: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select Class" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="6">Class 6</SelectItem>
                        <SelectItem value="7">Class 7</SelectItem>
                        <SelectItem value="8">Class 8</SelectItem>
                        <SelectItem value="9">Class 9</SelectItem>
                        <SelectItem value="10">Class 10</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>Section</Label>
                    <Select
                      value={recipientFilters.section}
                      onValueChange={(value) => setRecipientFilters({ ...recipientFilters, section: value })}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select Section" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="A">Section A</SelectItem>
                        <SelectItem value="B">Section B</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              )}

              {/* Advanced Filters */}
              <div className="space-y-2">
                <Label>Advanced Filters</Label>
                <div className="space-y-2">
                  <Select
                    value={recipientFilters.gender}
                    onValueChange={(value) => setRecipientFilters({ ...recipientFilters, gender: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Filter by Gender" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Genders</SelectItem>
                      <SelectItem value="male">Male</SelectItem>
                      <SelectItem value="female">Female</SelectItem>
                    </SelectContent>
                  </Select>

                  <Select
                    value={recipientFilters.attendanceStatus}
                    onValueChange={(value) => setRecipientFilters({ ...recipientFilters, attendanceStatus: value })}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Filter by Attendance" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="">All Students</SelectItem>
                      <SelectItem value="present">Present Today</SelectItem>
                      <SelectItem value="absent">Absent Today</SelectItem>
                      <SelectItem value="low_attendance">Low Attendance (&lt;80%)</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>

              {/* Recipient Count */}
              <div className="p-3 bg-blue-50 rounded-lg">
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Selected Recipients:</span>
                  <Badge variant="outline">{getRecipientCount()}</Badge>
                </div>
                <p className="text-xs text-gray-600 mt-1">
                  Estimated SMS cost: ৳{(getRecipientCount() * 0.5).toFixed(2)}
                </p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Message Composition */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center">
                <MessageSquare className="h-5 w-5 mr-2" />
                Compose Message
              </CardTitle>
              <CardDescription>Create your message using templates or custom text</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="compose" className="space-y-4">
                <TabsList>
                  <TabsTrigger value="compose">Compose</TabsTrigger>
                  <TabsTrigger value="templates">Templates</TabsTrigger>
                  <TabsTrigger value="schedule">Schedule</TabsTrigger>
                </TabsList>

                <TabsContent value="compose" className="space-y-4">
                  <div className="space-y-2">
                    <Label>Message Type</Label>
                    <Select value={messageType} onValueChange={setMessageType}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="custom">Custom Message</SelectItem>
                        <SelectItem value="attendance_alert">Attendance Alert</SelectItem>
                        <SelectItem value="fee_due">Fee Due Alert</SelectItem>
                        <SelectItem value="result_published">Result Published</SelectItem>
                        <SelectItem value="emergency">Emergency Notice</SelectItem>
                        <SelectItem value="event_reminder">Event Reminder</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label>Message Content</Label>
                    <Textarea
                      placeholder="Type your message here..."
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      rows={6}
                      className="resize-none"
                    />
                    <div className="flex justify-between text-xs text-gray-500">
                      <span>{message.length}/160 characters</span>
                      <span>{Math.ceil(message.length / 160)} SMS(s)</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-2">
                    <Checkbox id="emergency" />
                    <Label htmlFor="emergency" className="text-sm">
                      Mark as Emergency (High Priority)
                    </Label>
                  </div>

                  <div className="flex space-x-2">
                    <Button onClick={handleSendMessage} className="flex-1">
                      <Send className="h-4 w-4 mr-2" />
                      Send Now
                    </Button>
                    <Button variant="outline">
                      <Eye className="h-4 w-4 mr-2" />
                      Preview
                    </Button>
                  </div>
                </TabsContent>

                <TabsContent value="templates" className="space-y-4">
                  <div className="space-y-3">
                    {messageTemplates.map((template) => (
                      <div
                        key={template.id}
                        className="p-3 border rounded-lg hover:bg-gray-50 cursor-pointer"
                        onClick={() => handleTemplateSelect(template.id)}
                      >
                        <div className="flex items-center justify-between">
                          <h4 className="font-medium">{template.name}</h4>
                          <Button variant="ghost" size="sm">
                            Use Template
                          </Button>
                        </div>
                        <p className="text-sm text-gray-600 mt-1">{template.template}</p>
                      </div>
                    ))}
                  </div>
                </TabsContent>

                <TabsContent value="schedule" className="space-y-4">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>Schedule Date</Label>
                      <Input type="date" value={scheduledDate} onChange={(e) => setScheduledDate(e.target.value)} />
                    </div>
                    <div className="space-y-2">
                      <Label>Schedule Time</Label>
                      <Input type="time" value={scheduledTime} onChange={(e) => setScheduledTime(e.target.value)} />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label>Repeat Options</Label>
                    <Select>
                      <SelectTrigger>
                        <SelectValue placeholder="Select repeat option" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="none">No Repeat</SelectItem>
                        <SelectItem value="daily">Daily</SelectItem>
                        <SelectItem value="weekly">Weekly</SelectItem>
                        <SelectItem value="monthly">Monthly</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <Button className="w-full">
                    <Clock className="h-4 w-4 mr-2" />
                    Schedule Message
                  </Button>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
