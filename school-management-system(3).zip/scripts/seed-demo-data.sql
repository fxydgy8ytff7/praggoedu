-- Seed Demo Data for Bangladesh School Management System
-- This will create comprehensive test data

-- Insert demo school
INSERT INTO schools (id, name, name_bangla, address, address_bangla, phone, email, school_type, medium, subscription_plan, status) VALUES
('550e8400-e29b-41d4-a716-446655440000', 'Dhaka Model High School', 'ঢাকা মডেল উচ্চ বিদ্যালয়', 'Dhanmondi, Dhaka-1205', 'ধানমন্ডি, ঢাকা-১২০৫', '+8801712345678', 'info@dhakamodel.edu.bd', 'secondary', 'both', 'premium', 'active');

-- Get the school ID for reference
DO $$
DECLARE
    school_uuid UUID := '550e8400-e29b-41d4-a716-446655440000';
    admin_role_id UUID;
    head_teacher_role_id UUID;
    teacher_role_id UUID;
    student_role_id UUID;
    guardian_role_id UUID;
BEGIN
    -- Get role IDs
    SELECT id INTO admin_role_id FROM roles WHERE name = 'admin';
    SELECT id INTO head_teacher_role_id FROM roles WHERE name = 'head_teacher';
    SELECT id INTO teacher_role_id FROM roles WHERE name = 'teacher';
    SELECT id INTO student_role_id FROM roles WHERE name = 'student';
    SELECT id INTO guardian_role_id FROM roles WHERE name = 'guardian';

    -- Insert demo users
    -- Admin user
    INSERT INTO users (id, school_id, role_id, username, email, password_hash, name, name_bangla, phone, status) VALUES
    ('550e8400-e29b-41d4-a716-446655440001', school_uuid, admin_role_id, 'admin', 'admin@dhakamodel.edu.bd', '$2b$10$example_hash_admin', 'School Administrator', 'স্কুল প্রশাসক', '+8801712345679', 'active');

    -- Head Teacher
    INSERT INTO users (id, school_id, role_id, username, email, password_hash, name, name_bangla, phone, status) VALUES
    ('550e8400-e29b-41d4-a716-446655440002', school_uuid, head_teacher_role_id, 'headteacher', 'head@dhakamodel.edu.bd', '$2b$10$example_hash_head', 'Dr. Rashida Begum', 'ডঃ রাশিদা বেগম', '+8801712345680', 'active');

    -- Insert 10 teachers with Bangla names
    INSERT INTO users (id, school_id, role_id, username, email, password_hash, name, name_bangla, phone, status) VALUES
    ('550e8400-e29b-41d4-a716-446655440010', school_uuid, teacher_role_id, 'teacher001', 'sarah.ahmed@dhakamodel.edu.bd', '$2b$10$example_hash_teacher', 'Ms. Sarah Ahmed', 'সারাহ আহমেদ', '+8801712345681', 'active'),
    ('550e8400-e29b-41d4-a716-446655440011', school_uuid, teacher_role_id, 'teacher002', 'karim.hassan@dhakamodel.edu.bd', '$2b$10$example_hash_teacher', 'Mr. Karim Hassan', 'করিম হাসান', '+8801712345682', 'active'),
    ('550e8400-e29b-41d4-a716-446655440012', school_uuid, teacher_role_id, 'teacher003', 'fatima.khan@dhakamodel.edu.bd', '$2b$10$example_hash_teacher', 'Dr. Fatima Khan', 'ডঃ ফাতিমা খান', '+8801712345683', 'active'),
    ('550e8400-e29b-41d4-a716-446655440013', school_uuid, teacher_role_id, 'teacher004', 'nasir.uddin@dhakamodel.edu.bd', '$2b$10$example_hash_teacher', 'Mr. Nasir Uddin', 'নাসির উদ্দিন', '+8801712345684', 'active'),
    ('550e8400-e29b-41d4-a716-446655440014', school_uuid, teacher_role_id, 'teacher005', 'ruma.begum@dhakamodel.edu.bd', '$2b$10$example_hash_teacher', 'Ms. Ruma Begum', 'রুমা বেগম', '+8801712345685', 'active'),
    ('550e8400-e29b-41d4-a716-446655440015', school_uuid, teacher_role_id, 'teacher006', 'abdul.rahman@dhakamodel.edu.bd', '$2b$10$example_hash_teacher', 'Mr. Abdul Rahman', 'আব্দুল রহমান', '+8801712345686', 'active'),
    ('550e8400-e29b-41d4-a716-446655440016', school_uuid, teacher_role_id, 'teacher007', 'shahida.khatun@dhakamodel.edu.bd', '$2b$10$example_hash_teacher', 'Ms. Shahida Khatun', 'শাহিদা খাতুন', '+8801712345687', 'active'),
    ('550e8400-e29b-41d4-a716-446655440017', school_uuid, teacher_role_id, 'teacher008', 'mizanur.rahman@dhakamodel.edu.bd', '$2b$10$example_hash_teacher', 'Mr. Mizanur Rahman', 'মিজানুর রহমান', '+8801712345688', 'active'),
    ('550e8400-e29b-41d4-a716-446655440018', school_uuid, teacher_role_id, 'teacher009', 'nasreen.akter@dhakamodel.edu.bd', '$2b$10$example_hash_teacher', 'Ms. Nasreen Akter', 'নাসরিন আক্তার', '+8801712345689', 'active'),
    ('550e8400-e29b-41d4-a716-446655440019', school_uuid, teacher_role_id, 'teacher010', 'john.smith@dhakamodel.edu.bd', '$2b$10$example_hash_teacher', 'Mr. John Smith', 'জন স্মিথ', '+8801712345690', 'active');

    -- Insert teacher details
    INSERT INTO teachers (user_id, teacher_id, qualification, qualification_bangla, department, department_bangla, designation, designation_bangla, joining_date, salary, experience_years) VALUES
    ('550e8400-e29b-41d4-a716-446655440010', 'T001', 'M.Sc in Mathematics', 'গণিতে স্নাতকোত্তর', 'Science', 'বিজ্ঞান', 'Senior Teacher', 'সিনিয়র শিক্ষক', '2020-01-15', 45000.00, 8),
    ('550e8400-e29b-41d4-a716-446655440011', 'T002', 'M.Sc in Physics', 'পদার্থবিজ্ঞানে স্নাতকোত্তর', 'Science', 'বিজ্ঞান', 'Assistant Teacher', 'সহকারী শিক্ষক', '2021-03-10', 40000.00, 5),
    ('550e8400-e29b-41d4-a716-446655440012', 'T003', 'Ph.D in Chemistry', 'রসায়নে পিএইচডি', 'Science', 'বিজ্ঞান', 'Head of Department', 'বিভাগীয় প্রধান', '2019-07-01', 55000.00, 12),
    ('550e8400-e29b-41d4-a716-446655440013', 'T004', 'M.A in English', 'ইংরেজিতে স্নাতকোত্তর', 'Arts', 'কলা', 'Senior Teacher', 'সিনিয়র শিক্ষক', '2020-08-20', 42000.00, 7),
    ('550e8400-e29b-41d4-a716-446655440014', 'T005', 'M.A in Bangla', 'বাংলায় স্নাতকোত্তর', 'Arts', 'কলা', 'Assistant Teacher', 'সহকারী শিক্ষক', '2022-01-05', 38000.00, 3),
    ('550e8400-e29b-41d4-a716-446655440015', 'T006', 'M.A in History', 'ইতিহাসে স্নাতকোত্তর', 'Arts', 'কলা', 'Senior Teacher', 'সিনিয়র শিক্ষক', '2018-09-15', 48000.00, 10),
    ('550e8400-e29b-41d4-a716-446655440016', 'T007', 'M.Sc in Biology', 'জীববিজ্ঞানে স্নাতকোত্তর', 'Science', 'বিজ্ঞান', 'Assistant Teacher', 'সহকারী শিক্ষক', '2021-11-12', 41000.00, 4),
    ('550e8400-e29b-41d4-a716-446655440017', 'T008', 'M.A in Geography', 'ভূগোলে স্নাতকোত্তর', 'Arts', 'কলা', 'Senior Teacher', 'সিনিয়র শিক্ষক', '2019-04-08', 44000.00, 9),
    ('550e8400-e29b-41d4-a716-446655440018', 'T009', 'M.A in Islamic Studies', 'ইসলামিক স্টাডিজে স্নাতকোত্তর', 'Arts', 'কলা', 'Assistant Teacher', 'সহকারী শিক্ষক', '2022-06-01', 39000.00, 2),
    ('550e8400-e29b-41d4-a716-446655440019', 'T010', 'M.A in English Literature', 'ইংরেজি সাহিত্যে স্নাতকোত্তর', 'Arts', 'কলা', 'Senior Teacher', 'সিনিয়র শিক্ষক', '2020-02-28', 46000.00, 6);

    -- Insert 5 classes
    INSERT INTO classes (id, school_id, name, name_bangla, level, capacity, room_number, class_teacher_id) VALUES
    ('550e8400-e29b-41d4-a716-446655440100', school_uuid, 'Class 6', 'ষষ্ঠ শ্রেণী', 6, 40, '101', '550e8400-e29b-41d4-a716-446655440010'),
    ('550e8400-e29b-41d4-a716-446655440101', school_uuid, 'Class 7', 'সপ্তম শ্রেণী', 7, 40, '201', '550e8400-e29b-41d4-a716-446655440011'),
    ('550e8400-e29b-41d4-a716-446655440102', school_uuid, 'Class 8', 'অষ্টম শ্রেণী', 8, 40, '301', '550e8400-e29b-41d4-a716-446655440012'),
    ('550e8400-e29b-41d4-a716-446655440103', school_uuid, 'Class 9', 'নবম শ্রেণী', 9, 40, '401', '550e8400-e29b-41d4-a716-446655440013'),
    ('550e8400-e29b-41d4-a716-446655440104', school_uuid, 'Class 10', 'দশম শ্রেণী', 10, 40, '501', '550e8400-e29b-41d4-a716-446655440014');

    -- Insert sections for each class
    INSERT INTO sections (id, class_id, name, capacity, room_number, section_teacher_id) VALUES
    -- Class 6 sections
    ('550e8400-e29b-41d4-a716-446655440200', '550e8400-e29b-41d4-a716-446655440100', 'A', 40, '101A', '550e8400-e29b-41d4-a716-446655440010'),
    ('550e8400-e29b-41d4-a716-446655440201', '550e8400-e29b-41d4-a716-446655440100', 'B', 40, '101B', '550e8400-e29b-41d4-a716-446655440015'),
    -- Class 7 sections
    ('550e8400-e29b-41d4-a716-446655440202', '550e8400-e29b-41d4-a716-446655440101', 'A', 40, '201A', '550e8400-e29b-41d4-a716-446655440011'),
    ('550e8400-e29b-41d4-a716-446655440203', '550e8400-e29b-41d4-a716-446655440101', 'B', 40, '201B', '550e8400-e29b-41d4-a716-446655440016'),
    -- Class 8 sections
    ('550e8400-e29b-41d4-a716-446655440204', '550e8400-e29b-41d4-a716-446655440102', 'A', 40, '301A', '550e8400-e29b-41d4-a716-446655440012'),
    ('550e8400-e29b-41d4-a716-446655440205', '550e8400-e29b-41d4-a716-446655440102', 'B', 40, '301B', '550e8400-e29b-41d4-a716-446655440017'),
    -- Class 9 sections
    ('550e8400-e29b-41d4-a716-446655440206', '550e8400-e29b-41d4-a716-446655440103', 'A', 40, '401A', '550e8400-e29b-41d4-a716-446655440013'),
    ('550e8400-e29b-41d4-a716-446655440207', '550e8400-e29b-41d4-a716-446655440103', 'B', 40, '401B', '550e8400-e29b-41d4-a716-446655440018'),
    -- Class 10 sections
    ('550e8400-e29b-41d4-a716-446655440208', '550e8400-e29b-41d4-a716-446655440104', 'A', 40, '501A', '550e8400-e29b-41d4-a716-446655440014'),
    ('550e8400-e29b-41d4-a716-446655440209', '550e8400-e29b-41d4-a716-446655440104', 'B', 40, '501B', '550e8400-e29b-41d4-a716-446655440019');

    -- Insert subjects with Bangla names
    INSERT INTO subjects (id, school_id, name, name_bangla, code, type) VALUES
    ('550e8400-e29b-41d4-a716-446655440300', school_uuid, 'Mathematics', 'গণিত', 'MATH', 'core'),
    ('550e8400-e29b-41d4-a716-446655440301', school_uuid, 'English', 'ইংরেজি', 'ENG', 'core'),
    ('550e8400-e29b-41d4-a716-446655440302', school_uuid, 'Bangla', 'বাংলা', 'BAN', 'core'),
    ('550e8400-e29b-41d4-a716-446655440303', school_uuid, 'Physics', 'পদার্থবিজ্ঞান', 'PHY', 'core'),
    ('550e8400-e29b-41d4-a716-446655440304', school_uuid, 'Chemistry', 'রসায়ন', 'CHEM', 'core'),
    ('550e8400-e29b-41d4-a716-446655440305', school_uuid, 'Biology', 'জীববিজ্ঞান', 'BIO', 'core'),
    ('550e8400-e29b-41d4-a716-446655440306', school_uuid, 'History', 'ইতিহাস', 'HIST', 'core'),
    ('550e8400-e29b-41d4-a716-446655440307', school_uuid, 'Geography', 'ভূগোল', 'GEO', 'core'),
    ('550e8400-e29b-41d4-a716-446655440308', school_uuid, 'Islamic Studies', 'ইসলাম শিক্ষা', 'IS', 'core'),
    ('550e8400-e29b-41d4-a716-446655440309', school_uuid, 'Physical Education', 'শারীরিক শিক্ষা', 'PE', 'elective');

    -- Insert class routines (sample for Class 6-A)
    INSERT INTO class_routines (class_id, section_id, subject_id, teacher_id, day_of_week, start_time, end_time, room_number) VALUES
    -- Sunday (day 0)
    ('550e8400-e29b-41d4-a716-446655440100', '550e8400-e29b-41d4-a716-446655440200', '550e8400-e29b-41d4-a716-446655440300', '550e8400-e29b-41d4-a716-446655440010', 0, '08:00', '08:45', '101A'),
    ('550e8400-e29b-41d4-a716-446655440100', '550e8400-e29b-41d4-a716-446655440200', '550e8400-e29b-41d4-a716-446655440301', '550e8400-e29b-41d4-a716-446655440013', 0, '08:45', '09:30', '101A'),
    ('550e8400-e29b-41d4-a716-446655440100', '550e8400-e29b-41d4-a716-446655440200', '550e8400-e29b-41d4-a716-446655440302', '550e8400-e29b-41d4-a716-446655440014', 0, '09:45', '10:30', '101A'),
    -- Monday (day 1)
    ('550e8400-e29b-41d4-a716-446655440100', '550e8400-e29b-41d4-a716-446655440200', '550e8400-e29b-41d4-a716-446655440303', '550e8400-e29b-41d4-a716-446655440011', 1, '08:00', '08:45', '101A'),
    ('550e8400-e29b-41d4-a716-446655440100', '550e8400-e29b-41d4-a716-446655440200', '550e8400-e29b-41d4-a716-446655440304', '550e8400-e29b-41d4-a716-446655440012', 1, '08:45', '09:30', '101A'),
    ('550e8400-e29b-41d4-a716-446655440100', '550e8400-e29b-41d4-a716-446655440200', '550e8400-e29b-41d4-a716-446655440305', '550e8400-e29b-41d4-a716-446655440016', 1, '09:45', '10:30', '101A');

END $$;

-- Insert 20 guardians with Bangla names
INSERT INTO users (id, school_id, role_id, username, email, password_hash, name, name_bangla, phone, status) 
SELECT 
    ('550e8400-e29b-41d4-a716-44665544' || LPAD((1000 + generate_series)::text, 4, '0'))::uuid,
    '550e8400-e29b-41d4-a716-446655440000'::uuid,
    (SELECT id FROM roles WHERE name = 'guardian'),
    'guardian' || LPAD(generate_series::text, 3, '0'),
    'guardian' || LPAD(generate_series::text, 3, '0') || '@email.com',
    '$2b$10$example_hash_guardian',
    CASE 
        WHEN generate_series % 2 = 1 THEN 'Mr. Guardian ' || generate_series
        ELSE 'Mrs. Guardian ' || generate_series
    END,
    CASE 
        WHEN generate_series % 2 = 1 THEN 'জনাব অভিভাবক ' || generate_series
        ELSE 'বেগম অভিভাবক ' || generate_series
    END,
    '+88017123456' || LPAD((90 + generate_series)::text, 2, '0'),
    'active'
FROM generate_series(1, 20);

-- Insert guardian details
INSERT INTO guardians (user_id, occupation, occupation_bangla, workplace, workplace_bangla, monthly_income, education_level, education_level_bangla)
SELECT 
    ('550e8400-e29b-41d4-a716-44665544' || LPAD((1000 + generate_series)::text, 4, '0'))::uuid,
    CASE generate_series % 5
        WHEN 0 THEN 'Business'
        WHEN 1 THEN 'Government Service'
        WHEN 2 THEN 'Private Job'
        WHEN 3 THEN 'Doctor'
        ELSE 'Engineer'
    END,
    CASE generate_series % 5
        WHEN 0 THEN 'ব্যবসা'
        WHEN 1 THEN 'সরকারি চাকরি'
        WHEN 2 THEN 'বেসরকারি চাকরি'
        WHEN 3 THEN 'ডাক্তার'
        ELSE 'প্রকৌশলী'
    END,
    'Workplace ' || generate_series,
    'কর্মক্ষেত্র ' || generate_series,
    (30000 + (generate_series * 5000))::decimal,
    'Bachelor Degree',
    'স্নাতক ডিগ্রি'
FROM generate_series(1, 20);

-- Insert 50 students with Bangla names
INSERT INTO users (id, school_id, role_id, username, email, password_hash, name, name_bangla, phone, status, date_of_birth, gender, blood_group)
SELECT 
    ('550e8400-e29b-41d4-a716-44665544' || LPAD((2000 + generate_series)::text, 4, '0'))::uuid,
    '550e8400-e29b-41d4-a716-446655440000'::uuid,
    (SELECT id FROM roles WHERE name = 'student'),
    '2024' || LPAD(generate_series::text, 3, '0'),
    'student' || LPAD(generate_series::text, 3, '0') || '@dhakamodel.edu.bd',
    '$2b$10$example_hash_student',
    CASE 
        WHEN generate_series % 2 = 1 THEN 'Ahmed Rahman ' || generate_series
        ELSE 'Fatima Khatun ' || generate_series
    END,
    CASE 
        WHEN generate_series % 2 = 1 THEN 'আহমেদ রহমান ' || generate_series
        ELSE 'ফাতিমা খাতুন ' || generate_series
    END,
    '+88017123457' || LPAD(generate_series::text, 2, '0'),
    'active',
    ('2008-01-01'::date + (generate_series || ' days')::interval)::date,
    CASE WHEN generate_series % 2 = 1 THEN 'Male' ELSE 'Female' END,
    CASE generate_series % 4
        WHEN 0 THEN 'A+'
        WHEN 1 THEN 'B+'
        WHEN 2 THEN 'O+'
        ELSE 'AB+'
    END
FROM generate_series(1, 50);

-- Insert student details with distributed class/section assignment
INSERT INTO students (user_id, student_id, class_id, section_id, roll_number, admission_date, admission_number, guardian_name, guardian_name_bangla, guardian_phone, guardian_relation, guardian_occupation, guardian_occupation_bangla)
SELECT 
    ('550e8400-e29b-41d4-a716-44665544' || LPAD((2000 + generate_series)::text, 4, '0'))::uuid,
    '2024' || LPAD(generate_series::text, 3, '0'),
    -- Distribute students across classes
    CASE 
        WHEN generate_series <= 10 THEN '550e8400-e29b-41d4-a716-446655440100'::uuid -- Class 6
        WHEN generate_series <= 20 THEN '550e8400-e29b-41d4-a716-446655440101'::uuid -- Class 7
        WHEN generate_series <= 30 THEN '550e8400-e29b-41d4-a716-446655440102'::uuid -- Class 8
        WHEN generate_series <= 40 THEN '550e8400-e29b-41d4-a716-446655440103'::uuid -- Class 9
        ELSE '550e8400-e29b-41d4-a716-446655440104'::uuid -- Class 10
    END,
    -- Distribute students across sections A and B
    CASE 
        WHEN generate_series <= 10 THEN 
            CASE WHEN generate_series % 2 = 1 THEN '550e8400-e29b-41d4-a716-446655440200'::uuid ELSE '550e8400-e29b-41d4-a716-446655440201'::uuid END
        WHEN generate_series <= 20 THEN 
            CASE WHEN generate_series % 2 = 1 THEN '550e8400-e29b-41d4-a716-446655440202'::uuid ELSE '550e8400-e29b-41d4-a716-446655440203'::uuid END
        WHEN generate_series <= 30 THEN 
            CASE WHEN generate_series % 2 = 1 THEN '550e8400-e29b-41d4-a716-446655440204'::uuid ELSE '550e8400-e29b-41d4-a716-446655440205'::uuid END
        WHEN generate_series <= 40 THEN 
            CASE WHEN generate_series % 2 = 1 THEN '550e8400-e29b-41d4-a716-446655440206'::uuid ELSE '550e8400-e29b-41d4-a716-446655440207'::uuid END
        ELSE 
            CASE WHEN generate_series % 2 = 1 THEN '550e8400-e29b-41d4-a716-446655440208'::uuid ELSE '550e8400-e29b-41d4-a716-446655440209'::uuid END
    END,
    ((generate_series - 1) % 10) + 1, -- Roll numbers 1-10 per section
    '2024-01-01'::date,
    'ADM2024' || LPAD(generate_series::text, 3, '0'),
    'Guardian ' || generate_series,
    'অভিভাবক ' || generate_series,
    '+88017123456' || LPAD((90 + ((generate_series - 1) / 2 + 1))::text, 2, '0'),
    CASE WHEN generate_series % 2 = 1 THEN 'Father' ELSE 'Mother' END,
    'Business',
    'ব্যবসা'
FROM generate_series(1, 50);

-- Link students with guardians (each student has 1-2 guardians)
INSERT INTO student_guardians (student_id, guardian_id, relationship, relationship_bangla, is_primary)
SELECT 
    ('550e8400-e29b-41d4-a716-44665544' || LPAD((2000 + s.generate_series)::text, 4, '0'))::uuid,
    ('550e8400-e29b-41d4-a716-44665544' || LPAD((1000 + ((s.generate_series - 1) / 2 + 1))::text, 4, '0'))::uuid,
    CASE WHEN s.generate_series % 2 = 1 THEN 'Father' ELSE 'Mother' END,
    CASE WHEN s.generate_series % 2 = 1 THEN 'পিতা' ELSE 'মাতা' END,
    CASE WHEN s.generate_series % 2 = 1 THEN true ELSE false END
FROM generate_series(1, 50) s;

-- Insert sample attendance data for the last 30 days
INSERT INTO attendance (student_id, class_id, section_id, teacher_id, subject_id, date, status, marked_by)
SELECT 
    s.id,
    s.class_id,
    s.section_id,
    (SELECT user_id FROM teachers ORDER BY RANDOM() LIMIT 1),
    (SELECT id FROM subjects ORDER BY RANDOM() LIMIT 1),
    CURRENT_DATE - (generate_series || ' days')::interval,
    CASE 
        WHEN RANDOM() < 0.9 THEN 'present'
        WHEN RANDOM() < 0.95 THEN 'late'
        ELSE 'absent'
    END,
    'manual'
FROM students s
CROSS JOIN generate_series(1, 30)
WHERE EXTRACT(DOW FROM CURRENT_DATE - (generate_series || ' days')::interval) NOT IN (0, 6); -- Exclude weekends

-- Insert sample teacher notes
INSERT INTO teacher_notes (teacher_id, class_id, section_id, subject_id, title, title_bangla, content, content_bangla, file_type, visibility)
SELECT 
    t.user_id,
    c.id,
    s.id,
    sub.id,
    'Chapter ' || (RANDOM() * 10 + 1)::integer || ' Notes',
    'অধ্যায় ' || (RANDOM() * 10 + 1)::integer || ' নোট',
    'Important notes for this chapter. Please study carefully.',
    'এই অধ্যায়ের গুরুত্বপূর্ণ নোট। দয়া করে মনোযোগ দিয়ে পড়ুন।',
    'text',
    'class'
FROM teachers t
CROSS JOIN classes c
CROSS JOIN sections s
CROSS JOIN subjects sub
WHERE s.class_id = c.id
AND RANDOM() < 0.3 -- 30% chance to create a note
LIMIT 20;

-- Insert sample homework
INSERT INTO homework (teacher_id, class_id, section_id, subject_id, title, title_bangla, description, description_bangla, due_date, total_marks)
SELECT 
    t.user_id,
    c.id,
    s.id,
    sub.id,
    'Assignment ' || (RANDOM() * 5 + 1)::integer,
    'অ্যাসাইনমেন্ট ' || (RANDOM() * 5 + 1)::integer,
    'Complete the exercises from chapter ' || (RANDOM() * 10 + 1)::integer,
    'অধ্যায় ' || (RANDOM() * 10 + 1)::integer || ' থেকে অনুশীলনী সম্পূর্ণ করুন',
    CURRENT_DATE + (RANDOM() * 7 + 1)::integer,
    (RANDOM() * 20 + 10)::integer
FROM teachers t
CROSS JOIN classes c
CROSS JOIN sections s
CROSS JOIN subjects sub
WHERE s.class_id = c.id
AND RANDOM() < 0.2 -- 20% chance to create homework
LIMIT 15;

-- Insert sample AI questions
INSERT INTO ai_questions (teacher_id, subject_id, class_id, chapter, chapter_bangla, question_type, question, question_bangla, options, correct_answer, correct_answer_bangla, difficulty_level, marks, ai_generated)
VALUES 
-- Mathematics questions
((SELECT user_id FROM teachers WHERE teacher_id = 'T001'), 
 (SELECT id FROM subjects WHERE code = 'MATH'), 
 (SELECT id FROM classes WHERE level = 6),
 'Algebra', 'বীজগণিত', 'mcq',
 'What is the value of x in the equation 2x + 5 = 15?',
 '2x + 5 = 15 সমীকরণে x এর মান কত?',
 '{"A": "5", "B": "10", "C": "15", "D": "20"}',
 'A', 'ক', 'medium', 2, true),

-- English questions
((SELECT user_id FROM teachers WHERE teacher_id = 'T004'), 
 (SELECT id FROM subjects WHERE code = 'ENG'), 
 (SELECT id FROM classes WHERE level = 7),
 'Grammar', 'ব্যাকরণ', 'mcq',
 'Which is the correct past tense of "go"?',
 '"go" এর সঠিক অতীত কাল কোনটি?',
 '{"A": "goed", "B": "went", "C": "gone", "D": "going"}',
 'B', 'খ', 'easy', 1, true),

-- Bangla questions
((SELECT user_id FROM teachers WHERE teacher_id = 'T005'), 
 (SELECT id FROM subjects WHERE code = 'BAN'), 
 (SELECT id FROM classes WHERE level = 8),
 'Poetry', 'কবিতা', 'short',
 'Who wrote the poem "Bidrohi"?',
 '"বিদ্রোহী" কবিতাটি কে লিখেছেন?',
 NULL,
 'Kazi Nazrul Islam', 'কাজী নজরুল ইসলাম', 'easy', 2, false),

-- Physics questions
((SELECT user_id FROM teachers WHERE teacher_id = 'T002'), 
 (SELECT id FROM subjects WHERE code = 'PHY'), 
 (SELECT id FROM classes WHERE level = 9),
 'Motion', 'গতি', 'mcq',
 'What is the SI unit of velocity?',
 'বেগের SI একক কী?',
 '{"A": "m/s", "B": "m/s²", "C": "kg", "D": "N"}',
 'A', 'ক', 'medium', 2, true);

-- Insert sample cultural events
INSERT INTO cultural_events (school_id, name, name_bangla, event_type, event_date, start_time, end_time, description, description_bangla, location, location_bangla, organizer_id, target_audience, is_holiday)
VALUES 
('550e8400-e29b-41d4-a716-446655440000', 'Eid-ul-Fitr Celebration', 'ঈদুল ফিতর উদযাপন', 'religious', '2024-04-10', '09:00', '12:00', 'Eid celebration with cultural programs', 'সাংস্কৃতিক অনুষ্ঠানসহ ঈদ উদযাপন', 'School Auditorium', 'স্কুল অডিটোরিয়াম', '550e8400-e29b-41d4-a716-446655440002', 'all', true),

('550e8400-e29b-41d4-a716-446655440000', 'Victory Day Program', 'বিজয় দিবস অনুষ্ঠান', 'cultural', '2024-12-16', '10:00', '13:00', 'Victory Day celebration with patriotic songs and speeches', 'দেশাত্মবোধক গান ও বক্তৃতাসহ বিজয় দিবস উদযাপন', 'School Ground', 'স্কুল মাঠ', '550e8400-e29b-41d4-a716-446655440002', 'all', true),

('550e8400-e29b-41d4-a716-446655440000', 'Annual Sports Day', 'বার্ষিক ক্রীড়া দিবস', 'sports', '2024-02-21', '08:00', '16:00', 'Annual sports competition for all students', 'সকল শিক্ষার্থীদের জন্য বার্ষিক ক্রীড়া প্রতিযোগিতা', 'School Ground', 'স্কুল মাঠ', '550e8400-e29b-41d4-a716-446655440002', 'students', false);

-- Insert sample Qurbani management
INSERT INTO qurbani_management (school_id, year, animal_type, animal_count, cost_per_share, total_shares, available_shares, registration_start_date, registration_end_date, qurbani_date, location, location_bangla, organizer_id, status)
VALUES 
('550e8400-e29b-41d4-a716-446655440000', 2024, 'cow', 5, 8000.00, 35, 20, '2024-05-01', '2024-06-10', '2024-06-17', 'School Ground', 'স্কুল মাঠ', '550e8400-e29b-41d4-a716-446655440002', 'registration_open');

-- Insert sample Qurbani registrations
INSERT INTO qurbani_registrations (qurbani_id, participant_id, participant_type, shares_requested, total_amount, payment_status, paid_amount, status)
SELECT 
    (SELECT id FROM qurbani_management WHERE year = 2024),
    ('550e8400-e29b-41d4-a716-44665544' || LPAD((1000 + generate_series)::text, 4, '0'))::uuid,
    'guardian',
    1,
    8000.00,
    CASE WHEN RANDOM() < 0.7 THEN 'completed' ELSE 'pending' END,
    CASE WHEN RANDOM() < 0.7 THEN 8000.00 ELSE 0.00 END,
    'approved'
FROM generate_series(1, 15);

-- Insert sample fees
INSERT INTO fees (school_id, name, name_bangla, amount, type, class_id, due_date, academic_year) 
SELECT 
    '550e8400-e29b-41d4-a716-446655440000'::uuid,
    'Monthly Tuition Fee',
    'মাসিক বেতন',
    CASE 
        WHEN c.level <= 7 THEN 3000.00
        WHEN c.level <= 9 THEN 3500.00
        ELSE 4000.00
    END,
    'monthly',
    c.id,
    '2024-01-31'::date,
    '2024'
FROM classes c;

-- Insert sample transactions (some students have paid fees)
INSERT INTO transactions (student_id, fee_id, amount, total_amount, payment_date, payment_method, status, receipt_number, collected_by)
SELECT 
    s.id,
    f.id,
    f.amount,
    f.amount,
    CURRENT_DATE - (RANDOM() * 30)::integer,
    CASE (RANDOM() * 5)::integer
        WHEN 0 THEN 'cash'
        WHEN 1 THEN 'bank'
        WHEN 2 THEN 'bkash'
        WHEN 3 THEN 'nagad'
        ELSE 'rocket'
    END,
    'completed',
    'RCP' || LPAD((RANDOM() * 99999)::integer::text, 5, '0'),
    '550e8400-e29b-41d4-a716-446655440001'
FROM students s
JOIN fees f ON s.class_id = f.class_id
WHERE RANDOM() < 0.7; -- 70% of students have paid

-- Insert sample leave applications
INSERT INTO leave_applications (applicant_id, applicant_type, leave_type, leave_type_bangla, start_date, end_date, total_days, reason, reason_bangla, status)
SELECT 
    ('550e8400-e29b-41d4-a716-44665544' || LPAD((2000 + generate_series)::text, 4, '0'))::uuid,
    'student',
    CASE (RANDOM() * 4)::integer
        WHEN 0 THEN 'sick'
        WHEN 1 THEN 'family'
        WHEN 2 THEN 'emergency'
        ELSE 'religious'
    END,
    CASE (RANDOM() * 4)::integer
        WHEN 0 THEN 'অসুস্থতা'
        WHEN 1 THEN 'পারিবারিক'
        WHEN 2 THEN 'জরুরি'
        ELSE 'ধর্মীয়'
    END,
    CURRENT_DATE + (RANDOM() * 10)::integer,
    CURRENT_DATE + (RANDOM() * 10 + 1)::integer,
    (RANDOM() * 3 + 1)::integer,
    'Need leave for personal reasons',
    'ব্যক্তিগত কারণে ছুটি প্রয়োজন',
    CASE (RANDOM() * 3)::integer
        WHEN 0 THEN 'pending'
        WHEN 1 THEN 'approved'
        ELSE 'rejected'
    END
FROM generate_series(1, 10);

-- Insert sample message logs
INSERT INTO message_logs (sender_id, recipient_type, recipient_ids, message_type, template_type, message, message_bangla, total_recipients, sent_count, delivery_status, provider, cost)
VALUES 
('550e8400-e29b-41d4-a716-446655440002', 'guardian', '["all"]', 'sms', 'custom', 'Welcome to new academic year 2024. Classes will start from January 1st.', 'নতুন শিক্ষাবর্ষ ২০২৪ এ স্বাগতম। ক্লাস ১ জানুয়ারি থেকে শুরু হবে।', 20, 20, 'sent', 'muthofun', 10.00),

('550e8400-e29b-41d4-a716-446655440002', 'student', '["class_6_a"]', 'sms', 'attendance_alert', 'Your attendance is below 80%. Please attend classes regularly.', 'আপনার উপস্থিতি ৮০% এর নিচে। নিয়মিত ক্লাসে উপস্থিত থাকুন।', 5, 5, 'sent', 'muthofun', 2.50),

('550e8400-e29b-41d4-a716-446655440002', 'teacher', '["all"]', 'sms', 'custom', 'Staff meeting tomorrow at 10 AM in conference room.', 'আগামীকাল সকাল ১০টায় কনফারেন্স রুমে স্টাফ মিটিং।', 10, 10, 'sent', 'muthofun', 5.00);

-- Insert sample AI study sessions
INSERT INTO ai_study_sessions (student_id, subject_id, session_type, question, question_bangla, ai_response, ai_response_bangla, language_used)
SELECT 
    ('550e8400-e29b-41d4-a716-44665544' || LPAD((2000 + generate_series)::text, 4, '0'))::uuid,
    (SELECT id FROM subjects ORDER BY RANDOM() LIMIT 1),
    CASE (RANDOM() * 4)::integer
        WHEN 0 THEN 'homework_help'
        WHEN 1 THEN 'explanation'
        WHEN 2 THEN 'quiz'
        ELSE 'practice'
    END,
    'How to solve quadratic equations?',
    'দ্বিঘাত সমীকরণ কিভাবে সমাধান করব?',
    'To solve quadratic equations, you can use the quadratic formula: x = (-b ± √(b²-4ac)) / 2a',
    'দ্বিঘাত সমীকরণ সমাধানের জন্য দ্বিঘাত সূত্র ব্যবহার করুন: x = (-b ± √(b²-4ac)) / 2a',
    CASE WHEN RANDOM() < 0.6 THEN 'bangla' ELSE 'english' END
FROM generate_series(1, 25);

-- Insert sample notifications
INSERT INTO notifications (user_id, title, title_bangla, message, message_bangla, type, priority)
SELECT 
    ('550e8400-e29b-41d4-a716-44665544' || LPAD((2000 + generate_series)::text, 4, '0'))::uuid,
    'New Assignment Posted',
    'নতুন অ্যাসাইনমেন্ট দেওয়া হয়েছে',
    'A new assignment has been posted for Mathematics. Due date: Tomorrow',
    'গণিতের জন্য নতুন অ্যাসাইনমেন্ট দেওয়া হয়েছে। জমা দেওয়ার তারিখ: আগামীকাল',
    'homework',
    'normal'
FROM generate_series(1, 30);

-- Update settings with school-specific values
UPDATE settings SET school_id = '550e8400-e29b-41d4-a716-446655440000' WHERE school_id IS NULL;

COMMIT;
