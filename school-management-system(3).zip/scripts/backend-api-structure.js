// Backend API Structure for School Management System
// Node.js + Express.js + MongoDB/PostgreSQL

const express = require("express")
const cors = require("cors")
const helmet = require("helmet")
const rateLimit = require("express-rate-limit")
const jwt = require("jsonwebtoken")
const bcrypt = require("bcryptjs")
const { body, validationResult } = require("express-validator")

// Database connection (example with PostgreSQL)
const { Pool } = require("pg")
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false,
})

const app = express()

// Middleware
app.use(helmet())
app.use(cors())
app.use(express.json({ limit: "10mb" }))
app.use(express.urlencoded({ extended: true }))

// Rate limiting
const limiter = rateLimit({
  windowMs: 15 * 60 * 1000, // 15 minutes
  max: 100, // limit each IP to 100 requests per windowMs
})
app.use("/api/", limiter)

// Authentication middleware
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers["authorization"]
  const token = authHeader && authHeader.split(" ")[1]

  if (!token) {
    return res.status(401).json({ error: "Access token required" })
  }

  jwt.verify(token, process.env.JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: "Invalid token" })
    }
    req.user = user
    next()
  })
}

// Role-based authorization middleware
const authorize = (roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ error: "Insufficient permissions" })
    }
    next()
  }
}

// API Routes Structure

// 1. Authentication Routes
app.post(
  "/api/auth/login",
  [body("email").isEmail().normalizeEmail(), body("password").isLength({ min: 6 })],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { email, password, userType } = req.body

      // Determine table based on user type
      let table
      switch (userType) {
        case "super-admin":
          table = "super_admins"
          break
        case "admin":
          table = "school_admins"
          break
        case "teacher":
          table = "teachers"
          break
        case "student":
          table = "students"
          break
        case "parent":
          table = "parents"
          break
        default:
          return res.status(400).json({ error: "Invalid user type" })
      }

      const result = await pool.query(`SELECT * FROM ${table} WHERE email = $1`, [email])
      const user = result.rows[0]

      if (!user || !(await bcrypt.compare(password, user.password_hash))) {
        return res.status(401).json({ error: "Invalid credentials" })
      }

      const token = jwt.sign(
        { id: user.id, email: user.email, role: userType, schoolId: user.school_id },
        process.env.JWT_SECRET,
        { expiresIn: "24h" },
      )

      res.json({
        token,
        user: {
          id: user.id,
          name: user.name,
          email: user.email,
          role: userType,
          schoolId: user.school_id,
        },
      })
    } catch (error) {
      console.error("Login error:", error)
      res.status(500).json({ error: "Internal server error" })
    }
  },
)

// 2. Super Admin Routes
app.get("/api/super-admin/schools", authenticateToken, authorize(["super-admin"]), async (req, res) => {
  try {
    const result = await pool.query(`
      SELECT s.*, 
             COUNT(DISTINCT st.id) as student_count,
             COUNT(DISTINCT t.id) as teacher_count
      FROM schools s
      LEFT JOIN students st ON s.id = st.school_id
      LEFT JOIN teachers t ON s.id = t.school_id
      GROUP BY s.id
      ORDER BY s.created_at DESC
    `)

    res.json(result.rows)
  } catch (error) {
    console.error("Error fetching schools:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.post(
  "/api/super-admin/schools",
  authenticateToken,
  authorize(["super-admin"]),
  [body("name").notEmpty().trim(), body("email").isEmail().normalizeEmail(), body("phone").isMobilePhone()],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { name, address, phone, email, subscription_plan } = req.body

      const result = await pool.query(
        `
      INSERT INTO schools (name, address, phone, email, subscription_plan)
      VALUES ($1, $2, $3, $4, $5)
      RETURNING *
    `,
        [name, address, phone, email, subscription_plan],
      )

      res.status(201).json(result.rows[0])
    } catch (error) {
      console.error("Error creating school:", error)
      res.status(500).json({ error: "Internal server error" })
    }
  },
)

// 3. School Admin Routes
app.get("/api/admin/dashboard", authenticateToken, authorize(["admin"]), async (req, res) => {
  try {
    const schoolId = req.user.schoolId

    // Get dashboard statistics
    const stats = await Promise.all([
      pool.query("SELECT COUNT(*) as count FROM students WHERE school_id = $1", [schoolId]),
      pool.query("SELECT COUNT(*) as count FROM teachers WHERE school_id = $1", [schoolId]),
      pool.query("SELECT COUNT(*) as count FROM classes WHERE school_id = $1", [schoolId]),
      pool.query(
        `
        SELECT COALESCE(SUM(amount), 0) as total 
        FROM fee_payments fp 
        JOIN students s ON fp.student_id = s.id 
        WHERE s.school_id = $1 AND EXTRACT(MONTH FROM fp.payment_date) = EXTRACT(MONTH FROM CURRENT_DATE)
      `,
        [schoolId],
      ),
    ])

    res.json({
      totalStudents: Number.parseInt(stats[0].rows[0].count),
      totalTeachers: Number.parseInt(stats[1].rows[0].count),
      totalClasses: Number.parseInt(stats[2].rows[0].count),
      monthlyRevenue: Number.parseFloat(stats[3].rows[0].total),
    })
  } catch (error) {
    console.error("Error fetching admin dashboard:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// 4. Student Management Routes
app.get("/api/admin/students", authenticateToken, authorize(["admin"]), async (req, res) => {
  try {
    const schoolId = req.user.schoolId
    const { page = 1, limit = 10, search = "" } = req.query
    const offset = (page - 1) * limit

    let query = `
      SELECT s.*, c.name as class_name, c.section
      FROM students s
      LEFT JOIN classes c ON s.class_id = c.id
      WHERE s.school_id = $1
    `
    const params = [schoolId]

    if (search) {
      query += ` AND (s.name ILIKE $2 OR s.student_id ILIKE $2)`
      params.push(`%${search}%`)
    }

    query += ` ORDER BY s.created_at DESC LIMIT $${params.length + 1} OFFSET $${params.length + 2}`
    params.push(limit, offset)

    const result = await pool.query(query, params)

    // Get total count
    let countQuery = "SELECT COUNT(*) FROM students WHERE school_id = $1"
    const countParams = [schoolId]

    if (search) {
      countQuery += ` AND (name ILIKE $2 OR student_id ILIKE $2)`
      countParams.push(`%${search}%`)
    }

    const countResult = await pool.query(countQuery, countParams)

    res.json({
      students: result.rows,
      total: Number.parseInt(countResult.rows[0].count),
      page: Number.parseInt(page),
      totalPages: Math.ceil(countResult.rows[0].count / limit),
    })
  } catch (error) {
    console.error("Error fetching students:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

app.post(
  "/api/admin/students",
  authenticateToken,
  authorize(["admin"]),
  [
    body("name").notEmpty().trim(),
    body("email").optional().isEmail().normalizeEmail(),
    body("student_id").notEmpty().trim(),
    body("class_id").isUUID(),
  ],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const schoolId = req.user.schoolId
      const {
        name,
        email,
        student_id,
        class_id,
        phone,
        address,
        date_of_birth,
        gender,
        blood_group,
        roll_number,
        guardian_name,
        guardian_phone,
        guardian_email,
        guardian_relation,
      } = req.body

      // Generate password hash
      const password = student_id // Default password is student ID
      const password_hash = await bcrypt.hash(password, 10)

      const result = await pool.query(
        `
      INSERT INTO students (
        school_id, name, email, student_id, class_id, phone, address,
        date_of_birth, gender, blood_group, roll_number, guardian_name,
        guardian_phone, guardian_email, guardian_relation, password_hash
      ) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16)
      RETURNING *
    `,
        [
          schoolId,
          name,
          email,
          student_id,
          class_id,
          phone,
          address,
          date_of_birth,
          gender,
          blood_group,
          roll_number,
          guardian_name,
          guardian_phone,
          guardian_email,
          guardian_relation,
          password_hash,
        ],
      )

      res.status(201).json(result.rows[0])
    } catch (error) {
      console.error("Error creating student:", error)
      if (error.code === "23505") {
        // Unique violation
        res.status(400).json({ error: "Student ID already exists" })
      } else {
        res.status(500).json({ error: "Internal server error" })
      }
    }
  },
)

// 5. Attendance Routes
app.post(
  "/api/teacher/attendance",
  authenticateToken,
  authorize(["teacher"]),
  [body("class_id").isUUID(), body("date").isISO8601(), body("attendance").isArray()],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const teacherId = req.user.id
      const { class_id, date, attendance } = req.body

      // Begin transaction
      const client = await pool.connect()
      try {
        await client.query("BEGIN")

        // Delete existing attendance for this class and date
        await client.query("DELETE FROM attendance WHERE class_id = $1 AND date = $2", [class_id, date])

        // Insert new attendance records
        for (const record of attendance) {
          await client.query(
            `
          INSERT INTO attendance (student_id, class_id, teacher_id, date, status, marked_by)
          VALUES ($1, $2, $3, $4, $5, 'manual')
        `,
            [record.student_id, class_id, teacherId, date, record.status],
          )

          // Send SMS notification for absent students
          if (record.status === "absent") {
            // TODO: Implement SMS notification
            console.log(`SMS: Student ${record.student_id} was absent on ${date}`)
          }
        }

        await client.query("COMMIT")
        res.json({ message: "Attendance recorded successfully" })
      } catch (error) {
        await client.query("ROLLBACK")
        throw error
      } finally {
        client.release()
      }
    } catch (error) {
      console.error("Error recording attendance:", error)
      res.status(500).json({ error: "Internal server error" })
    }
  },
)

// 6. Fee Management Routes
app.get("/api/admin/fees/pending", authenticateToken, authorize(["admin"]), async (req, res) => {
  try {
    const schoolId = req.user.schoolId

    const result = await pool.query(
      `
      SELECT s.id, s.name, s.student_id, c.name as class_name,
             fs.name as fee_name, fs.amount, fs.due_date,
             COALESCE(SUM(fp.amount), 0) as paid_amount,
             (fs.amount - COALESCE(SUM(fp.amount), 0)) as due_amount
      FROM students s
      JOIN classes c ON s.class_id = c.id
      JOIN fee_structures fs ON c.id = fs.class_id
      LEFT JOIN fee_payments fp ON s.id = fp.student_id AND fs.id = fp.fee_structure_id
      WHERE s.school_id = $1
      GROUP BY s.id, s.name, s.student_id, c.name, fs.name, fs.amount, fs.due_date
      HAVING (fs.amount - COALESCE(SUM(fp.amount), 0)) > 0
      ORDER BY fs.due_date ASC
    `,
      [schoolId],
    )

    res.json(result.rows)
  } catch (error) {
    console.error("Error fetching pending fees:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// 7. Results Management Routes
app.post(
  "/api/teacher/results",
  authenticateToken,
  authorize(["teacher"]),
  [body("exam_id").isUUID(), body("results").isArray()],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const { exam_id, results } = req.body

      const client = await pool.connect()
      try {
        await client.query("BEGIN")

        for (const result of results) {
          await client.query(
            `
          INSERT INTO results (student_id, exam_id, marks_obtained, grade, remarks)
          VALUES ($1, $2, $3, $4, $5)
          ON CONFLICT (student_id, exam_id) 
          DO UPDATE SET marks_obtained = $3, grade = $4, remarks = $5, updated_at = CURRENT_TIMESTAMP
        `,
            [result.student_id, exam_id, result.marks_obtained, result.grade, result.remarks],
          )
        }

        await client.query("COMMIT")
        res.json({ message: "Results saved successfully" })
      } catch (error) {
        await client.query("ROLLBACK")
        throw error
      } finally {
        client.release()
      }
    } catch (error) {
      console.error("Error saving results:", error)
      res.status(500).json({ error: "Internal server error" })
    }
  },
)

// 8. Mobile App API Routes
app.post(
  "/api/mobile/attendance/nfc",
  authenticateToken,
  authorize(["teacher"]),
  [body("nfc_tag_id").notEmpty(), body("class_id").isUUID(), body("date").isISO8601()],
  async (req, res) => {
    try {
      const errors = validationResult(req)
      if (!errors.isEmpty()) {
        return res.status(400).json({ errors: errors.array() })
      }

      const teacherId = req.user.id
      const { nfc_tag_id, class_id, date } = req.body

      // Find student by NFC tag
      const studentResult = await pool.query("SELECT id, name FROM students WHERE nfc_tag_id = $1", [nfc_tag_id])

      if (studentResult.rows.length === 0) {
        return res.status(404).json({ error: "Student not found" })
      }

      const student = studentResult.rows[0]

      // Record attendance
      await pool.query(
        `
      INSERT INTO attendance (student_id, class_id, teacher_id, date, status, marked_by)
      VALUES ($1, $2, $3, $4, 'present', 'nfc')
      ON CONFLICT (student_id, class_id, date)
      DO UPDATE SET status = 'present', marked_by = 'nfc', marked_at = CURRENT_TIMESTAMP
    `,
        [student.id, class_id, teacherId, date],
      )

      res.json({
        message: "Attendance marked successfully",
        student: student,
      })
    } catch (error) {
      console.error("Error marking NFC attendance:", error)
      res.status(500).json({ error: "Internal server error" })
    }
  },
)

// 9. Notification Routes
app.get("/api/notifications", authenticateToken, async (req, res) => {
  try {
    const userId = req.user.id
    const userType = req.user.role

    const result = await pool.query(
      `
      SELECT * FROM notifications 
      WHERE user_id = $1 AND user_type = $2 
      ORDER BY created_at DESC 
      LIMIT 20
    `,
      [userId, userType],
    )

    res.json(result.rows)
  } catch (error) {
    console.error("Error fetching notifications:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// 10. File Upload Route
const multer = require("multer")
const path = require("path")

const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    cb(null, "uploads/")
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9)
    cb(null, file.fieldname + "-" + uniqueSuffix + path.extname(file.originalname))
  },
})

const upload = multer({
  storage: storage,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5MB limit
  fileFilter: (req, file, cb) => {
    const allowedTypes = /jpeg|jpg|png|pdf|doc|docx/
    const extname = allowedTypes.test(path.extname(file.originalname).toLowerCase())
    const mimetype = allowedTypes.test(file.mimetype)

    if (mimetype && extname) {
      return cb(null, true)
    } else {
      cb(new Error("Invalid file type"))
    }
  },
})

app.post("/api/upload", authenticateToken, upload.single("file"), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: "No file uploaded" })
    }

    res.json({
      message: "File uploaded successfully",
      filename: req.file.filename,
      path: req.file.path,
      size: req.file.size,
    })
  } catch (error) {
    console.error("Error uploading file:", error)
    res.status(500).json({ error: "Internal server error" })
  }
})

// Error handling middleware
app.use((error, req, res, next) => {
  console.error("Unhandled error:", error)
  res.status(500).json({ error: "Internal server error" })
})

// 404 handler
app.use("*", (req, res) => {
  res.status(404).json({ error: "Route not found" })
})

const PORT = process.env.PORT || 5000
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`)
})

module.exports = app
