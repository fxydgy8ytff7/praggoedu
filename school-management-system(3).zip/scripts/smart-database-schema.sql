-- Smart Database Schema for Bangladesh School Management System
-- PostgreSQL Database with AI, Cultural Events, and Communication Features

-- Create database
CREATE DATABASE bangladesh_school_management;

-- Use the database
\c bangladesh_school_management;

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Roles table
CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(50) UNIQUE NOT NULL,
    display_name VARCHAR(100) NOT NULL,
    permissions JSONB DEFAULT '[]',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert default roles
INSERT INTO roles (name, display_name, permissions) VALUES
('super_admin', 'Super Administrator', '["all"]'),
('admin', 'School Administrator', '["manage_school", "manage_users", "view_reports"]'),
('head_teacher', 'Head Teacher', '["manage_teachers", "manage_students", "send_sms", "approve_leaves", "view_analytics"]'),
('teacher', 'Teacher', '["manage_classes", "take_attendance", "upload_notes", "assign_homework"]'),
('student', 'Student', '["view_profile", "view_attendance", "submit_homework", "use_ai_helper"]'),
('guardian', 'Guardian/Parent', '["view_child_info", "receive_notifications", "communicate_teachers"]');

-- Schools table
CREATE TABLE schools (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(200) NOT NULL,
    name_bangla VARCHAR(200),
    address TEXT,
    address_bangla TEXT,
    phone VARCHAR(20),
    email VARCHAR(100),
    website VARCHAR(100),
    logo_url VARCHAR(255),
    established_year INTEGER,
    school_type VARCHAR(50) DEFAULT 'secondary', -- primary, secondary, higher_secondary
    medium VARCHAR(50) DEFAULT 'bangla', -- bangla, english, both
    subscription_plan VARCHAR(50) DEFAULT 'basic',
    status VARCHAR(20) DEFAULT 'active',
    academic_year VARCHAR(10) DEFAULT '2024',
    timezone VARCHAR(50) DEFAULT 'Asia/Dhaka',
    currency VARCHAR(10) DEFAULT 'BDT',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Users table (unified for all user types)
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES schools(id) ON DELETE CASCADE,
    role_id UUID REFERENCES roles(id) ON DELETE RESTRICT,
    username VARCHAR(100) UNIQUE NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password_hash VARCHAR(255) NOT NULL,
    name VARCHAR(100) NOT NULL,
    name_bangla VARCHAR(100),
    phone VARCHAR(20),
    address TEXT,
    address_bangla TEXT,
    profile_picture VARCHAR(255),
    date_of_birth DATE,
    gender VARCHAR(10),
    blood_group VARCHAR(5),
    nid_number VARCHAR(20),
    status VARCHAR(20) DEFAULT 'active',
    last_login TIMESTAMP,
    email_verified BOOLEAN DEFAULT false,
    phone_verified BOOLEAN DEFAULT false,
    two_factor_enabled BOOLEAN DEFAULT false,
    preferences JSONB DEFAULT '{}',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Classes table
CREATE TABLE classes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES schools(id) ON DELETE CASCADE,
    name VARCHAR(50) NOT NULL,
    name_bangla VARCHAR(50),
    level INTEGER NOT NULL, -- 1-12
    capacity INTEGER DEFAULT 40,
    room_number VARCHAR(20),
    class_teacher_id UUID REFERENCES users(id) ON DELETE SET NULL,
    academic_year VARCHAR(10) DEFAULT '2024',
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Sections table
CREATE TABLE sections (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    class_id UUID REFERENCES classes(id) ON DELETE CASCADE,
    name VARCHAR(10) NOT NULL, -- A, B, C, etc.
    capacity INTEGER DEFAULT 40,
    room_number VARCHAR(20),
    section_teacher_id UUID REFERENCES users(id) ON DELETE SET NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Subjects table
CREATE TABLE subjects (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES schools(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    name_bangla VARCHAR(100),
    code VARCHAR(20),
    type VARCHAR(50) DEFAULT 'core', -- core, elective, extra_curricular
    description TEXT,
    description_bangla TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Teachers table
CREATE TABLE teachers (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    teacher_id VARCHAR(50) UNIQUE NOT NULL,
    qualification VARCHAR(200),
    qualification_bangla VARCHAR(200),
    department VARCHAR(100),
    department_bangla VARCHAR(100),
    designation VARCHAR(100),
    designation_bangla VARCHAR(100),
    joining_date DATE,
    salary DECIMAL(10,2),
    experience_years INTEGER DEFAULT 0,
    specialization TEXT,
    specialization_bangla TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Students table
CREATE TABLE students (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    student_id VARCHAR(50) UNIQUE NOT NULL,
    class_id UUID REFERENCES classes(id) ON DELETE SET NULL,
    section_id UUID REFERENCES sections(id) ON DELETE SET NULL,
    roll_number INTEGER,
    admission_date DATE,
    admission_number VARCHAR(50),
    birth_certificate VARCHAR(255),
    guardian_name VARCHAR(100),
    guardian_name_bangla VARCHAR(100),
    guardian_phone VARCHAR(20),
    guardian_email VARCHAR(100),
    guardian_relation VARCHAR(50),
    guardian_occupation VARCHAR(100),
    guardian_occupation_bangla VARCHAR(100),
    emergency_contact VARCHAR(20),
    medical_conditions TEXT,
    medical_conditions_bangla TEXT,
    transport_mode VARCHAR(50), -- bus, rickshaw, walking, private
    nfc_tag_id VARCHAR(100),
    qr_code VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Guardians table
CREATE TABLE guardians (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    occupation VARCHAR(100),
    occupation_bangla VARCHAR(100),
    workplace VARCHAR(200),
    workplace_bangla VARCHAR(200),
    monthly_income DECIMAL(10,2),
    education_level VARCHAR(100),
    education_level_bangla VARCHAR(100),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Student-Guardian relationship table
CREATE TABLE student_guardians (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID REFERENCES students(id) ON DELETE CASCADE,
    guardian_id UUID REFERENCES guardians(id) ON DELETE CASCADE,
    relationship VARCHAR(50) NOT NULL, -- father, mother, uncle, aunt, etc.
    relationship_bangla VARCHAR(50),
    is_primary BOOLEAN DEFAULT false,
    can_receive_sms BOOLEAN DEFAULT true,
    can_pickup_student BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Teacher-Class-Subject assignments
CREATE TABLE teacher_assignments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    teacher_id UUID REFERENCES teachers(id) ON DELETE CASCADE,
    class_id UUID REFERENCES classes(id) ON DELETE CASCADE,
    section_id UUID REFERENCES sections(id) ON DELETE CASCADE,
    subject_id UUID REFERENCES subjects(id) ON DELETE CASCADE,
    is_class_teacher BOOLEAN DEFAULT false,
    academic_year VARCHAR(10) DEFAULT '2024',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Class Routines table
CREATE TABLE class_routines (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    class_id UUID REFERENCES classes(id) ON DELETE CASCADE,
    section_id UUID REFERENCES sections(id) ON DELETE CASCADE,
    subject_id UUID REFERENCES subjects(id) ON DELETE CASCADE,
    teacher_id UUID REFERENCES teachers(id) ON DELETE CASCADE,
    day_of_week INTEGER NOT NULL, -- 0=Sunday, 1=Monday, etc.
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    room_number VARCHAR(20),
    academic_year VARCHAR(10) DEFAULT '2024',
    is_active BOOLEAN DEFAULT true,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Attendance table
CREATE TABLE attendance (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID REFERENCES students(id) ON DELETE CASCADE,
    class_id UUID REFERENCES classes(id) ON DELETE CASCADE,
    section_id UUID REFERENCES sections(id) ON DELETE CASCADE,
    teacher_id UUID REFERENCES teachers(id) ON DELETE CASCADE,
    subject_id UUID REFERENCES subjects(id) ON DELETE SET NULL,
    date DATE NOT NULL,
    status VARCHAR(20) NOT NULL, -- present, absent, late, excused
    marked_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    marked_by VARCHAR(50), -- manual, nfc, qr, fingerprint, ai_camera
    notes TEXT,
    notes_bangla TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Teacher Notes table
CREATE TABLE teacher_notes (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    teacher_id UUID REFERENCES teachers(id) ON DELETE CASCADE,
    class_id UUID REFERENCES classes(id) ON DELETE CASCADE,
    section_id UUID REFERENCES sections(id) ON DELETE CASCADE,
    subject_id UUID REFERENCES subjects(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    title_bangla VARCHAR(200),
    content TEXT,
    content_bangla TEXT,
    file_url VARCHAR(255),
    file_type VARCHAR(50), -- pdf, image, audio, video
    visibility VARCHAR(50) DEFAULT 'class', -- class, section, individual
    target_students JSONB DEFAULT '[]', -- for individual targeting
    is_important BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Homework/Assignments table
CREATE TABLE homework (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    teacher_id UUID REFERENCES teachers(id) ON DELETE CASCADE,
    class_id UUID REFERENCES classes(id) ON DELETE CASCADE,
    section_id UUID REFERENCES sections(id) ON DELETE CASCADE,
    subject_id UUID REFERENCES subjects(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    title_bangla VARCHAR(200),
    description TEXT,
    description_bangla TEXT,
    instructions TEXT,
    instructions_bangla TEXT,
    due_date DATE,
    due_time TIME,
    total_marks INTEGER DEFAULT 0,
    file_url VARCHAR(255),
    submission_type VARCHAR(50) DEFAULT 'file', -- file, text, both
    is_group_work BOOLEAN DEFAULT false,
    status VARCHAR(20) DEFAULT 'active', -- active, completed, cancelled
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Homework submissions table
CREATE TABLE homework_submissions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    homework_id UUID REFERENCES homework(id) ON DELETE CASCADE,
    student_id UUID REFERENCES students(id) ON DELETE CASCADE,
    submission_text TEXT,
    submission_text_bangla TEXT,
    file_url VARCHAR(255),
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    marks_obtained DECIMAL(5,2),
    feedback TEXT,
    feedback_bangla TEXT,
    status VARCHAR(20) DEFAULT 'submitted', -- submitted, graded, returned
    is_late BOOLEAN DEFAULT false,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Leave Applications table
CREATE TABLE leave_applications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    applicant_id UUID REFERENCES users(id) ON DELETE CASCADE,
    applicant_type VARCHAR(20) NOT NULL, -- student, teacher
    leave_type VARCHAR(50) NOT NULL, -- sick, casual, emergency, religious, family
    leave_type_bangla VARCHAR(50),
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    total_days INTEGER NOT NULL,
    reason TEXT NOT NULL,
    reason_bangla TEXT,
    supporting_document VARCHAR(255),
    status VARCHAR(20) DEFAULT 'pending', -- pending, approved, rejected
    approved_by UUID REFERENCES users(id) ON DELETE SET NULL,
    approved_at TIMESTAMP,
    rejection_reason TEXT,
    rejection_reason_bangla TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Fees table
CREATE TABLE fees (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES schools(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    name_bangla VARCHAR(100),
    amount DECIMAL(10,2) NOT NULL,
    type VARCHAR(50) NOT NULL, -- monthly, term, annual, admission, exam, transport
    class_id UUID REFERENCES classes(id) ON DELETE CASCADE,
    due_date DATE,
    late_fee DECIMAL(10,2) DEFAULT 0,
    academic_year VARCHAR(10) DEFAULT '2024',
    is_mandatory BOOLEAN DEFAULT true,
    description TEXT,
    description_bangla TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Transactions table
CREATE TABLE transactions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID REFERENCES students(id) ON DELETE CASCADE,
    fee_id UUID REFERENCES fees(id) ON DELETE CASCADE,
    amount DECIMAL(10,2) NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    payment_date DATE NOT NULL,
    payment_method VARCHAR(50), -- cash, bank, bkash, nagad, rocket, card
    transaction_id VARCHAR(100),
    status VARCHAR(20) DEFAULT 'completed', -- pending, completed, failed, refunded
    receipt_number VARCHAR(50),
    collected_by UUID REFERENCES users(id) ON DELETE SET NULL,
    notes TEXT,
    notes_bangla TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Exams table
CREATE TABLE exams (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES schools(id) ON DELETE CASCADE,
    name VARCHAR(100) NOT NULL,
    name_bangla VARCHAR(100),
    type VARCHAR(50), -- first_term, second_term, final, test, quiz
    class_id UUID REFERENCES classes(id) ON DELETE CASCADE,
    subject_id UUID REFERENCES subjects(id) ON DELETE CASCADE,
    exam_date DATE,
    start_time TIME,
    duration INTEGER, -- in minutes
    total_marks INTEGER,
    pass_marks INTEGER,
    room_number VARCHAR(20),
    instructions TEXT,
    instructions_bangla TEXT,
    status VARCHAR(20) DEFAULT 'scheduled', -- scheduled, ongoing, completed, cancelled
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Results table
CREATE TABLE results (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID REFERENCES students(id) ON DELETE CASCADE,
    exam_id UUID REFERENCES exams(id) ON DELETE CASCADE,
    marks_obtained DECIMAL(5,2),
    grade VARCHAR(5),
    grade_point DECIMAL(3,2),
    position INTEGER,
    remarks TEXT,
    remarks_bangla TEXT,
    is_published BOOLEAN DEFAULT false,
    published_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- AI Question Bank table
CREATE TABLE ai_questions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    teacher_id UUID REFERENCES teachers(id) ON DELETE CASCADE,
    subject_id UUID REFERENCES subjects(id) ON DELETE CASCADE,
    class_id UUID REFERENCES classes(id) ON DELETE CASCADE,
    chapter VARCHAR(200),
    chapter_bangla VARCHAR(200),
    question_type VARCHAR(50), -- mcq, short, broad, fill_blank, true_false
    question TEXT NOT NULL,
    question_bangla TEXT,
    options JSONB, -- for MCQ questions
    correct_answer TEXT,
    correct_answer_bangla TEXT,
    explanation TEXT,
    explanation_bangla TEXT,
    difficulty_level VARCHAR(20) DEFAULT 'medium', -- easy, medium, hard
    marks INTEGER DEFAULT 1,
    source_material TEXT, -- textbook, notes, etc.
    ai_generated BOOLEAN DEFAULT false,
    usage_count INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- AI Study Sessions table (for student AI helper)
CREATE TABLE ai_study_sessions (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    student_id UUID REFERENCES students(id) ON DELETE CASCADE,
    subject_id UUID REFERENCES subjects(id) ON DELETE SET NULL,
    session_type VARCHAR(50), -- homework_help, quiz, explanation, practice
    question TEXT NOT NULL,
    question_bangla TEXT,
    ai_response TEXT NOT NULL,
    ai_response_bangla TEXT,
    feedback_rating INTEGER, -- 1-5 stars
    feedback_comment TEXT,
    language_used VARCHAR(10) DEFAULT 'bangla', -- bangla, english
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Message Logs table (for SMS system)
CREATE TABLE message_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sender_id UUID REFERENCES users(id) ON DELETE CASCADE,
    recipient_type VARCHAR(50) NOT NULL, -- student, guardian, teacher, class, section, all
    recipient_ids JSONB NOT NULL, -- array of recipient IDs
    message_type VARCHAR(50) NOT NULL, -- sms, notification, email
    template_type VARCHAR(50), -- attendance_alert, fee_due, result_published, custom
    subject VARCHAR(200),
    message TEXT NOT NULL,
    message_bangla TEXT,
    total_recipients INTEGER NOT NULL,
    sent_count INTEGER DEFAULT 0,
    failed_count INTEGER DEFAULT 0,
    delivery_status VARCHAR(20) DEFAULT 'pending', -- pending, sending, sent, failed, partial
    provider VARCHAR(50), -- muthofun, bulksmsbd, twilio
    cost DECIMAL(8,2) DEFAULT 0,
    scheduled_at TIMESTAMP,
    sent_at TIMESTAMP,
    completed_at TIMESTAMP,
    provider_response JSONB,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Scheduled Messages table
CREATE TABLE scheduled_messages (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    sender_id UUID REFERENCES users(id) ON DELETE CASCADE,
    recipient_type VARCHAR(50) NOT NULL,
    recipient_ids JSONB NOT NULL,
    message_type VARCHAR(50) NOT NULL,
    template_type VARCHAR(50),
    message TEXT NOT NULL,
    message_bangla TEXT,
    scheduled_at TIMESTAMP NOT NULL,
    repeat_type VARCHAR(20), -- none, daily, weekly, monthly
    repeat_until DATE,
    status VARCHAR(20) DEFAULT 'scheduled', -- scheduled, processing, sent, failed, cancelled
    message_log_id UUID REFERENCES message_logs(id) ON DELETE SET NULL,
    sent_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Cultural Events table (Qurbani, Eid, etc.)
CREATE TABLE cultural_events (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES schools(id) ON DELETE CASCADE,
    name VARCHAR(200) NOT NULL,
    name_bangla VARCHAR(200) NOT NULL,
    event_type VARCHAR(50) NOT NULL, -- religious, cultural, academic, sports
    event_date DATE NOT NULL,
    start_time TIME,
    end_time TIME,
    description TEXT,
    description_bangla TEXT,
    location VARCHAR(200),
    location_bangla VARCHAR(200),
    organizer_id UUID REFERENCES users(id) ON DELETE SET NULL,
    target_audience VARCHAR(50) DEFAULT 'all', -- all, students, teachers, parents
    is_holiday BOOLEAN DEFAULT false,
    requires_participation BOOLEAN DEFAULT false,
    max_participants INTEGER,
    registration_deadline DATE,
    status VARCHAR(20) DEFAULT 'planned', -- planned, ongoing, completed, cancelled
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Qurbani Management table
CREATE TABLE qurbani_management (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES schools(id) ON DELETE CASCADE,
    year INTEGER NOT NULL,
    animal_type VARCHAR(50) NOT NULL, -- cow, goat, camel
    animal_count INTEGER NOT NULL,
    cost_per_share DECIMAL(10,2) NOT NULL,
    total_shares INTEGER NOT NULL,
    available_shares INTEGER NOT NULL,
    registration_start_date DATE NOT NULL,
    registration_end_date DATE NOT NULL,
    qurbani_date DATE NOT NULL,
    distribution_date DATE,
    location VARCHAR(200),
    location_bangla VARCHAR(200),
    organizer_id UUID REFERENCES users(id) ON DELETE SET NULL,
    status VARCHAR(20) DEFAULT 'registration_open',
    special_instructions TEXT,
    special_instructions_bangla TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Qurbani Registrations table
CREATE TABLE qurbani_registrations (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    qurbani_id UUID REFERENCES qurbani_management(id) ON DELETE CASCADE,
    participant_id UUID REFERENCES users(id) ON DELETE CASCADE,
    participant_type VARCHAR(20) NOT NULL, -- student, teacher, guardian
    shares_requested INTEGER NOT NULL,
    total_amount DECIMAL(10,2) NOT NULL,
    payment_status VARCHAR(20) DEFAULT 'pending', -- pending, partial, completed
    paid_amount DECIMAL(10,2) DEFAULT 0,
    special_requests TEXT,
    special_requests_bangla TEXT,
    registration_date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    approved_by UUID REFERENCES users(id) ON DELETE SET NULL,
    approved_at TIMESTAMP,
    status VARCHAR(20) DEFAULT 'pending', -- pending, approved, rejected, cancelled
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Notifications table
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    title VARCHAR(200) NOT NULL,
    title_bangla VARCHAR(200),
    message TEXT NOT NULL,
    message_bangla TEXT,
    type VARCHAR(50), -- attendance, fee, result, announcement, homework, leave
    priority VARCHAR(20) DEFAULT 'normal', -- low, normal, high, urgent
    action_url VARCHAR(255),
    is_read BOOLEAN DEFAULT false,
    read_at TIMESTAMP,
    expires_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- System Settings table
CREATE TABLE settings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    school_id UUID REFERENCES schools(id) ON DELETE CASCADE,
    category VARCHAR(100) NOT NULL,
    setting_key VARCHAR(100) NOT NULL,
    setting_value TEXT,
    setting_value_bangla TEXT,
    data_type VARCHAR(20) DEFAULT 'string', -- string, number, boolean, json
    is_public BOOLEAN DEFAULT false,
    description TEXT,
    description_bangla TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(school_id, category, setting_key)
);

-- Audit Logs table
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE SET NULL,
    action VARCHAR(100) NOT NULL,
    table_name VARCHAR(100),
    record_id UUID,
    old_values JSONB,
    new_values JSONB,
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create indexes for better performance
CREATE INDEX idx_users_school_role ON users(school_id, role_id);
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_users_phone ON users(phone);
CREATE INDEX idx_students_class_section ON students(class_id, section_id);
CREATE INDEX idx_students_student_id ON students(student_id);
CREATE INDEX idx_attendance_student_date ON attendance(student_id, date);
CREATE INDEX idx_attendance_class_date ON attendance(class_id, date);
CREATE INDEX idx_teacher_assignments_teacher ON teacher_assignments(teacher_id);
CREATE INDEX idx_class_routines_class_day ON class_routines(class_id, section_id, day_of_week);
CREATE INDEX idx_homework_class_subject ON homework(class_id, section_id, subject_id);
CREATE INDEX idx_message_logs_sender ON message_logs(sender_id);
CREATE INDEX idx_message_logs_status ON message_logs(delivery_status);
CREATE INDEX idx_notifications_user_read ON notifications(user_id, is_read);
CREATE INDEX idx_ai_questions_subject_class ON ai_questions(subject_id, class_id);
CREATE INDEX idx_ai_study_sessions_student ON ai_study_sessions(student_id);
CREATE INDEX idx_leave_applications_status ON leave_applications(status);
CREATE INDEX idx_cultural_events_date ON cultural_events(event_date);
CREATE INDEX idx_qurbani_registrations_qurbani ON qurbani_registrations(qurbani_id);

-- Insert default settings
INSERT INTO settings (school_id, category, setting_key, setting_value, description) VALUES
(NULL, 'sms', 'default_provider', 'muthofun', 'Default SMS provider'),
(NULL, 'sms', 'sender_id', 'SCHOOL', 'Default SMS sender ID'),
(NULL, 'ai', 'enabled', 'true', 'Enable AI features'),
(NULL, 'ai', 'language_support', '["bangla", "english"]', 'Supported languages for AI'),
(NULL, 'academic', 'week_start_day', '0', 'Week start day (0=Sunday)'),
(NULL, 'academic', 'class_duration', '45', 'Default class duration in minutes'),
(NULL, 'cultural', 'enable_qurbani', 'true', 'Enable Qurbani management'),
(NULL, 'cultural', 'enable_cultural_events', 'true', 'Enable cultural events management'),
(NULL, 'attendance', 'auto_absent_time', '10:00', 'Auto mark absent after this time'),
(NULL, 'fees', 'late_fee_percentage', '5', 'Late fee percentage'),
(NULL, 'notification', 'sms_attendance_alert', 'true', 'Send SMS for attendance alerts'),
(NULL, 'notification', 'sms_fee_reminder', 'true', 'Send SMS for fee reminders');

COMMIT;
